# Cycle 3 — Analytics Pages Full Wiring

## Objective
Fully wire dashboard, risk-center, attribution, rebalancing, and portfolio-builder to their correct backend endpoints with visible error states and chart null-safety, all using the portfolio name from the global context.

## Project vision
A fully usable Angular 21 portfolio-optimizer dashboard where selecting a portfolio once propagates to all 10 pages, every API call hits the correct backend contract, every chart renders, and every error surfaces cleanly — backed by ≥80% branch test coverage.

## Preceding cycles
Cycle 1 locked service contracts and error patterns. Cycle 2 migrated `dashboard.ts`, `risk-center.ts`, `attribution.ts`, and `rebalancing.ts` onto `PortfolioContextService`. This cycle builds the endpoint/panel wiring on top of that migration.

## Following cycles
Cycle 4 wires research pages and ticker seeding. Cycle 5 adds settings error handling, contract-parity tests, Playwright UX fixes, and ≥80% coverage.

## In scope
- **Dashboard** (`dashboard/`): `getPerformanceMetrics()`, `getEquityCurve()`, `getAllocation()`, `getRollingMetrics()`, `getAssetClassReturns()` all use the context name; `POST /reports/generate` passes the correct name; market snapshot + indices load independently of selection; `EchartsSunburstComponent`, `EchartsDrawdownComponent`, `EchartsRollingMetricsComponent` handle null/empty without throwing; `PerformanceMetrics` matches `GET /portfolio-analytics/{name}/performance-metrics` field-by-field; equity-curve `dates[]`/`values[]` drive the drawdown chart.
- **Risk-center** (`risk-center/`): VaR, correlation, factor-exposure, concentration, liquidity panels render from their `GET /portfolio/{name}/risk/*` endpoints; `StressPanelComponent` from `POST /risk/stress-scenarios`; limit CRUD round-trip on `/risk/{portfolio_name}/limits`; every panel shows a visible 4xx/5xx error state.
- **Attribution** (`attribution/`): `portfolioWeights` from `getLatestSnapshot(name)`; `BrinsonPanelComponent` from `POST /attribution/brinson`; `FactorAttributionPanelComponent` from `POST /attribution/factor`; `SaaTaaPanelComponent` and `HoldingsAttributionPanelComponent` render.
- **Rebalancing** (`rebalancing/`): drift, policy CRUD, trade preview, snapshot history, and `POST /rebalance/decide` whatif panels all use the global name.
- **Portfolio-builder** (`portfolio-builder/`): `BuilderStore` propagates the global name into name-dependent calls; drift service uses the correct name; analytics-pane drift/result charts render without blank states.

## Out of scope
- Ticker seeding and research pages optimization-studio/backtesting/factor-research (Cycle 4).
- Backtest result persistence and walk-forward (Cycle 4).
- Settings panels (Cycle 5).
- `contract-parity.spec.ts` field-by-field tests (Cycle 5).
- Playwright UX polish — factor 404 hint, KPI em-dash, benchmark metrics (Cycle 5).

## Acceptance criteria
- All five dashboard service methods use the context name; the three named charts render on null/empty; `POST /reports/generate` passes the correct name; market/indices load regardless of selection; `PerformanceMetrics` matches its endpoint field-by-field; KPI cards, equity curve, allocation sunburst, and rolling charts populate within 3s locally.
- Each risk panel renders from its endpoint; stress and limit CRUD work; every panel shows a visible error on 4xx/5xx.
- `portfolioWeights` populates from `getLatestSnapshot(name)`; Brinson, factor, SaaTaa, and holdings panels render.
- All rebalancing endpoints use the global name; status, policy CRUD, trade preview, history, and whatif panels render.
- `BuilderStore` propagates the global name; drift service uses the correct name; analytics-pane charts render without blank states after build.
