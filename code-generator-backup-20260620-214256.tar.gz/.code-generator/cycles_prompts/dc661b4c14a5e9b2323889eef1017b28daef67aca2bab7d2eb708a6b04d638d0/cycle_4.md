# Cycle 4 — Research Pages (Ticker Seeding & Wiring)

## Objective
Seed the ticker universe from the selected portfolio's snapshot across optimization-studio, backtesting, and factor-research, and wire each page's POST/GET-with-polling endpoints and result charts — including backtest result persistence and walk-forward validation.

## Project vision
A fully usable Angular 21 portfolio-optimizer dashboard where selecting a portfolio once propagates to all 10 pages, every API call hits the correct backend contract, every chart renders, and every error surfaces cleanly — backed by ≥80% branch test coverage.

## Preceding cycles
Cycle 1 delivered `core/services/ticker-seeding.service.ts`, the `currentPortfolioName()` signal, and locked research service contracts (`optimization.service.ts`, `backtest.service.ts`, `factors.service.ts`). Cycle 2 propagated global context. Build seeding and wiring on top of those.

## Following cycles
Cycle 5 adds settings error handling, contract-parity tests, remaining Playwright UX polish (KPI em-dash, factor 404 hint, benchmark/walk-forward copy), and ≥80% coverage.

## In scope
- **Ticker seeding (all three pages)**: on load with a portfolio selected, seed from `Object.keys(snapshot.weights)` of `PortfolioApiService.getLatestSnapshot(name)`; re-seed on portfolio change only when the field still holds the last applied seed (leave user-edited fields untouched); fall back to `DEFAULT_TICKERS` on no-portfolio, empty snapshot, or API error (error fallback is silent).
- **optimization-studio** (`optimization-studio/`): `POST /optimize` body matches `OptimizationRequest` exactly; poll `GET /optimize/{runId}` for progress + final result; `applyWeightsToPortfolio()` calls the existing apply endpoint with correct body; llm-moments endpoints (`/llm-moments/calibrate-delta`, etc.) and views endpoints (`/views/generate`, `/views/opinion-pool`, `/views/entropy-pooling`) pass correct shapes; `ResultsPanelComponent` renders all sub-charts.
- **backtesting** (`backtesting/`): `POST /backtest` body matches `BacktestRequest`; poll `GET /backtest/{jobId}`; equity curve, underwater, rolling Sharpe/vol/beta, and QQ charts render; walk-forward via `POST /validate/walk-forward` + polling works end-to-end; date-range sync from context is preserved; backtest result persistence — store the run ID (localStorage/singleton) and restore via `GET /backtest/runs/{runId}` on re-mount and hard refresh, discarding it when it belongs to a different portfolio.
- **factor-research** (`factor-research/`): add the previously-absent portfolio reference via seeding; `POST /factors/compute` + poll `GET /factors/compute/{id}`; `POST /factors/validate` IC/t-stat charts; `POST /factors/score` / `POST /factors/select`; `GET /views/macro-calibration` TAA; `GET /macro-data/te-observations` CMA; all panels show visible error states.

## Out of scope
- Analytics pages dashboard/risk/attribution/rebalancing/portfolio-builder (Cycle 3).
- Context migration (delivered Cycle 2).
- Settings panels and `contract-parity.spec.ts` (Cycle 5).
- Playwright UX polish: KPI pre-run em-dash (13b), factor 404 hint (13c), benchmark metrics, walk-forward copy (Cycle 5).

## Acceptance criteria
- Ticker universe seeds from `Object.keys(snapshot.weights)` of `getLatestSnapshot(name)` on all three pages; re-seeds only when the field still holds its previous seed; falls back to `DEFAULT_TICKERS` (silently on error) on no-portfolio/empty/error.
- optimization-studio: `POST /optimize` matches schema exactly; polling surfaces the result; apply-weights, llm-moments, and views endpoints pass correct shapes; `ResultsPanelComponent` renders all sub-charts.
- backtesting: `POST /backtest` matches schema; polling updates progress; equity/underwater/rolling/QQ charts render; walk-forward works end-to-end; date-range sync unbroken; run ID persists and restores across navigation and refresh, discarding cross-portfolio runs.
- factor-research: compute+validate IC chart renders; score/select/TAA/CMA panels render; all panels show error states on failure.
