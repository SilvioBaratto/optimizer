# Cycle 1 — Service Layer Foundation

## Objective
Establish and lock the shared service foundation every page depends on: `PortfolioContextService` signals (`currentPortfolioName()`, `selectedPortfolio()`), correct feature-service method contracts, and standardized error-handling patterns — so all downstream pages can read global context instead of re-implementing it.

## Project vision
A fully usable Angular 21 portfolio-optimizer dashboard where selecting a portfolio once propagates to all 10 pages, every API call hits the correct backend contract (endpoint, shape, method), every chart renders, and every error surfaces cleanly — backed by ≥80% branch test coverage.

## Preceding cycles
None — this is the first cycle and owns the foundation no other cycle should redefine.

## Following cycles
Cycle 2 migrates risk-center/attribution/rebalancing/dashboard onto this context. Cycle 3 wires analytics-page endpoints. Cycle 4 wires research pages + ticker seeding. Cycle 5 adds settings error handling, contract-parity tests, and UX fixes.

## In scope
- `core/services/portfolio-context.service.ts`: confirm/expose `currentPortfolioName(): Signal<string | null>` resolved from the portfolio list, and `selectedPortfolio(): Signal<Portfolio | null>` holding the full object, alongside existing `currentPortfolioId()`.
- Lock method contracts (correct endpoint URL, HTTP method, request/response shape) on the feature services: `dashboard/dashboard.service.ts`, `risk-center/risk.service.ts`, `backtesting/backtest.service.ts`, `attribution/attribution.service.ts`, `rebalancing/rebalancing.service.ts`, `optimization-studio/optimization.service.ts`, `factor-research/factors.service.ts`.
- Standardize error-handling primitives: the `core/interceptors/api-http.interceptor.ts` toast/retry behavior, identity `mapHttpError` re-throw pattern, `catchError` fallback convention, and `core/services/ticker-seeding.service.ts` silent-fallback contract.

## Out of scope
- Page migrations to context (Cycle 2).
- Wiring panels/charts to endpoints (Cycle 3 analytics, Cycle 4 research).
- Ticker seeding behavior on pages (Cycle 4).
- `contract-parity.spec.ts` and ≥80% coverage (Cycle 5).
- Playwright UX bug fixes (Cycle 5).

## Acceptance criteria
- `PortfolioContextService` exposes `currentPortfolioName(): Signal<string | null>` resolved from the portfolio list and `selectedPortfolio(): Signal<Portfolio | null>` holding the full Portfolio object.
- `currentPortfolioName()` returns the correct name for the selected ID within one render cycle.
- For every service method, HTTP method matches the route, request body matches the backend Pydantic schema with no extra/missing fields, and the response interface matches the API response (validated formally in Cycle 5).
