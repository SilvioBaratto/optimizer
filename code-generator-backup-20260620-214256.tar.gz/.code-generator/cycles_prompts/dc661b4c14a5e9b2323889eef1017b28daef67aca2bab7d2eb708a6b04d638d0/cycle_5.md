# Cycle 5 — Cross-cutting (Testing, UX Bugs, Error States)

## Objective
Harden the application end-to-end: settings-page error handling, field-by-field contract-parity tests across every service, the remaining Playwright-identified UX fixes, standardized error states, and ≥80% branch coverage on all modified files.

## Project vision
A fully usable Angular 21 portfolio-optimizer dashboard where selecting a portfolio once propagates to all 10 pages, every API call hits the correct backend contract, every chart renders, and every error surfaces cleanly — backed by ≥80% branch test coverage.

## Preceding cycles
Cycle 1 locked service contracts and error patterns. Cycle 2 migrated analytics pages to context. Cycle 3 wired dashboard/risk-center/attribution/rebalancing/portfolio-builder. Cycle 4 delivered research-page ticker seeding, endpoint wiring, walk-forward, and backtest run-ID persistence (`backtesting/backtesting-run-storage.ts`). This cycle verifies and tests all of it.

## Following cycles
None — this is the final cycle.

## In scope
- **Settings** (`settings/`): `DataManagementPanelComponent`, `PortfoliosPanelComponent`, `SchedulerStatusPanelComponent`, `JobsPanelComponent` each show a visible error state on API failure; Jobs panel pagination and filtering work against `GET /jobs`.
- **Contract validation (cross-cutting)**: for every service method, verify request body matches the backend Pydantic schema (no extra/missing fields), response interface matches the actual response, HTTP method matches the route, path params are interpolated (no raw `{name}` left), and query params are appended (not in body/omitted). Add or extend `contract-parity.spec.ts` to assert request/response shapes field-by-field for every service method.
- **Playwright UX fixes** (remaining items from scope 13): backtest KPI pre-run state shows `—` instead of `0.00%` (13b); `FactorAttributionPanelComponent` shows an inline "Factor scores not available. Run the factor pipeline first." on a 404 from `POST /attribution/factor`, while other 4xx/5xx still surface as visible errors (13c); the benchmark-comparison empty state on the backtesting Metrics tab; walk-forward copy; and the attribution hint. Verify and keep the two already-patched fixes: the `dashboard` redirect route in `app.routes.ts` and the attribution Brinson/factor endpoint correction.
- **Global error-state standardization** and ≥80% branch coverage on all modified files; `ng test` green.

## Out of scope
- Backtest run-ID persistence mechanism, 13a (delivered in Cycle 4 — Cycle 5 only tests it).
- Any new or changed backend endpoint/contract (forbidden — frontend conforms to existing routes).
- Context migration and analytics/research page wiring (Cycles 2–4).

## Acceptance criteria
- The four settings panels each handle API errors with a visible error state; Jobs pagination and filtering work against `GET /jobs`.
- For every service method: request body matches schema with no extra/missing fields; response type matches the response; HTTP method matches the route; path params are interpolated with no raw `{name}`; query params are appended, not in body/omitted; `contract-parity.spec.ts` asserts request and response shapes field-by-field.
- Backtest KPI cards (Total Return, Sharpe, Max Drawdown, Information Ratio) show `—` pre-run and update after a run; a 404 from `POST /attribution/factor` renders the inline empty-state hint while other errors surface visibly.
- ≥80% branch coverage on all modified files with `ng test` green.
