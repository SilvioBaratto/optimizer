# Cycle 2 — Global Context Propagation

## Objective
Migrate risk-center, attribution, rebalancing, and dashboard off their local portfolio-selection state onto the global `PortfolioContextService`, removing per-page portfolio dropdowns so one selection in the global nav propagates everywhere.

## Project vision
A fully usable Angular 21 portfolio-optimizer dashboard where selecting a portfolio once propagates to all 10 pages, every API call hits the correct backend contract, every chart renders, and every error surfaces cleanly — backed by ≥80% branch test coverage.

## Preceding cycles
Cycle 1 delivered the foundation: `core/services/portfolio-context.service.ts` now exposes `currentPortfolioName()` and `selectedPortfolio()`, plus locked service contracts and shared error-handling patterns. Do not re-plan those.

## Following cycles
Cycle 3 wires the now-migrated pages' endpoints, panels, and chart null-safety. Cycle 4 handles research-page ticker seeding. Cycle 5 covers settings, contract tests, and UX fixes.

## In scope
- `risk-center/risk-center.ts`: drop any local `selectedPortfolio` signal and the local portfolio dropdown; read `portfolioContextService.selectedPortfolio()` / `currentPortfolioName()`.
- `attribution/attribution.ts`: drop local `selectedPortfolio` and `portfolioWeights` selection UI; read from context.
- `rebalancing/rebalancing.ts`: drop local `selectedPortfolio` dropdown; derive name from context.
- `dashboard/dashboard.ts`: read the portfolio name from context and stop re-fetching the portfolio list on each load.
- Portfolio selection remains solely in the global nav/header; per-page dropdowns are removed (a partial "mirror signal" read is explicitly excluded — duplicate state must be eliminated).

## Out of scope
- Endpoint wiring, panel rendering, and chart null-safety for these pages (Cycle 3).
- Ticker seeding and the research pages optimization-studio/backtesting/factor-research (Cycle 4).
- portfolio-builder and settings pages (Cycles 3 and 5).
- Tests and contract-parity specs (Cycle 5).

## Acceptance criteria
- Selecting a portfolio in the global nav/header propagates to all 10 pages without any per-page selection step, and `currentPortfolioName()` returns the correct name within one render cycle.
- risk-center, attribution, rebalancing, and dashboard read `portfolioContextService.selectedPortfolio()` instead of any local `selectedPortfolio` signal, and their local portfolio dropdowns are removed.
- dashboard does not re-fetch the portfolio list on each load, reading the portfolio name from `PortfolioContextService` instead.
