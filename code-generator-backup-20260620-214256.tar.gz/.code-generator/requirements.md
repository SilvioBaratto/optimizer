# Full-stack frontend integration: portfolio-aware pages, correct API wiring, and chart rendering

## Description

The frontend is currently not production-usable. Two classes of problems coexist:

1. **Context gap**: three research pages (optimization-studio, backtesting, factor-research) hardcode `DEFAULT_TICKERS` instead of seeding from the selected portfolio. Four other pages (risk-center, attribution, rebalancing, dashboard) carry their own local `selectedPortfolio` signal instead of reading from the global `PortfolioContextService`, causing the same portfolio to be re-selected on every page change.

2. **Integration gap**: API calls on multiple pages are either wired to wrong endpoints, pass incorrect parameter shapes, or lack error handling, causing blank charts, silent failures, and broken UI states. No systematic integration test coverage exists to catch regressions.

The goal is a fully usable application: selecting a portfolio once propagates everywhere, every page loads its data correctly, every chart renders, and errors surface cleanly.

## Tech Stack

- Angular 21 (standalone components, signals, `inject()`, OnPush, native control flow)
- TypeScript strict
- RxJS (`takeUntilDestroyed`, `switchMap`, `catchError`)
- ECharts via ngx-echarts
- Existing services: `PortfolioContextService`, `PortfolioApiService`, and all feature-domain services (DashboardService, RiskService, BacktestService, etc.)

## Goals

1. One portfolio selection propagates to all 10 pages without re-selecting per page.
2. Every API call uses the correct endpoint, parameter shape, and HTTP method as defined in the backend route contracts.
3. Every chart component renders its data correctly; no blank/broken chart on first load when data is available.
4. Every API error surfaces in the UI with a visible error state — never a silent blank panel.
5. Fallback to `DEFAULT_TICKERS` on research pages when no portfolio is selected, snapshot is empty, or API call fails.
6. Full unit and integration test coverage (≥80% branch) for all wired pages and their services; `ng test` green.

## Scope

### 1. Global portfolio context propagation

`PortfolioContextService` (`core/services/portfolio-context.service.ts`) stores `currentPortfolioId()`. It must also store and expose:

- `currentPortfolioName(): Signal<string | null>` — resolved from the portfolio list
- `selectedPortfolio(): Signal<Portfolio | null>` — full Portfolio object

Pages currently using a local `selectedPortfolio` signal must be migrated to read from `PortfolioContextService`:

- **risk-center** — currently injects `PortfolioApiService` and holds local `selectedPortfolio`
- **attribution** — currently holds local `selectedPortfolio` and `portfolioWeights`
- **rebalancing** — currently holds local `selectedPortfolio`
- **dashboard** — currently reads portfolio name from context but must not re-fetch the portfolio list on each load

Migration rule: each page drops its local portfolio-selection UI and reads `portfolioContextService.selectedPortfolio()`. Portfolio selection stays in the global nav/header where it already lives. Local portfolio dropdowns on these pages are removed.

Acceptance criteria:

- [ ] `PortfolioContextService` exposes `currentPortfolioName(): Signal<string | null>` resolved from the portfolio list and `selectedPortfolio(): Signal<Portfolio | null>` holding the full Portfolio object.
- [ ] Selecting a portfolio in the global nav/header propagates to all 10 pages without any additional per-page selection step, and `currentPortfolioName()` returns the correct name for the selected ID within one render cycle.
- [ ] risk-center, attribution, rebalancing, and dashboard read `portfolioContextService.selectedPortfolio()` instead of any local `selectedPortfolio` signal, and their local portfolio dropdowns are removed.
      _Assumption: "migrated to read from PortfolioContextService" was read as fully removing the local selection signal and its dropdown UI on these four pages, since the migration rule explicitly states local dropdowns are removed; a partial read (keep signal as a mirror) is excluded because it would leave duplicate state the goal eliminates._
- [ ] dashboard does not re-fetch the portfolio list on each load, reading the portfolio name from `PortfolioContextService` instead.

### 2. Ticker universe seeding (optimization-studio, backtesting, factor-research)

Resolve the id→name gap: `PortfolioContextService` holds an ID; holdings API needs a name. Use `currentPortfolioName()` from scope 1 above.

For each of the three pages:

- On load, if portfolio selected → fetch `PortfolioApiService.getLatestSnapshot(name)` → seed ticker universe from `Object.keys(snapshot.weights)`
- Re-seed on portfolio change (only when field is still at its previous seed value, not when user has edited it)
- Fallback to `DEFAULT_TICKERS` on: no portfolio, empty snapshot, API error

Acceptance criteria:

- [ ] On load of optimization-studio, backtesting, and factor-research with a portfolio selected, the ticker universe is seeded from `Object.keys(snapshot.weights)` of `PortfolioApiService.getLatestSnapshot(name)`.
- [ ] On portfolio change, the ticker field re-seeds only when it still holds its previous seed value, and a user-edited field is left untouched.
      _Assumption: "only when field is still at its previous seed value, not when user has edited it" was read as comparing the current field value against the last seed the page applied; if they match, re-seed; if the user changed it, skip — the only reading consistent with "not when user has edited it."_
- [ ] The ticker field falls back to `DEFAULT_TICKERS` when no portfolio is selected, the snapshot is empty, or the snapshot API call errors, and the API-error fallback occurs silently.

### 3. Dashboard page

- `getPerformanceMetrics()`, `getEquityCurve()`, `getAllocation()`, `getRollingMetrics()`, `getAssetClassReturns()` must all use the name from `PortfolioContextService`
- `EchartsSunburstComponent` (allocation), `EchartsDrawdownComponent`, `EchartsRollingMetricsComponent` must handle null/empty data without throwing
- Report generation (`POST /reports/generate`) must pass correct portfolio name
- Market snapshot and indices must load independently of portfolio selection
- Contract check: `GET /portfolio-analytics/{name}/performance-metrics` → verify response shape matches `PerformanceMetrics` interface
- Contract check: `GET /portfolio-analytics/{name}/equity-curve` → verify `dates[]` and `values[]` arrays drive the drawdown chart correctly

Acceptance criteria:

- [ ] `getPerformanceMetrics()`, `getEquityCurve()`, `getAllocation()`, `getRollingMetrics()`, and `getAssetClassReturns()` all use the portfolio name from `PortfolioContextService`.
- [ ] `EchartsSunburstComponent`, `EchartsDrawdownComponent`, and `EchartsRollingMetricsComponent` render without throwing when given null or empty data.
- [ ] `POST /reports/generate` passes the correct portfolio name.
- [ ] Market snapshot and indices load regardless of whether a portfolio is selected.
- [ ] The `PerformanceMetrics` interface matches the `GET /portfolio-analytics/{name}/performance-metrics` response shape field-by-field, and the `dates[]` and `values[]` arrays from `GET /portfolio-analytics/{name}/equity-curve` drive the drawdown chart.
- [ ] All KPI cards, the equity curve, the allocation sunburst, and the rolling metrics charts populate within 3 seconds on a local API connection.

### 4. Risk-center page

- After migrating to global context (scope 1), all risk endpoints must use the portfolio name from `PortfolioContextService`
- `GET /portfolio/{name}/risk/var` → `VarPanelComponent` must render VaR gauge/bar
- `GET /portfolio/{name}/risk/correlation` → `CorrelationPanelComponent` heatmap must render
- `GET /portfolio/{name}/risk/factor-exposure` → `FactorPanelComponent` must render
- `GET /portfolio/{name}/risk/concentration` → `ConcentrationPanelComponent` must render
- `GET /portfolio/{name}/risk/liquidity` → `LiquidityPanelComponent` must render
- `POST /risk/stress-scenarios` → `StressPanelComponent` must render scenario results
- Limit CRUD (`/risk/{portfolio_name}/limits`) must complete round-trip correctly
- Every panel must show a visible error state when its endpoint returns 4xx/5xx

Acceptance criteria:

- [ ] All risk endpoints use the portfolio name from `PortfolioContextService` after the scope 1 migration.
- [ ] `VarPanelComponent`, `CorrelationPanelComponent`, `FactorPanelComponent`, `ConcentrationPanelComponent`, and `LiquidityPanelComponent` each render when their respective `GET /portfolio/{name}/risk/*` endpoints return data for a portfolio that has data.
- [ ] `StressPanelComponent` renders scenario results from `POST /risk/stress-scenarios`.
- [ ] Limit CRUD against `/risk/{portfolio_name}/limits` completes a correct round-trip.
- [ ] Every panel shows a visible error state when its endpoint returns a 4xx or 5xx response.

### 5. Attribution page

- After migrating to global context (scope 1), portfolio weights loaded via `getLatestSnapshot(name)` must populate `portfolioWeights`
- `POST /attribution/brinson` → `BrinsonPanelComponent` renders waterfall/bar chart
- `POST /attribution/factor` → `FactorAttributionPanelComponent` renders factor bars
- `SaaTaaPanelComponent` and `HoldingsAttributionPanelComponent` render correctly

Acceptance criteria:

- [ ] `portfolioWeights` is populated from `getLatestSnapshot(name)` using the global portfolio context.
- [ ] `BrinsonPanelComponent` renders the Brinson waterfall/bar chart from `POST /attribution/brinson` when the portfolio has a snapshot and a date range is selected.
- [ ] `FactorAttributionPanelComponent` renders factor attribution bars from `POST /attribution/factor`.
- [ ] `SaaTaaPanelComponent` and `HoldingsAttributionPanelComponent` render correctly.

### 6. Rebalancing page

- After migrating to global context (scope 1), all rebalancing endpoints use global name
- `GET /portfolio-analytics/{name}/drift` → `StatusPanelComponent` renders drift metrics
- `GET/POST /portfolio/{name}/rebalance-policy` → `PolicyPanelComponent` CRUD works
- `GET /rebalance/preview/{portfolio_name}` → `TradePreviewPanelComponent` renders trades
- `GET /portfolio/{name}/snapshots` → `HistoryPanelComponent` renders timeline
- `POST /rebalance/decide` → `WhatifPanelComponent` returns decision correctly

Acceptance criteria:

- [ ] All rebalancing endpoints use the global portfolio name after the scope 1 migration.
- [ ] `StatusPanelComponent` renders drift metrics from `GET /portfolio-analytics/{name}/drift`.
- [ ] `PolicyPanelComponent` CRUD works against `GET/POST /portfolio/{name}/rebalance-policy`.
- [ ] `TradePreviewPanelComponent` renders trades from `GET /rebalance/preview/{portfolio_name}`.
- [ ] `HistoryPanelComponent` renders the snapshot timeline from `GET /portfolio/{name}/snapshots`.
- [ ] `WhatifPanelComponent` returns the decision correctly from `POST /rebalance/decide`.

### 7. Optimization-studio page

- Ticker seeding from portfolio (scope 2)
- `POST /optimize` request body must match backend `OptimizationRequest` schema exactly
- Polling `GET /optimize/{runId}` must update progress and surface final result
- `applyWeightsToPortfolio()` must call correct endpoint with correct body
- LLM-moments endpoints (`/llm-moments/calibrate-delta`, etc.) must pass correct shapes
- Views endpoints (`/views/generate`, `/views/opinion-pool`, `/views/entropy-pooling`) must pass correct shapes
- `ResultsPanelComponent` must render all sub-charts when result arrives

Acceptance criteria:

- [ ] The ticker universe is seeded from the selected portfolio per scope 2.
- [ ] The `POST /optimize` request body matches the backend `OptimizationRequest` schema exactly, with no extra or missing fields.
- [ ] Polling `GET /optimize/{runId}` updates progress and surfaces the final result.
- [ ] `applyWeightsToPortfolio()` calls the correct endpoint with the correct body.
      _Assumption: "correct endpoint with correct body" was read as the endpoint and request shape already defined by the existing backend route for applying weights; no new endpoint is introduced, per the non-goal forbidding backend contract changes._
- [ ] LLM-moments endpoints (`/llm-moments/calibrate-delta`, etc.) pass the correct request shapes.
- [ ] Views endpoints (`/views/generate`, `/views/opinion-pool`, `/views/entropy-pooling`) pass the correct request shapes.
- [ ] `ResultsPanelComponent` renders all sub-charts when the result arrives.

### 8. Backtesting page

- Ticker seeding from portfolio (scope 2)
- `POST /backtest` request body must match backend `BacktestRequest` schema exactly
- Polling `GET /backtest/{jobId}` must update progress
- Equity curve, underwater chart, rolling Sharpe/vol/beta, QQ plot must all render when result data is present
- Walk-forward `POST /validate/walk-forward` and polling must work end-to-end
- Date-range sync from `PortfolioContextService` must not be broken by ticker seeding

Acceptance criteria:

- [ ] The ticker universe is seeded from the selected portfolio per scope 2.
- [ ] The `POST /backtest` request body matches the backend `BacktestRequest` schema exactly.
- [ ] Polling `GET /backtest/{jobId}` updates progress.
- [ ] The equity curve, underwater chart, rolling Sharpe/vol/beta charts, and QQ plot all render when result data is present.
- [ ] Walk-forward via `POST /validate/walk-forward` plus its polling works end-to-end.
- [ ] Date-range sync from `PortfolioContextService` continues to work and is not broken by ticker seeding.

### 9. Factor-research page

- Ticker seeding from portfolio (scope 2) — page currently has no portfolio reference
- `POST /factors/compute` + polling `GET /factors/compute/{id}` must work
- `POST /factors/validate` → `FactorAnalysisPanelComponent` renders IC/t-stat charts
- `POST /factors/score` / `POST /factors/select` → `ScorePanelComponent` / `SelectPanelComponent` render results
- `GET /views/macro-calibration` → `TaaPanelComponent` renders TAA weights
- `GET /macro-data/te-observations` → `CmaBuilderPanelComponent` renders CMA chart
- All panels show visible error state on failure

Acceptance criteria:

- [ ] The ticker universe is seeded from the selected portfolio per scope 2, adding the previously-absent portfolio reference to this page.
- [ ] `POST /factors/compute` plus polling `GET /factors/compute/{id}` works, and the IC chart renders on completion of the compute + validate round-trip.
- [ ] `FactorAnalysisPanelComponent` renders IC/t-stat charts from `POST /factors/validate`.
- [ ] `ScorePanelComponent` renders results from `POST /factors/score` and `SelectPanelComponent` renders results from `POST /factors/select`.
- [ ] `TaaPanelComponent` renders TAA weights from `GET /views/macro-calibration`.
- [ ] `CmaBuilderPanelComponent` renders the CMA chart from `GET /macro-data/te-observations`.
- [ ] All panels show a visible error state on failure.

### 10. Portfolio-builder page

- `BuilderStore` must propagate the globally-selected portfolio name into any endpoint calls that are portfolio-name-dependent
- Drift service endpoint must use correct portfolio name
- Result charts in analytics-pane must render without blank states

Acceptance criteria:

- [ ] `BuilderStore` propagates the globally-selected portfolio name into every portfolio-name-dependent endpoint call.
- [ ] The drift service endpoint uses the correct portfolio name.
- [ ] The drift and result charts in analytics-pane render without blank states after the build step completes.

### 11. Settings page

- `DataManagementPanelComponent`, `PortfoliosPanelComponent`, `SchedulerStatusPanelComponent`, `JobsPanelComponent` — each must handle API errors with visible error states
- Jobs panel pagination and filtering must work correctly against `GET /jobs`

Acceptance criteria:

- [ ] `DataManagementPanelComponent`, `PortfoliosPanelComponent`, `SchedulerStatusPanelComponent`, and `JobsPanelComponent` each handle API errors with a visible error state.
- [ ] Jobs panel pagination and filtering work correctly against `GET /jobs`.

### 12. API contract validation (cross-cutting)

For every service method across all pages:

- Request body shape must match the backend Pydantic schema (no extra or missing fields)
- Response type interface must match the actual API response structure
- HTTP method (GET/POST/PUT/DELETE) must match the route definition
- URL path parameters must be correctly interpolated (no raw `{name}` in actual requests)
- Query parameters must be correctly appended (not placed in body or omitted)

Add `contract-parity.spec.ts` tests (or extend existing ones) that validate the frontend interface types against the backend schema field-by-field.

Acceptance criteria:

- [ ] For every service method, the request body shape matches the backend Pydantic schema with no extra or missing fields.
- [ ] For every service method, the response type interface matches the actual API response structure.
- [ ] For every service method, the HTTP method matches the route definition.
- [ ] URL path parameters are correctly interpolated, with no raw `{name}` token left in any actual request.
- [ ] Query parameters are correctly appended to the URL, not placed in the body or omitted.
- [ ] `contract-parity.spec.ts` tests (new or extended) assert request and response shapes field-by-field for every service method.

### 13. Playwright-identified UX and wiring bugs

Bugs discovered via live Playwright investigation of the running application (Jun 12, 2026). Two have already been patched in source; the rest need implementation.

**Already fixed in source (verify and keep):**

- `/dashboard` route was a 404 — added `{ path: 'dashboard', redirectTo: '', pathMatch: 'full' }` to `app.routes.ts`.
- Attribution page called `GET /attribution/brinson/{name}` and `GET /attribution/factor/{name}` (non-existent endpoints). Fixed: `loadAttributionData` now calls `portfolioApi.getLatestSnapshot(name)` then `attribution.brinson(POST)` and `attribution.factor(POST)`.

**Needs implementation:**

#### 13a. Backtest result persistence across navigation

After a backtest completes, navigating away and back resets all KPI cards to `0.00%` and the equity curve disappears. The run ID must be stored (in `localStorage` or a singleton service signal) so that on re-mount the page re-fetches `GET /backtest/runs/{runId}` and restores the result without requiring a re-run.

Acceptance criteria:

- [ ] After a successful backtest, the run ID is persisted so that navigating away and back restores the result via `GET /backtest/runs/{runId}`.
- [ ] A hard refresh (`F5`) also restores the last run result for the currently selected portfolio.
- [ ] If the stored run ID belongs to a different portfolio, the result is discarded and the page shows the empty state.

#### 13b. Backtest KPI pre-run state

Before any backtest has been run, KPI cards display `0.00%` / `0.00`, which looks like real data. They should display `—` (em-dash) to signal "no data yet."

Acceptance criteria:

- [ ] Total Return, Sharpe Ratio, Max Drawdown, and Information Ratio all display `—` when no backtest result is loaded.
- [ ] After a run completes the values update to the actual result.

#### 13c. Attribution factor 404 — meaningful empty state

`POST /attribution/factor` returns `404` when no factor scores exist in the database. The current UI shows a generic HTTP error toast. Instead, the `FactorAttributionPanelComponent` should detect a 404 from this endpoint and show a targeted message: _"Factor scores not available. Run the factor pipeline first."_

Acceptance criteria:

- [ ] A 404 response from `POST /attribution/factor` renders an inline empty-state message in `FactorAttributionPanelComponent` rather than a generic error toast.
- [ ] Any other 4xx/5xx still surfaces as a visible error state.

#### 13d. Backtesting Metrics tab — benchmark comparison empty

The Metrics tab shows `—` for every value in the "Benchmark (SPY)" column. Benchmark returns must be fetched (price history for the benchmark ticker over the backtest date range) and compared against the portfolio return series.

Acceptance criteria:

- [ ] The Metrics tab Benchmark column shows actual values (Total Return, Sharpe, Volatility, etc.) for the selected benchmark ticker when price history is available.
- [ ] If benchmark price history is unavailable, the column shows `N/A` with a tooltip explanation.

#### 13e. Walk-forward section exposes implementation detail

In the Backtesting Lab, the "Walk-forward validation" section description reads: _"Runs a background job via POST /validate/walk-forward with cv_type=walk_forward."_ This is an internal implementation detail, not user-facing copy.

Acceptance criteria:

- [ ] The walk-forward section description is replaced with a user-facing description of what walk-forward validation does (e.g. "Validates the strategy using out-of-sample rolling windows to avoid look-ahead bias.").
- [ ] No API endpoint or request parameter names appear in any user-facing UI copy.

#### 13f. Attribution page shows "(none)" for portfolio name in form hint

The form hint below the benchmark weights field reads: _"Portfolio weights are taken from the latest snapshot of the selected portfolio (none)."_ The `(none)` is a stale placeholder; after the scope-5 fix the selected portfolio name must be interpolated.

Acceptance criteria:

- [ ] The form hint interpolates the current portfolio name: _"Portfolio weights are taken from the latest snapshot of **t212**."_
- [ ] When no portfolio is selected the hint reads: _"No portfolio selected. Select one in the navigation bar."_

## Non-goals

- Do not change the backend API contracts or add new endpoints.
- Do not redesign the visual layout of any page.
- Do not migrate to a new state management library.
- AI-control-room: backend not yet implemented — skip.
- Do not add E2E (Playwright) tests in this cycle — unit/integration coverage only.

## Constraints

- Standalone components only; no `standalone: true` in decorators.
- `ChangeDetectionStrategy.OnPush`; signals + `computed()`; `inject()`.
- Native control flow (`@if`/`@for`/`@switch`); `class`/`style` bindings.
- `takeUntilDestroyed(this.destroyRef)` on all subscriptions.
- `catchError` on every HTTP call; never let an uncaught observable error reach the component and leave the UI blank.
- ECharts options objects must be non-null before binding to `[options]`; use a `computed()` that returns a safe empty-state option when data is null.
- No `any` types on API response shapes — every response must have a typed interface.

## Global acceptance criteria

- [ ] Selecting a portfolio in the header propagates to all pages without additional selection steps, and `PortfolioContextService.currentPortfolioName()` returns the correct name for the selected ID within one render cycle.
- [ ] Dashboard: all KPI cards, equity curve, allocation sunburst, and rolling metrics charts populate within 3 seconds on a local API connection.
- [ ] Risk-center: VaR, correlation heatmap, factor exposure, concentration, and liquidity panels all render when the portfolio has data.
- [ ] Attribution: the Brinson waterfall and factor attribution bars render when the portfolio has a snapshot and a date range is selected.
- [ ] Rebalancing: drift metrics, policy list, trade preview, and snapshot history all load.
- [ ] Optimization-studio: an optimization run completes and the results panel renders all sub-charts.
- [ ] Backtesting: a backtest run completes and the equity curve and rolling metrics charts render.
- [ ] Factor-research: the compute + validate round-trip completes and the IC chart renders.
- [ ] Portfolio-builder: drift and result charts render after the build step completes.
- [ ] Every page/panel shows a visible, non-blank error state (message or alert component) when its primary API call returns an error.
- [ ] No unhandled observable errors reach `console.error`.
      _Assumption: "No `console.error` unhandled observable errors" was read as the prohibition of uncaught observable errors surfacing through `console.error`, since the constraints already mandate `catchError` on every HTTP call; deliberate diagnostic logging that is caught and handled is not in scope of this prohibition._
- [ ] Navigation to optimization-studio, backtesting, or factor-research with a portfolio selected pre-fills tickers from that portfolio's latest snapshot.
- [ ] Navigation to those pages with no portfolio selected shows `DEFAULT_TICKERS`.
- [ ] An API error during snapshot fetch falls back to `DEFAULT_TICKERS` silently.
- [ ] `ng test` passes with zero failures.
- [ ] Branch coverage is ≥80% on all modified and new files.
- [ ] Every wired page has specs covering: (a) loads data on init, (b) handles API error, and (c) reacts to portfolio context change.
- [ ] Contract-parity specs assert request and response shapes for every service method.
- [ ] Navigating to `/dashboard` redirects to `/` rather than showing the 404 page.
- [ ] Backtesting Lab restores the last run result (KPIs + equity curve) after navigating away and back.
- [ ] Backtesting Lab shows `—` in all KPI cards before any run is executed.
- [ ] Factor attribution 404 renders an inline "Factor scores not available" message, not a generic error toast.
- [ ] Attribution form hint shows the actual portfolio name, not "(none)".
- [ ] No API endpoint or parameter names appear in any user-facing UI copy.
