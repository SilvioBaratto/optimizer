# Graph Report - optimizer  (2026-06-15)

## Corpus Check
- 1818 files · ~3,576,761 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 35989 nodes · 90215 edges · 2077 communities (1495 shown, 582 thin omitted)
- Extraction: 85% EXTRACTED · 15% INFERRED · 0% AMBIGUOUS · INFERRED: 13852 edges (avg confidence: 0.68)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `02f1c05b`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_API Views & Scenarios|API Views & Scenarios]]
- [[_COMMUNITY_Optimizer Validation & Reporting|Optimizer Validation & Reporting]]
- [[_COMMUNITY_Macro Regime API & Tests|Macro Regime API & Tests]]
- [[_COMMUNITY_Async Job Endpoints|Async Job Endpoints]]
- [[_COMMUNITY_News Sentiment Pipeline|News Sentiment Pipeline]]
- [[_COMMUNITY_Macro Calibration & BL Config|Macro Calibration & BL Config]]
- [[_COMMUNITY_Hierarchical Clustering Config|Hierarchical Clustering Config]]
- [[_COMMUNITY_Service Import Boundary Tests|Service Import Boundary Tests]]
- [[_COMMUNITY_LLM Moments & Business Cycle|LLM Moments & Business Cycle]]
- [[_COMMUNITY_Universe Screening & Selection|Universe Screening & Selection]]
- [[_COMMUNITY_Risk Analytics API Tests|Risk Analytics API Tests]]
- [[_COMMUNITY_Optimization & Tuning Schemas|Optimization & Tuning Schemas]]
- [[_COMMUNITY_Factor & Macro Models|Factor & Macro Models]]
- [[_COMMUNITY_BAML Type Builder|BAML Type Builder]]
- [[_COMMUNITY_Optimizer Config Surface|Optimizer Config Surface]]
- [[_COMMUNITY_Portfolio Routes & Jobs|Portfolio Routes & Jobs]]
- [[_COMMUNITY_Resilience Infrastructure Clients|Resilience Infrastructure Clients]]
- [[_COMMUNITY_Rebalancing & Risk Schemas|Rebalancing & Risk Schemas]]
- [[_COMMUNITY_Cluster 18|Cluster 18]]
- [[_COMMUNITY_Cluster 19|Cluster 19]]
- [[_COMMUNITY_Cluster 20|Cluster 20]]
- [[_COMMUNITY_Cluster 21|Cluster 21]]
- [[_COMMUNITY_Cluster 22|Cluster 22]]
- [[_COMMUNITY_Cluster 23|Cluster 23]]
- [[_COMMUNITY_Cluster 24|Cluster 24]]
- [[_COMMUNITY_Cluster 25|Cluster 25]]
- [[_COMMUNITY_Cluster 26|Cluster 26]]
- [[_COMMUNITY_Cluster 27|Cluster 27]]
- [[_COMMUNITY_Cluster 28|Cluster 28]]
- [[_COMMUNITY_Cluster 29|Cluster 29]]
- [[_COMMUNITY_Cluster 30|Cluster 30]]
- [[_COMMUNITY_Cluster 31|Cluster 31]]
- [[_COMMUNITY_Cluster 32|Cluster 32]]
- [[_COMMUNITY_Cluster 33|Cluster 33]]
- [[_COMMUNITY_Cluster 34|Cluster 34]]
- [[_COMMUNITY_Cluster 35|Cluster 35]]
- [[_COMMUNITY_Cluster 36|Cluster 36]]
- [[_COMMUNITY_Cluster 37|Cluster 37]]
- [[_COMMUNITY_Cluster 38|Cluster 38]]
- [[_COMMUNITY_Cluster 39|Cluster 39]]
- [[_COMMUNITY_Cluster 40|Cluster 40]]
- [[_COMMUNITY_Cluster 41|Cluster 41]]
- [[_COMMUNITY_Cluster 42|Cluster 42]]
- [[_COMMUNITY_Cluster 43|Cluster 43]]
- [[_COMMUNITY_Cluster 44|Cluster 44]]
- [[_COMMUNITY_Cluster 45|Cluster 45]]
- [[_COMMUNITY_Cluster 46|Cluster 46]]
- [[_COMMUNITY_Cluster 47|Cluster 47]]
- [[_COMMUNITY_Cluster 48|Cluster 48]]
- [[_COMMUNITY_Cluster 49|Cluster 49]]
- [[_COMMUNITY_Cluster 50|Cluster 50]]
- [[_COMMUNITY_Cluster 51|Cluster 51]]
- [[_COMMUNITY_Cluster 52|Cluster 52]]
- [[_COMMUNITY_Cluster 53|Cluster 53]]
- [[_COMMUNITY_Cluster 54|Cluster 54]]
- [[_COMMUNITY_Cluster 55|Cluster 55]]
- [[_COMMUNITY_Cluster 56|Cluster 56]]
- [[_COMMUNITY_Cluster 57|Cluster 57]]
- [[_COMMUNITY_Cluster 58|Cluster 58]]
- [[_COMMUNITY_Cluster 59|Cluster 59]]
- [[_COMMUNITY_Cluster 60|Cluster 60]]
- [[_COMMUNITY_Cluster 61|Cluster 61]]
- [[_COMMUNITY_Cluster 62|Cluster 62]]
- [[_COMMUNITY_Cluster 63|Cluster 63]]
- [[_COMMUNITY_Cluster 64|Cluster 64]]
- [[_COMMUNITY_Cluster 65|Cluster 65]]
- [[_COMMUNITY_Cluster 66|Cluster 66]]
- [[_COMMUNITY_Cluster 67|Cluster 67]]
- [[_COMMUNITY_Cluster 68|Cluster 68]]
- [[_COMMUNITY_Cluster 69|Cluster 69]]
- [[_COMMUNITY_Cluster 70|Cluster 70]]
- [[_COMMUNITY_Cluster 71|Cluster 71]]
- [[_COMMUNITY_Cluster 72|Cluster 72]]
- [[_COMMUNITY_Cluster 73|Cluster 73]]
- [[_COMMUNITY_Cluster 74|Cluster 74]]
- [[_COMMUNITY_Cluster 75|Cluster 75]]
- [[_COMMUNITY_Cluster 76|Cluster 76]]
- [[_COMMUNITY_Cluster 77|Cluster 77]]
- [[_COMMUNITY_Cluster 78|Cluster 78]]
- [[_COMMUNITY_Cluster 79|Cluster 79]]
- [[_COMMUNITY_Cluster 80|Cluster 80]]
- [[_COMMUNITY_Cluster 81|Cluster 81]]
- [[_COMMUNITY_Cluster 82|Cluster 82]]
- [[_COMMUNITY_Cluster 83|Cluster 83]]
- [[_COMMUNITY_Cluster 84|Cluster 84]]
- [[_COMMUNITY_Cluster 85|Cluster 85]]
- [[_COMMUNITY_Cluster 86|Cluster 86]]
- [[_COMMUNITY_Cluster 87|Cluster 87]]
- [[_COMMUNITY_Cluster 88|Cluster 88]]
- [[_COMMUNITY_Cluster 89|Cluster 89]]
- [[_COMMUNITY_Cluster 90|Cluster 90]]
- [[_COMMUNITY_Cluster 91|Cluster 91]]
- [[_COMMUNITY_Cluster 92|Cluster 92]]
- [[_COMMUNITY_Cluster 93|Cluster 93]]
- [[_COMMUNITY_Cluster 94|Cluster 94]]
- [[_COMMUNITY_Cluster 95|Cluster 95]]
- [[_COMMUNITY_Cluster 96|Cluster 96]]
- [[_COMMUNITY_Cluster 97|Cluster 97]]
- [[_COMMUNITY_Cluster 98|Cluster 98]]
- [[_COMMUNITY_Cluster 99|Cluster 99]]
- [[_COMMUNITY_Cluster 100|Cluster 100]]
- [[_COMMUNITY_Cluster 101|Cluster 101]]
- [[_COMMUNITY_Cluster 102|Cluster 102]]
- [[_COMMUNITY_Cluster 103|Cluster 103]]
- [[_COMMUNITY_Cluster 104|Cluster 104]]
- [[_COMMUNITY_Cluster 105|Cluster 105]]
- [[_COMMUNITY_Cluster 106|Cluster 106]]
- [[_COMMUNITY_Cluster 107|Cluster 107]]
- [[_COMMUNITY_Cluster 108|Cluster 108]]
- [[_COMMUNITY_Cluster 109|Cluster 109]]
- [[_COMMUNITY_Cluster 110|Cluster 110]]
- [[_COMMUNITY_Cluster 111|Cluster 111]]
- [[_COMMUNITY_Cluster 112|Cluster 112]]
- [[_COMMUNITY_Cluster 113|Cluster 113]]
- [[_COMMUNITY_Cluster 114|Cluster 114]]
- [[_COMMUNITY_Cluster 115|Cluster 115]]
- [[_COMMUNITY_Cluster 116|Cluster 116]]
- [[_COMMUNITY_Cluster 117|Cluster 117]]
- [[_COMMUNITY_Cluster 118|Cluster 118]]
- [[_COMMUNITY_Cluster 119|Cluster 119]]
- [[_COMMUNITY_Cluster 120|Cluster 120]]
- [[_COMMUNITY_Cluster 121|Cluster 121]]
- [[_COMMUNITY_Cluster 122|Cluster 122]]
- [[_COMMUNITY_Cluster 123|Cluster 123]]
- [[_COMMUNITY_Cluster 124|Cluster 124]]
- [[_COMMUNITY_Cluster 125|Cluster 125]]
- [[_COMMUNITY_Cluster 126|Cluster 126]]
- [[_COMMUNITY_Cluster 127|Cluster 127]]
- [[_COMMUNITY_Cluster 128|Cluster 128]]
- [[_COMMUNITY_Cluster 129|Cluster 129]]
- [[_COMMUNITY_Cluster 130|Cluster 130]]
- [[_COMMUNITY_Cluster 131|Cluster 131]]
- [[_COMMUNITY_Cluster 132|Cluster 132]]
- [[_COMMUNITY_Cluster 133|Cluster 133]]
- [[_COMMUNITY_Cluster 134|Cluster 134]]
- [[_COMMUNITY_Cluster 135|Cluster 135]]
- [[_COMMUNITY_Cluster 136|Cluster 136]]
- [[_COMMUNITY_Cluster 137|Cluster 137]]
- [[_COMMUNITY_Cluster 138|Cluster 138]]
- [[_COMMUNITY_Cluster 139|Cluster 139]]
- [[_COMMUNITY_Cluster 140|Cluster 140]]
- [[_COMMUNITY_Cluster 141|Cluster 141]]
- [[_COMMUNITY_Cluster 142|Cluster 142]]
- [[_COMMUNITY_Cluster 143|Cluster 143]]
- [[_COMMUNITY_Cluster 144|Cluster 144]]
- [[_COMMUNITY_Cluster 145|Cluster 145]]
- [[_COMMUNITY_Cluster 146|Cluster 146]]
- [[_COMMUNITY_Cluster 147|Cluster 147]]
- [[_COMMUNITY_Cluster 148|Cluster 148]]
- [[_COMMUNITY_Cluster 149|Cluster 149]]
- [[_COMMUNITY_Cluster 150|Cluster 150]]
- [[_COMMUNITY_Cluster 151|Cluster 151]]
- [[_COMMUNITY_Cluster 152|Cluster 152]]
- [[_COMMUNITY_Cluster 153|Cluster 153]]
- [[_COMMUNITY_Cluster 154|Cluster 154]]
- [[_COMMUNITY_Cluster 155|Cluster 155]]
- [[_COMMUNITY_Cluster 156|Cluster 156]]
- [[_COMMUNITY_Cluster 157|Cluster 157]]
- [[_COMMUNITY_Cluster 158|Cluster 158]]
- [[_COMMUNITY_Cluster 159|Cluster 159]]
- [[_COMMUNITY_Cluster 160|Cluster 160]]
- [[_COMMUNITY_Cluster 161|Cluster 161]]
- [[_COMMUNITY_Cluster 162|Cluster 162]]
- [[_COMMUNITY_Cluster 163|Cluster 163]]
- [[_COMMUNITY_Cluster 164|Cluster 164]]
- [[_COMMUNITY_Cluster 165|Cluster 165]]
- [[_COMMUNITY_Cluster 166|Cluster 166]]
- [[_COMMUNITY_Cluster 167|Cluster 167]]
- [[_COMMUNITY_Cluster 168|Cluster 168]]
- [[_COMMUNITY_Cluster 169|Cluster 169]]
- [[_COMMUNITY_Cluster 170|Cluster 170]]
- [[_COMMUNITY_Cluster 171|Cluster 171]]
- [[_COMMUNITY_Cluster 172|Cluster 172]]
- [[_COMMUNITY_Cluster 173|Cluster 173]]
- [[_COMMUNITY_Cluster 174|Cluster 174]]
- [[_COMMUNITY_Cluster 175|Cluster 175]]
- [[_COMMUNITY_Cluster 176|Cluster 176]]
- [[_COMMUNITY_Cluster 177|Cluster 177]]
- [[_COMMUNITY_Cluster 178|Cluster 178]]
- [[_COMMUNITY_Cluster 179|Cluster 179]]
- [[_COMMUNITY_Cluster 180|Cluster 180]]
- [[_COMMUNITY_Cluster 181|Cluster 181]]
- [[_COMMUNITY_Cluster 182|Cluster 182]]
- [[_COMMUNITY_Cluster 183|Cluster 183]]
- [[_COMMUNITY_Cluster 184|Cluster 184]]
- [[_COMMUNITY_Cluster 185|Cluster 185]]
- [[_COMMUNITY_Cluster 186|Cluster 186]]
- [[_COMMUNITY_Cluster 187|Cluster 187]]
- [[_COMMUNITY_Cluster 188|Cluster 188]]
- [[_COMMUNITY_Cluster 189|Cluster 189]]
- [[_COMMUNITY_Cluster 190|Cluster 190]]
- [[_COMMUNITY_Cluster 191|Cluster 191]]
- [[_COMMUNITY_Cluster 192|Cluster 192]]
- [[_COMMUNITY_Cluster 193|Cluster 193]]
- [[_COMMUNITY_Cluster 194|Cluster 194]]
- [[_COMMUNITY_Cluster 195|Cluster 195]]
- [[_COMMUNITY_Cluster 196|Cluster 196]]
- [[_COMMUNITY_Cluster 197|Cluster 197]]
- [[_COMMUNITY_Cluster 198|Cluster 198]]
- [[_COMMUNITY_Cluster 199|Cluster 199]]
- [[_COMMUNITY_Cluster 200|Cluster 200]]
- [[_COMMUNITY_Cluster 201|Cluster 201]]
- [[_COMMUNITY_Cluster 202|Cluster 202]]
- [[_COMMUNITY_Cluster 203|Cluster 203]]
- [[_COMMUNITY_Cluster 204|Cluster 204]]
- [[_COMMUNITY_Cluster 205|Cluster 205]]
- [[_COMMUNITY_Cluster 206|Cluster 206]]
- [[_COMMUNITY_Cluster 207|Cluster 207]]
- [[_COMMUNITY_Cluster 208|Cluster 208]]
- [[_COMMUNITY_Cluster 209|Cluster 209]]
- [[_COMMUNITY_Cluster 210|Cluster 210]]
- [[_COMMUNITY_Cluster 211|Cluster 211]]
- [[_COMMUNITY_Cluster 212|Cluster 212]]
- [[_COMMUNITY_Cluster 213|Cluster 213]]
- [[_COMMUNITY_Cluster 214|Cluster 214]]
- [[_COMMUNITY_Cluster 215|Cluster 215]]
- [[_COMMUNITY_Cluster 216|Cluster 216]]
- [[_COMMUNITY_Cluster 217|Cluster 217]]
- [[_COMMUNITY_Cluster 218|Cluster 218]]
- [[_COMMUNITY_Cluster 219|Cluster 219]]
- [[_COMMUNITY_Cluster 220|Cluster 220]]
- [[_COMMUNITY_Cluster 221|Cluster 221]]
- [[_COMMUNITY_Cluster 222|Cluster 222]]
- [[_COMMUNITY_Cluster 223|Cluster 223]]
- [[_COMMUNITY_Cluster 224|Cluster 224]]
- [[_COMMUNITY_Cluster 225|Cluster 225]]
- [[_COMMUNITY_Cluster 226|Cluster 226]]
- [[_COMMUNITY_Cluster 227|Cluster 227]]
- [[_COMMUNITY_Cluster 228|Cluster 228]]
- [[_COMMUNITY_Cluster 229|Cluster 229]]
- [[_COMMUNITY_Cluster 230|Cluster 230]]
- [[_COMMUNITY_Cluster 231|Cluster 231]]
- [[_COMMUNITY_Cluster 232|Cluster 232]]
- [[_COMMUNITY_Cluster 233|Cluster 233]]
- [[_COMMUNITY_Cluster 234|Cluster 234]]
- [[_COMMUNITY_Cluster 235|Cluster 235]]
- [[_COMMUNITY_Cluster 236|Cluster 236]]
- [[_COMMUNITY_Cluster 237|Cluster 237]]
- [[_COMMUNITY_Cluster 238|Cluster 238]]
- [[_COMMUNITY_Cluster 239|Cluster 239]]
- [[_COMMUNITY_Cluster 240|Cluster 240]]
- [[_COMMUNITY_Cluster 241|Cluster 241]]
- [[_COMMUNITY_Cluster 242|Cluster 242]]
- [[_COMMUNITY_Cluster 243|Cluster 243]]
- [[_COMMUNITY_Cluster 244|Cluster 244]]
- [[_COMMUNITY_Cluster 245|Cluster 245]]
- [[_COMMUNITY_Cluster 246|Cluster 246]]
- [[_COMMUNITY_Cluster 247|Cluster 247]]
- [[_COMMUNITY_Cluster 248|Cluster 248]]
- [[_COMMUNITY_Cluster 249|Cluster 249]]
- [[_COMMUNITY_Cluster 250|Cluster 250]]
- [[_COMMUNITY_Cluster 251|Cluster 251]]
- [[_COMMUNITY_Cluster 252|Cluster 252]]
- [[_COMMUNITY_Cluster 253|Cluster 253]]
- [[_COMMUNITY_Cluster 254|Cluster 254]]
- [[_COMMUNITY_Cluster 255|Cluster 255]]
- [[_COMMUNITY_Cluster 256|Cluster 256]]
- [[_COMMUNITY_Cluster 257|Cluster 257]]
- [[_COMMUNITY_Cluster 258|Cluster 258]]
- [[_COMMUNITY_Cluster 259|Cluster 259]]
- [[_COMMUNITY_Cluster 260|Cluster 260]]
- [[_COMMUNITY_Cluster 261|Cluster 261]]
- [[_COMMUNITY_Cluster 262|Cluster 262]]
- [[_COMMUNITY_Cluster 263|Cluster 263]]
- [[_COMMUNITY_Cluster 264|Cluster 264]]
- [[_COMMUNITY_Cluster 265|Cluster 265]]
- [[_COMMUNITY_Cluster 266|Cluster 266]]
- [[_COMMUNITY_Cluster 267|Cluster 267]]
- [[_COMMUNITY_Cluster 268|Cluster 268]]
- [[_COMMUNITY_Cluster 269|Cluster 269]]
- [[_COMMUNITY_Cluster 270|Cluster 270]]
- [[_COMMUNITY_Cluster 271|Cluster 271]]
- [[_COMMUNITY_Cluster 272|Cluster 272]]
- [[_COMMUNITY_Cluster 273|Cluster 273]]
- [[_COMMUNITY_Cluster 274|Cluster 274]]
- [[_COMMUNITY_Cluster 275|Cluster 275]]
- [[_COMMUNITY_Cluster 276|Cluster 276]]
- [[_COMMUNITY_Cluster 277|Cluster 277]]
- [[_COMMUNITY_Cluster 278|Cluster 278]]
- [[_COMMUNITY_Cluster 279|Cluster 279]]
- [[_COMMUNITY_Cluster 280|Cluster 280]]
- [[_COMMUNITY_Cluster 281|Cluster 281]]
- [[_COMMUNITY_Cluster 282|Cluster 282]]
- [[_COMMUNITY_Cluster 283|Cluster 283]]
- [[_COMMUNITY_Cluster 284|Cluster 284]]
- [[_COMMUNITY_Cluster 285|Cluster 285]]
- [[_COMMUNITY_Cluster 286|Cluster 286]]
- [[_COMMUNITY_Cluster 287|Cluster 287]]
- [[_COMMUNITY_Cluster 288|Cluster 288]]
- [[_COMMUNITY_Cluster 289|Cluster 289]]
- [[_COMMUNITY_Cluster 290|Cluster 290]]
- [[_COMMUNITY_Cluster 291|Cluster 291]]
- [[_COMMUNITY_Cluster 292|Cluster 292]]
- [[_COMMUNITY_Cluster 293|Cluster 293]]
- [[_COMMUNITY_Cluster 294|Cluster 294]]
- [[_COMMUNITY_Cluster 295|Cluster 295]]
- [[_COMMUNITY_Cluster 296|Cluster 296]]
- [[_COMMUNITY_Cluster 297|Cluster 297]]
- [[_COMMUNITY_Cluster 298|Cluster 298]]
- [[_COMMUNITY_Cluster 299|Cluster 299]]
- [[_COMMUNITY_Cluster 300|Cluster 300]]
- [[_COMMUNITY_Cluster 301|Cluster 301]]
- [[_COMMUNITY_Cluster 302|Cluster 302]]
- [[_COMMUNITY_Cluster 303|Cluster 303]]
- [[_COMMUNITY_Cluster 304|Cluster 304]]
- [[_COMMUNITY_Cluster 305|Cluster 305]]
- [[_COMMUNITY_Cluster 306|Cluster 306]]
- [[_COMMUNITY_Cluster 307|Cluster 307]]
- [[_COMMUNITY_Cluster 308|Cluster 308]]
- [[_COMMUNITY_Cluster 309|Cluster 309]]
- [[_COMMUNITY_Cluster 310|Cluster 310]]
- [[_COMMUNITY_Cluster 311|Cluster 311]]
- [[_COMMUNITY_Cluster 312|Cluster 312]]
- [[_COMMUNITY_Cluster 313|Cluster 313]]
- [[_COMMUNITY_Cluster 314|Cluster 314]]
- [[_COMMUNITY_Cluster 315|Cluster 315]]
- [[_COMMUNITY_Cluster 316|Cluster 316]]
- [[_COMMUNITY_Cluster 317|Cluster 317]]
- [[_COMMUNITY_Cluster 318|Cluster 318]]
- [[_COMMUNITY_Cluster 319|Cluster 319]]
- [[_COMMUNITY_Cluster 320|Cluster 320]]
- [[_COMMUNITY_Cluster 321|Cluster 321]]
- [[_COMMUNITY_Cluster 322|Cluster 322]]
- [[_COMMUNITY_Cluster 323|Cluster 323]]
- [[_COMMUNITY_Cluster 324|Cluster 324]]
- [[_COMMUNITY_Cluster 325|Cluster 325]]
- [[_COMMUNITY_Cluster 326|Cluster 326]]
- [[_COMMUNITY_Cluster 327|Cluster 327]]
- [[_COMMUNITY_Cluster 328|Cluster 328]]
- [[_COMMUNITY_Cluster 329|Cluster 329]]
- [[_COMMUNITY_Cluster 330|Cluster 330]]
- [[_COMMUNITY_Cluster 331|Cluster 331]]
- [[_COMMUNITY_Cluster 332|Cluster 332]]
- [[_COMMUNITY_Cluster 333|Cluster 333]]
- [[_COMMUNITY_Cluster 334|Cluster 334]]
- [[_COMMUNITY_Cluster 335|Cluster 335]]
- [[_COMMUNITY_Cluster 336|Cluster 336]]
- [[_COMMUNITY_Cluster 337|Cluster 337]]
- [[_COMMUNITY_Cluster 338|Cluster 338]]
- [[_COMMUNITY_Cluster 339|Cluster 339]]
- [[_COMMUNITY_Cluster 340|Cluster 340]]
- [[_COMMUNITY_Cluster 341|Cluster 341]]
- [[_COMMUNITY_Cluster 342|Cluster 342]]
- [[_COMMUNITY_Cluster 343|Cluster 343]]
- [[_COMMUNITY_Cluster 344|Cluster 344]]
- [[_COMMUNITY_Cluster 345|Cluster 345]]
- [[_COMMUNITY_Cluster 346|Cluster 346]]
- [[_COMMUNITY_Cluster 347|Cluster 347]]
- [[_COMMUNITY_Cluster 348|Cluster 348]]
- [[_COMMUNITY_Cluster 349|Cluster 349]]
- [[_COMMUNITY_Cluster 350|Cluster 350]]
- [[_COMMUNITY_Cluster 351|Cluster 351]]
- [[_COMMUNITY_Cluster 352|Cluster 352]]
- [[_COMMUNITY_Cluster 353|Cluster 353]]
- [[_COMMUNITY_Cluster 354|Cluster 354]]
- [[_COMMUNITY_Cluster 355|Cluster 355]]
- [[_COMMUNITY_Cluster 356|Cluster 356]]
- [[_COMMUNITY_Cluster 357|Cluster 357]]
- [[_COMMUNITY_Cluster 358|Cluster 358]]
- [[_COMMUNITY_Cluster 359|Cluster 359]]
- [[_COMMUNITY_Cluster 360|Cluster 360]]
- [[_COMMUNITY_Cluster 361|Cluster 361]]
- [[_COMMUNITY_Cluster 362|Cluster 362]]
- [[_COMMUNITY_Cluster 363|Cluster 363]]
- [[_COMMUNITY_Cluster 364|Cluster 364]]
- [[_COMMUNITY_Cluster 365|Cluster 365]]
- [[_COMMUNITY_Cluster 366|Cluster 366]]
- [[_COMMUNITY_Cluster 367|Cluster 367]]
- [[_COMMUNITY_Cluster 368|Cluster 368]]
- [[_COMMUNITY_Cluster 369|Cluster 369]]
- [[_COMMUNITY_Cluster 370|Cluster 370]]
- [[_COMMUNITY_Cluster 371|Cluster 371]]
- [[_COMMUNITY_Cluster 372|Cluster 372]]
- [[_COMMUNITY_Cluster 373|Cluster 373]]
- [[_COMMUNITY_Cluster 374|Cluster 374]]
- [[_COMMUNITY_Cluster 375|Cluster 375]]
- [[_COMMUNITY_Cluster 376|Cluster 376]]
- [[_COMMUNITY_Cluster 377|Cluster 377]]
- [[_COMMUNITY_Cluster 378|Cluster 378]]
- [[_COMMUNITY_Cluster 379|Cluster 379]]
- [[_COMMUNITY_Cluster 380|Cluster 380]]
- [[_COMMUNITY_Cluster 381|Cluster 381]]
- [[_COMMUNITY_Cluster 382|Cluster 382]]
- [[_COMMUNITY_Cluster 383|Cluster 383]]
- [[_COMMUNITY_Cluster 384|Cluster 384]]
- [[_COMMUNITY_Cluster 385|Cluster 385]]
- [[_COMMUNITY_Cluster 386|Cluster 386]]
- [[_COMMUNITY_Cluster 387|Cluster 387]]
- [[_COMMUNITY_Cluster 388|Cluster 388]]
- [[_COMMUNITY_Cluster 389|Cluster 389]]
- [[_COMMUNITY_Cluster 390|Cluster 390]]
- [[_COMMUNITY_Cluster 391|Cluster 391]]
- [[_COMMUNITY_Cluster 392|Cluster 392]]
- [[_COMMUNITY_Cluster 393|Cluster 393]]
- [[_COMMUNITY_Cluster 394|Cluster 394]]
- [[_COMMUNITY_Cluster 395|Cluster 395]]
- [[_COMMUNITY_Cluster 396|Cluster 396]]
- [[_COMMUNITY_Cluster 397|Cluster 397]]
- [[_COMMUNITY_Cluster 398|Cluster 398]]
- [[_COMMUNITY_Cluster 399|Cluster 399]]
- [[_COMMUNITY_Cluster 400|Cluster 400]]
- [[_COMMUNITY_Cluster 401|Cluster 401]]
- [[_COMMUNITY_Cluster 402|Cluster 402]]
- [[_COMMUNITY_Cluster 403|Cluster 403]]
- [[_COMMUNITY_Cluster 404|Cluster 404]]
- [[_COMMUNITY_Cluster 405|Cluster 405]]
- [[_COMMUNITY_Cluster 406|Cluster 406]]
- [[_COMMUNITY_Cluster 407|Cluster 407]]
- [[_COMMUNITY_Cluster 408|Cluster 408]]
- [[_COMMUNITY_Cluster 409|Cluster 409]]
- [[_COMMUNITY_Cluster 410|Cluster 410]]
- [[_COMMUNITY_Cluster 411|Cluster 411]]
- [[_COMMUNITY_Cluster 412|Cluster 412]]
- [[_COMMUNITY_Cluster 413|Cluster 413]]
- [[_COMMUNITY_Cluster 414|Cluster 414]]
- [[_COMMUNITY_Cluster 415|Cluster 415]]
- [[_COMMUNITY_Cluster 416|Cluster 416]]
- [[_COMMUNITY_Cluster 417|Cluster 417]]
- [[_COMMUNITY_Cluster 418|Cluster 418]]
- [[_COMMUNITY_Cluster 419|Cluster 419]]
- [[_COMMUNITY_Cluster 420|Cluster 420]]
- [[_COMMUNITY_Cluster 421|Cluster 421]]
- [[_COMMUNITY_Cluster 422|Cluster 422]]
- [[_COMMUNITY_Cluster 423|Cluster 423]]
- [[_COMMUNITY_Cluster 424|Cluster 424]]
- [[_COMMUNITY_Cluster 425|Cluster 425]]
- [[_COMMUNITY_Cluster 426|Cluster 426]]
- [[_COMMUNITY_Cluster 427|Cluster 427]]
- [[_COMMUNITY_Cluster 428|Cluster 428]]
- [[_COMMUNITY_Cluster 429|Cluster 429]]
- [[_COMMUNITY_Cluster 430|Cluster 430]]
- [[_COMMUNITY_Cluster 431|Cluster 431]]
- [[_COMMUNITY_Cluster 432|Cluster 432]]
- [[_COMMUNITY_Cluster 433|Cluster 433]]
- [[_COMMUNITY_Cluster 434|Cluster 434]]
- [[_COMMUNITY_Cluster 435|Cluster 435]]
- [[_COMMUNITY_Cluster 436|Cluster 436]]
- [[_COMMUNITY_Cluster 437|Cluster 437]]
- [[_COMMUNITY_Cluster 438|Cluster 438]]
- [[_COMMUNITY_Cluster 439|Cluster 439]]
- [[_COMMUNITY_Cluster 440|Cluster 440]]
- [[_COMMUNITY_Cluster 441|Cluster 441]]
- [[_COMMUNITY_Cluster 442|Cluster 442]]
- [[_COMMUNITY_Cluster 443|Cluster 443]]
- [[_COMMUNITY_Cluster 444|Cluster 444]]
- [[_COMMUNITY_Cluster 445|Cluster 445]]
- [[_COMMUNITY_Cluster 446|Cluster 446]]
- [[_COMMUNITY_Cluster 447|Cluster 447]]
- [[_COMMUNITY_Cluster 448|Cluster 448]]
- [[_COMMUNITY_Cluster 449|Cluster 449]]
- [[_COMMUNITY_Cluster 450|Cluster 450]]
- [[_COMMUNITY_Cluster 451|Cluster 451]]
- [[_COMMUNITY_Cluster 452|Cluster 452]]
- [[_COMMUNITY_Cluster 453|Cluster 453]]
- [[_COMMUNITY_Cluster 454|Cluster 454]]
- [[_COMMUNITY_Cluster 455|Cluster 455]]
- [[_COMMUNITY_Cluster 456|Cluster 456]]
- [[_COMMUNITY_Cluster 457|Cluster 457]]
- [[_COMMUNITY_Cluster 458|Cluster 458]]
- [[_COMMUNITY_Cluster 459|Cluster 459]]
- [[_COMMUNITY_Cluster 460|Cluster 460]]
- [[_COMMUNITY_Cluster 461|Cluster 461]]
- [[_COMMUNITY_Cluster 462|Cluster 462]]
- [[_COMMUNITY_Cluster 463|Cluster 463]]
- [[_COMMUNITY_Cluster 464|Cluster 464]]
- [[_COMMUNITY_Cluster 465|Cluster 465]]
- [[_COMMUNITY_Cluster 466|Cluster 466]]
- [[_COMMUNITY_Cluster 467|Cluster 467]]
- [[_COMMUNITY_Cluster 468|Cluster 468]]
- [[_COMMUNITY_Cluster 469|Cluster 469]]
- [[_COMMUNITY_Cluster 470|Cluster 470]]
- [[_COMMUNITY_Cluster 471|Cluster 471]]
- [[_COMMUNITY_Cluster 472|Cluster 472]]
- [[_COMMUNITY_Cluster 473|Cluster 473]]
- [[_COMMUNITY_Cluster 474|Cluster 474]]
- [[_COMMUNITY_Cluster 475|Cluster 475]]
- [[_COMMUNITY_Cluster 476|Cluster 476]]
- [[_COMMUNITY_Cluster 478|Cluster 478]]
- [[_COMMUNITY_Cluster 479|Cluster 479]]
- [[_COMMUNITY_Cluster 480|Cluster 480]]
- [[_COMMUNITY_Cluster 481|Cluster 481]]
- [[_COMMUNITY_Cluster 482|Cluster 482]]
- [[_COMMUNITY_Cluster 483|Cluster 483]]
- [[_COMMUNITY_Cluster 484|Cluster 484]]
- [[_COMMUNITY_Cluster 485|Cluster 485]]
- [[_COMMUNITY_Cluster 486|Cluster 486]]
- [[_COMMUNITY_Cluster 487|Cluster 487]]
- [[_COMMUNITY_Cluster 488|Cluster 488]]
- [[_COMMUNITY_Cluster 489|Cluster 489]]
- [[_COMMUNITY_Cluster 490|Cluster 490]]
- [[_COMMUNITY_Cluster 491|Cluster 491]]
- [[_COMMUNITY_Cluster 492|Cluster 492]]
- [[_COMMUNITY_Cluster 493|Cluster 493]]
- [[_COMMUNITY_Cluster 494|Cluster 494]]
- [[_COMMUNITY_Cluster 495|Cluster 495]]
- [[_COMMUNITY_Cluster 496|Cluster 496]]
- [[_COMMUNITY_Cluster 497|Cluster 497]]
- [[_COMMUNITY_Cluster 498|Cluster 498]]
- [[_COMMUNITY_Cluster 499|Cluster 499]]
- [[_COMMUNITY_Cluster 500|Cluster 500]]
- [[_COMMUNITY_Cluster 501|Cluster 501]]
- [[_COMMUNITY_Cluster 502|Cluster 502]]
- [[_COMMUNITY_Cluster 503|Cluster 503]]
- [[_COMMUNITY_Cluster 504|Cluster 504]]
- [[_COMMUNITY_Cluster 505|Cluster 505]]
- [[_COMMUNITY_Cluster 506|Cluster 506]]
- [[_COMMUNITY_Cluster 507|Cluster 507]]
- [[_COMMUNITY_Cluster 508|Cluster 508]]
- [[_COMMUNITY_Cluster 509|Cluster 509]]
- [[_COMMUNITY_Cluster 510|Cluster 510]]
- [[_COMMUNITY_Cluster 511|Cluster 511]]
- [[_COMMUNITY_Cluster 512|Cluster 512]]
- [[_COMMUNITY_Cluster 513|Cluster 513]]
- [[_COMMUNITY_Cluster 514|Cluster 514]]
- [[_COMMUNITY_Cluster 515|Cluster 515]]
- [[_COMMUNITY_Cluster 516|Cluster 516]]
- [[_COMMUNITY_Cluster 517|Cluster 517]]
- [[_COMMUNITY_Cluster 518|Cluster 518]]
- [[_COMMUNITY_Cluster 519|Cluster 519]]
- [[_COMMUNITY_Cluster 520|Cluster 520]]
- [[_COMMUNITY_Cluster 521|Cluster 521]]
- [[_COMMUNITY_Cluster 522|Cluster 522]]
- [[_COMMUNITY_Cluster 523|Cluster 523]]
- [[_COMMUNITY_Cluster 524|Cluster 524]]
- [[_COMMUNITY_Cluster 525|Cluster 525]]
- [[_COMMUNITY_Cluster 526|Cluster 526]]
- [[_COMMUNITY_Cluster 527|Cluster 527]]
- [[_COMMUNITY_Cluster 528|Cluster 528]]
- [[_COMMUNITY_Cluster 529|Cluster 529]]
- [[_COMMUNITY_Cluster 530|Cluster 530]]
- [[_COMMUNITY_Cluster 531|Cluster 531]]
- [[_COMMUNITY_Cluster 532|Cluster 532]]
- [[_COMMUNITY_Cluster 533|Cluster 533]]
- [[_COMMUNITY_Cluster 534|Cluster 534]]
- [[_COMMUNITY_Cluster 535|Cluster 535]]
- [[_COMMUNITY_Cluster 536|Cluster 536]]
- [[_COMMUNITY_Cluster 537|Cluster 537]]
- [[_COMMUNITY_Cluster 538|Cluster 538]]
- [[_COMMUNITY_Cluster 539|Cluster 539]]
- [[_COMMUNITY_Cluster 540|Cluster 540]]
- [[_COMMUNITY_Cluster 541|Cluster 541]]
- [[_COMMUNITY_Cluster 542|Cluster 542]]
- [[_COMMUNITY_Cluster 543|Cluster 543]]
- [[_COMMUNITY_Cluster 544|Cluster 544]]
- [[_COMMUNITY_Cluster 545|Cluster 545]]
- [[_COMMUNITY_Cluster 546|Cluster 546]]
- [[_COMMUNITY_Cluster 547|Cluster 547]]
- [[_COMMUNITY_Cluster 548|Cluster 548]]
- [[_COMMUNITY_Cluster 549|Cluster 549]]
- [[_COMMUNITY_Cluster 550|Cluster 550]]
- [[_COMMUNITY_Cluster 551|Cluster 551]]
- [[_COMMUNITY_Cluster 552|Cluster 552]]
- [[_COMMUNITY_Cluster 553|Cluster 553]]
- [[_COMMUNITY_Cluster 554|Cluster 554]]
- [[_COMMUNITY_Cluster 555|Cluster 555]]
- [[_COMMUNITY_Cluster 556|Cluster 556]]
- [[_COMMUNITY_Cluster 557|Cluster 557]]
- [[_COMMUNITY_Cluster 558|Cluster 558]]
- [[_COMMUNITY_Cluster 559|Cluster 559]]
- [[_COMMUNITY_Cluster 560|Cluster 560]]
- [[_COMMUNITY_Cluster 561|Cluster 561]]
- [[_COMMUNITY_Cluster 562|Cluster 562]]
- [[_COMMUNITY_Cluster 563|Cluster 563]]
- [[_COMMUNITY_Cluster 564|Cluster 564]]
- [[_COMMUNITY_Cluster 565|Cluster 565]]
- [[_COMMUNITY_Cluster 566|Cluster 566]]
- [[_COMMUNITY_Cluster 567|Cluster 567]]
- [[_COMMUNITY_Cluster 568|Cluster 568]]
- [[_COMMUNITY_Cluster 569|Cluster 569]]
- [[_COMMUNITY_Cluster 570|Cluster 570]]
- [[_COMMUNITY_Cluster 571|Cluster 571]]
- [[_COMMUNITY_Cluster 572|Cluster 572]]
- [[_COMMUNITY_Cluster 573|Cluster 573]]
- [[_COMMUNITY_Cluster 574|Cluster 574]]
- [[_COMMUNITY_Cluster 575|Cluster 575]]
- [[_COMMUNITY_Cluster 576|Cluster 576]]
- [[_COMMUNITY_Cluster 577|Cluster 577]]
- [[_COMMUNITY_Cluster 578|Cluster 578]]
- [[_COMMUNITY_Cluster 579|Cluster 579]]
- [[_COMMUNITY_Cluster 580|Cluster 580]]
- [[_COMMUNITY_Cluster 581|Cluster 581]]
- [[_COMMUNITY_Cluster 582|Cluster 582]]
- [[_COMMUNITY_Cluster 583|Cluster 583]]
- [[_COMMUNITY_Cluster 584|Cluster 584]]
- [[_COMMUNITY_Cluster 585|Cluster 585]]
- [[_COMMUNITY_Cluster 586|Cluster 586]]
- [[_COMMUNITY_Cluster 587|Cluster 587]]
- [[_COMMUNITY_Cluster 588|Cluster 588]]
- [[_COMMUNITY_Cluster 589|Cluster 589]]
- [[_COMMUNITY_Cluster 590|Cluster 590]]
- [[_COMMUNITY_Cluster 591|Cluster 591]]
- [[_COMMUNITY_Cluster 592|Cluster 592]]
- [[_COMMUNITY_Cluster 593|Cluster 593]]
- [[_COMMUNITY_Cluster 594|Cluster 594]]
- [[_COMMUNITY_Cluster 595|Cluster 595]]
- [[_COMMUNITY_Cluster 596|Cluster 596]]
- [[_COMMUNITY_Cluster 597|Cluster 597]]
- [[_COMMUNITY_Cluster 598|Cluster 598]]
- [[_COMMUNITY_Cluster 599|Cluster 599]]
- [[_COMMUNITY_Cluster 600|Cluster 600]]
- [[_COMMUNITY_Cluster 601|Cluster 601]]
- [[_COMMUNITY_Cluster 602|Cluster 602]]
- [[_COMMUNITY_Cluster 603|Cluster 603]]
- [[_COMMUNITY_Cluster 604|Cluster 604]]
- [[_COMMUNITY_Cluster 605|Cluster 605]]
- [[_COMMUNITY_Cluster 606|Cluster 606]]
- [[_COMMUNITY_Cluster 607|Cluster 607]]
- [[_COMMUNITY_Cluster 608|Cluster 608]]
- [[_COMMUNITY_Cluster 609|Cluster 609]]
- [[_COMMUNITY_Cluster 610|Cluster 610]]
- [[_COMMUNITY_Cluster 611|Cluster 611]]
- [[_COMMUNITY_Cluster 612|Cluster 612]]
- [[_COMMUNITY_Cluster 613|Cluster 613]]
- [[_COMMUNITY_Cluster 614|Cluster 614]]
- [[_COMMUNITY_Cluster 615|Cluster 615]]
- [[_COMMUNITY_Cluster 616|Cluster 616]]
- [[_COMMUNITY_Cluster 617|Cluster 617]]
- [[_COMMUNITY_Cluster 618|Cluster 618]]
- [[_COMMUNITY_Cluster 619|Cluster 619]]
- [[_COMMUNITY_Cluster 620|Cluster 620]]
- [[_COMMUNITY_Cluster 621|Cluster 621]]
- [[_COMMUNITY_Cluster 622|Cluster 622]]
- [[_COMMUNITY_Cluster 623|Cluster 623]]
- [[_COMMUNITY_Cluster 624|Cluster 624]]
- [[_COMMUNITY_Cluster 625|Cluster 625]]
- [[_COMMUNITY_Cluster 626|Cluster 626]]
- [[_COMMUNITY_Cluster 627|Cluster 627]]
- [[_COMMUNITY_Cluster 628|Cluster 628]]
- [[_COMMUNITY_Cluster 629|Cluster 629]]
- [[_COMMUNITY_Cluster 630|Cluster 630]]
- [[_COMMUNITY_Cluster 631|Cluster 631]]
- [[_COMMUNITY_Cluster 632|Cluster 632]]
- [[_COMMUNITY_Cluster 633|Cluster 633]]
- [[_COMMUNITY_Cluster 634|Cluster 634]]
- [[_COMMUNITY_Cluster 635|Cluster 635]]
- [[_COMMUNITY_Cluster 636|Cluster 636]]
- [[_COMMUNITY_Cluster 637|Cluster 637]]
- [[_COMMUNITY_Cluster 638|Cluster 638]]
- [[_COMMUNITY_Cluster 639|Cluster 639]]
- [[_COMMUNITY_Cluster 640|Cluster 640]]
- [[_COMMUNITY_Cluster 641|Cluster 641]]
- [[_COMMUNITY_Cluster 642|Cluster 642]]
- [[_COMMUNITY_Cluster 643|Cluster 643]]
- [[_COMMUNITY_Cluster 644|Cluster 644]]
- [[_COMMUNITY_Cluster 645|Cluster 645]]
- [[_COMMUNITY_Cluster 646|Cluster 646]]
- [[_COMMUNITY_Cluster 647|Cluster 647]]
- [[_COMMUNITY_Cluster 648|Cluster 648]]
- [[_COMMUNITY_Cluster 649|Cluster 649]]
- [[_COMMUNITY_Cluster 650|Cluster 650]]
- [[_COMMUNITY_Cluster 651|Cluster 651]]
- [[_COMMUNITY_Cluster 652|Cluster 652]]
- [[_COMMUNITY_Cluster 653|Cluster 653]]
- [[_COMMUNITY_Cluster 654|Cluster 654]]
- [[_COMMUNITY_Cluster 655|Cluster 655]]
- [[_COMMUNITY_Cluster 656|Cluster 656]]
- [[_COMMUNITY_Cluster 657|Cluster 657]]
- [[_COMMUNITY_Cluster 658|Cluster 658]]
- [[_COMMUNITY_Cluster 659|Cluster 659]]
- [[_COMMUNITY_Cluster 660|Cluster 660]]
- [[_COMMUNITY_Cluster 661|Cluster 661]]
- [[_COMMUNITY_Cluster 662|Cluster 662]]
- [[_COMMUNITY_Cluster 663|Cluster 663]]
- [[_COMMUNITY_Cluster 664|Cluster 664]]
- [[_COMMUNITY_Cluster 665|Cluster 665]]
- [[_COMMUNITY_Cluster 666|Cluster 666]]
- [[_COMMUNITY_Cluster 667|Cluster 667]]
- [[_COMMUNITY_Cluster 668|Cluster 668]]
- [[_COMMUNITY_Cluster 669|Cluster 669]]
- [[_COMMUNITY_Cluster 670|Cluster 670]]
- [[_COMMUNITY_Cluster 671|Cluster 671]]
- [[_COMMUNITY_Cluster 672|Cluster 672]]
- [[_COMMUNITY_Cluster 673|Cluster 673]]
- [[_COMMUNITY_Cluster 674|Cluster 674]]
- [[_COMMUNITY_Cluster 675|Cluster 675]]
- [[_COMMUNITY_Cluster 676|Cluster 676]]
- [[_COMMUNITY_Cluster 677|Cluster 677]]
- [[_COMMUNITY_Cluster 678|Cluster 678]]
- [[_COMMUNITY_Cluster 679|Cluster 679]]
- [[_COMMUNITY_Cluster 680|Cluster 680]]
- [[_COMMUNITY_Cluster 681|Cluster 681]]
- [[_COMMUNITY_Cluster 682|Cluster 682]]
- [[_COMMUNITY_Cluster 683|Cluster 683]]
- [[_COMMUNITY_Cluster 684|Cluster 684]]
- [[_COMMUNITY_Cluster 685|Cluster 685]]
- [[_COMMUNITY_Cluster 686|Cluster 686]]
- [[_COMMUNITY_Cluster 687|Cluster 687]]
- [[_COMMUNITY_Cluster 688|Cluster 688]]
- [[_COMMUNITY_Cluster 689|Cluster 689]]
- [[_COMMUNITY_Cluster 690|Cluster 690]]
- [[_COMMUNITY_Cluster 691|Cluster 691]]
- [[_COMMUNITY_Cluster 692|Cluster 692]]
- [[_COMMUNITY_Cluster 693|Cluster 693]]
- [[_COMMUNITY_Cluster 694|Cluster 694]]
- [[_COMMUNITY_Cluster 695|Cluster 695]]
- [[_COMMUNITY_Cluster 696|Cluster 696]]
- [[_COMMUNITY_Cluster 697|Cluster 697]]
- [[_COMMUNITY_Cluster 698|Cluster 698]]
- [[_COMMUNITY_Cluster 699|Cluster 699]]
- [[_COMMUNITY_Cluster 700|Cluster 700]]
- [[_COMMUNITY_Cluster 701|Cluster 701]]
- [[_COMMUNITY_Cluster 702|Cluster 702]]
- [[_COMMUNITY_Cluster 703|Cluster 703]]
- [[_COMMUNITY_Cluster 704|Cluster 704]]
- [[_COMMUNITY_Cluster 705|Cluster 705]]
- [[_COMMUNITY_Cluster 706|Cluster 706]]
- [[_COMMUNITY_Cluster 707|Cluster 707]]
- [[_COMMUNITY_Cluster 708|Cluster 708]]
- [[_COMMUNITY_Cluster 709|Cluster 709]]
- [[_COMMUNITY_Cluster 710|Cluster 710]]
- [[_COMMUNITY_Cluster 711|Cluster 711]]
- [[_COMMUNITY_Cluster 712|Cluster 712]]
- [[_COMMUNITY_Cluster 713|Cluster 713]]
- [[_COMMUNITY_Cluster 714|Cluster 714]]
- [[_COMMUNITY_Cluster 715|Cluster 715]]
- [[_COMMUNITY_Cluster 716|Cluster 716]]
- [[_COMMUNITY_Cluster 717|Cluster 717]]
- [[_COMMUNITY_Cluster 718|Cluster 718]]
- [[_COMMUNITY_Cluster 719|Cluster 719]]
- [[_COMMUNITY_Cluster 720|Cluster 720]]
- [[_COMMUNITY_Cluster 721|Cluster 721]]
- [[_COMMUNITY_Cluster 722|Cluster 722]]
- [[_COMMUNITY_Cluster 723|Cluster 723]]
- [[_COMMUNITY_Cluster 724|Cluster 724]]
- [[_COMMUNITY_Cluster 725|Cluster 725]]
- [[_COMMUNITY_Cluster 726|Cluster 726]]
- [[_COMMUNITY_Cluster 727|Cluster 727]]
- [[_COMMUNITY_Cluster 728|Cluster 728]]
- [[_COMMUNITY_Cluster 729|Cluster 729]]
- [[_COMMUNITY_Cluster 730|Cluster 730]]
- [[_COMMUNITY_Cluster 731|Cluster 731]]
- [[_COMMUNITY_Cluster 732|Cluster 732]]
- [[_COMMUNITY_Cluster 733|Cluster 733]]
- [[_COMMUNITY_Cluster 734|Cluster 734]]
- [[_COMMUNITY_Cluster 735|Cluster 735]]
- [[_COMMUNITY_Cluster 736|Cluster 736]]
- [[_COMMUNITY_Cluster 737|Cluster 737]]
- [[_COMMUNITY_Cluster 738|Cluster 738]]
- [[_COMMUNITY_Cluster 739|Cluster 739]]
- [[_COMMUNITY_Cluster 740|Cluster 740]]
- [[_COMMUNITY_Cluster 741|Cluster 741]]
- [[_COMMUNITY_Cluster 742|Cluster 742]]
- [[_COMMUNITY_Cluster 743|Cluster 743]]
- [[_COMMUNITY_Cluster 744|Cluster 744]]
- [[_COMMUNITY_Cluster 745|Cluster 745]]
- [[_COMMUNITY_Cluster 746|Cluster 746]]
- [[_COMMUNITY_Cluster 747|Cluster 747]]
- [[_COMMUNITY_Cluster 748|Cluster 748]]
- [[_COMMUNITY_Cluster 749|Cluster 749]]
- [[_COMMUNITY_Cluster 750|Cluster 750]]
- [[_COMMUNITY_Cluster 751|Cluster 751]]
- [[_COMMUNITY_Cluster 752|Cluster 752]]
- [[_COMMUNITY_Cluster 753|Cluster 753]]
- [[_COMMUNITY_Cluster 754|Cluster 754]]
- [[_COMMUNITY_Cluster 755|Cluster 755]]
- [[_COMMUNITY_Cluster 756|Cluster 756]]
- [[_COMMUNITY_Cluster 757|Cluster 757]]
- [[_COMMUNITY_Cluster 758|Cluster 758]]
- [[_COMMUNITY_Cluster 759|Cluster 759]]
- [[_COMMUNITY_Cluster 760|Cluster 760]]
- [[_COMMUNITY_Cluster 761|Cluster 761]]
- [[_COMMUNITY_Cluster 762|Cluster 762]]
- [[_COMMUNITY_Cluster 763|Cluster 763]]
- [[_COMMUNITY_Cluster 764|Cluster 764]]
- [[_COMMUNITY_Cluster 765|Cluster 765]]
- [[_COMMUNITY_Cluster 766|Cluster 766]]
- [[_COMMUNITY_Cluster 767|Cluster 767]]
- [[_COMMUNITY_Cluster 768|Cluster 768]]
- [[_COMMUNITY_Cluster 769|Cluster 769]]
- [[_COMMUNITY_Cluster 770|Cluster 770]]
- [[_COMMUNITY_Cluster 771|Cluster 771]]
- [[_COMMUNITY_Cluster 772|Cluster 772]]
- [[_COMMUNITY_Cluster 773|Cluster 773]]
- [[_COMMUNITY_Cluster 774|Cluster 774]]
- [[_COMMUNITY_Cluster 775|Cluster 775]]
- [[_COMMUNITY_Cluster 776|Cluster 776]]
- [[_COMMUNITY_Cluster 777|Cluster 777]]
- [[_COMMUNITY_Cluster 778|Cluster 778]]
- [[_COMMUNITY_Cluster 779|Cluster 779]]
- [[_COMMUNITY_Cluster 780|Cluster 780]]
- [[_COMMUNITY_Cluster 781|Cluster 781]]
- [[_COMMUNITY_Cluster 782|Cluster 782]]
- [[_COMMUNITY_Cluster 783|Cluster 783]]
- [[_COMMUNITY_Cluster 784|Cluster 784]]
- [[_COMMUNITY_Cluster 785|Cluster 785]]
- [[_COMMUNITY_Cluster 786|Cluster 786]]
- [[_COMMUNITY_Cluster 787|Cluster 787]]
- [[_COMMUNITY_Cluster 810|Cluster 810]]
- [[_COMMUNITY_Cluster 837|Cluster 837]]
- [[_COMMUNITY_Cluster 838|Cluster 838]]
- [[_COMMUNITY_Cluster 839|Cluster 839]]
- [[_COMMUNITY_Cluster 842|Cluster 842]]
- [[_COMMUNITY_Cluster 843|Cluster 843]]
- [[_COMMUNITY_Cluster 844|Cluster 844]]
- [[_COMMUNITY_Cluster 846|Cluster 846]]
- [[_COMMUNITY_Cluster 853|Cluster 853]]
- [[_COMMUNITY_Cluster 854|Cluster 854]]
- [[_COMMUNITY_Cluster 855|Cluster 855]]
- [[_COMMUNITY_Cluster 856|Cluster 856]]
- [[_COMMUNITY_Cluster 857|Cluster 857]]
- [[_COMMUNITY_Cluster 858|Cluster 858]]
- [[_COMMUNITY_Cluster 859|Cluster 859]]
- [[_COMMUNITY_Cluster 860|Cluster 860]]
- [[_COMMUNITY_Cluster 861|Cluster 861]]
- [[_COMMUNITY_Cluster 862|Cluster 862]]
- [[_COMMUNITY_Cluster 865|Cluster 865]]
- [[_COMMUNITY_Cluster 869|Cluster 869]]
- [[_COMMUNITY_Cluster 870|Cluster 870]]
- [[_COMMUNITY_Cluster 871|Cluster 871]]
- [[_COMMUNITY_Cluster 872|Cluster 872]]
- [[_COMMUNITY_Cluster 873|Cluster 873]]
- [[_COMMUNITY_Cluster 874|Cluster 874]]
- [[_COMMUNITY_Cluster 875|Cluster 875]]
- [[_COMMUNITY_Cluster 878|Cluster 878]]
- [[_COMMUNITY_Cluster 879|Cluster 879]]
- [[_COMMUNITY_Cluster 880|Cluster 880]]
- [[_COMMUNITY_Cluster 881|Cluster 881]]
- [[_COMMUNITY_Cluster 882|Cluster 882]]
- [[_COMMUNITY_Cluster 883|Cluster 883]]
- [[_COMMUNITY_Cluster 884|Cluster 884]]
- [[_COMMUNITY_Cluster 885|Cluster 885]]
- [[_COMMUNITY_Cluster 887|Cluster 887]]
- [[_COMMUNITY_Cluster 888|Cluster 888]]
- [[_COMMUNITY_Cluster 889|Cluster 889]]
- [[_COMMUNITY_Cluster 890|Cluster 890]]
- [[_COMMUNITY_Cluster 891|Cluster 891]]
- [[_COMMUNITY_Cluster 892|Cluster 892]]
- [[_COMMUNITY_Cluster 893|Cluster 893]]
- [[_COMMUNITY_Cluster 894|Cluster 894]]
- [[_COMMUNITY_Cluster 895|Cluster 895]]
- [[_COMMUNITY_Cluster 896|Cluster 896]]
- [[_COMMUNITY_Cluster 897|Cluster 897]]
- [[_COMMUNITY_Cluster 898|Cluster 898]]
- [[_COMMUNITY_Cluster 899|Cluster 899]]
- [[_COMMUNITY_Cluster 900|Cluster 900]]
- [[_COMMUNITY_Cluster 901|Cluster 901]]
- [[_COMMUNITY_Cluster 902|Cluster 902]]
- [[_COMMUNITY_Cluster 903|Cluster 903]]
- [[_COMMUNITY_Cluster 904|Cluster 904]]
- [[_COMMUNITY_Cluster 905|Cluster 905]]
- [[_COMMUNITY_Cluster 906|Cluster 906]]
- [[_COMMUNITY_Cluster 907|Cluster 907]]
- [[_COMMUNITY_Cluster 908|Cluster 908]]
- [[_COMMUNITY_Cluster 909|Cluster 909]]
- [[_COMMUNITY_Cluster 910|Cluster 910]]
- [[_COMMUNITY_Cluster 911|Cluster 911]]
- [[_COMMUNITY_Cluster 912|Cluster 912]]
- [[_COMMUNITY_Cluster 913|Cluster 913]]
- [[_COMMUNITY_Cluster 914|Cluster 914]]
- [[_COMMUNITY_Cluster 915|Cluster 915]]
- [[_COMMUNITY_Cluster 916|Cluster 916]]
- [[_COMMUNITY_Cluster 917|Cluster 917]]
- [[_COMMUNITY_Cluster 918|Cluster 918]]
- [[_COMMUNITY_Cluster 919|Cluster 919]]
- [[_COMMUNITY_Cluster 920|Cluster 920]]
- [[_COMMUNITY_Cluster 921|Cluster 921]]
- [[_COMMUNITY_Cluster 922|Cluster 922]]
- [[_COMMUNITY_Cluster 923|Cluster 923]]
- [[_COMMUNITY_Cluster 924|Cluster 924]]
- [[_COMMUNITY_Cluster 925|Cluster 925]]
- [[_COMMUNITY_Cluster 926|Cluster 926]]
- [[_COMMUNITY_Cluster 927|Cluster 927]]
- [[_COMMUNITY_Cluster 928|Cluster 928]]
- [[_COMMUNITY_Cluster 929|Cluster 929]]
- [[_COMMUNITY_Cluster 930|Cluster 930]]
- [[_COMMUNITY_Cluster 931|Cluster 931]]
- [[_COMMUNITY_Cluster 932|Cluster 932]]
- [[_COMMUNITY_Cluster 933|Cluster 933]]
- [[_COMMUNITY_Cluster 934|Cluster 934]]
- [[_COMMUNITY_Cluster 935|Cluster 935]]
- [[_COMMUNITY_Cluster 936|Cluster 936]]
- [[_COMMUNITY_Cluster 937|Cluster 937]]
- [[_COMMUNITY_Cluster 938|Cluster 938]]
- [[_COMMUNITY_Cluster 939|Cluster 939]]
- [[_COMMUNITY_Cluster 940|Cluster 940]]
- [[_COMMUNITY_Cluster 941|Cluster 941]]
- [[_COMMUNITY_Cluster 942|Cluster 942]]
- [[_COMMUNITY_Cluster 943|Cluster 943]]
- [[_COMMUNITY_Cluster 944|Cluster 944]]
- [[_COMMUNITY_Cluster 945|Cluster 945]]
- [[_COMMUNITY_Cluster 946|Cluster 946]]
- [[_COMMUNITY_Cluster 947|Cluster 947]]
- [[_COMMUNITY_Cluster 948|Cluster 948]]
- [[_COMMUNITY_Cluster 949|Cluster 949]]
- [[_COMMUNITY_Cluster 950|Cluster 950]]
- [[_COMMUNITY_Cluster 951|Cluster 951]]
- [[_COMMUNITY_Cluster 952|Cluster 952]]
- [[_COMMUNITY_Cluster 953|Cluster 953]]
- [[_COMMUNITY_Cluster 954|Cluster 954]]
- [[_COMMUNITY_Cluster 955|Cluster 955]]
- [[_COMMUNITY_Cluster 956|Cluster 956]]
- [[_COMMUNITY_Cluster 957|Cluster 957]]
- [[_COMMUNITY_Cluster 958|Cluster 958]]
- [[_COMMUNITY_Cluster 959|Cluster 959]]
- [[_COMMUNITY_Cluster 960|Cluster 960]]
- [[_COMMUNITY_Cluster 961|Cluster 961]]
- [[_COMMUNITY_Cluster 962|Cluster 962]]
- [[_COMMUNITY_Cluster 963|Cluster 963]]
- [[_COMMUNITY_Cluster 964|Cluster 964]]
- [[_COMMUNITY_Cluster 965|Cluster 965]]
- [[_COMMUNITY_Cluster 966|Cluster 966]]
- [[_COMMUNITY_Cluster 967|Cluster 967]]
- [[_COMMUNITY_Community 968|Community 968]]
- [[_COMMUNITY_Community 969|Community 969]]
- [[_COMMUNITY_Community 970|Community 970]]
- [[_COMMUNITY_Community 971|Community 971]]
- [[_COMMUNITY_Community 972|Community 972]]
- [[_COMMUNITY_Community 973|Community 973]]
- [[_COMMUNITY_Community 974|Community 974]]
- [[_COMMUNITY_Community 975|Community 975]]
- [[_COMMUNITY_Community 976|Community 976]]
- [[_COMMUNITY_Community 977|Community 977]]
- [[_COMMUNITY_Community 978|Community 978]]
- [[_COMMUNITY_Community 979|Community 979]]
- [[_COMMUNITY_Community 980|Community 980]]
- [[_COMMUNITY_Community 981|Community 981]]
- [[_COMMUNITY_Community 982|Community 982]]
- [[_COMMUNITY_Community 983|Community 983]]
- [[_COMMUNITY_Community 984|Community 984]]
- [[_COMMUNITY_Community 985|Community 985]]
- [[_COMMUNITY_Community 986|Community 986]]
- [[_COMMUNITY_Community 987|Community 987]]
- [[_COMMUNITY_Community 988|Community 988]]
- [[_COMMUNITY_Community 989|Community 989]]
- [[_COMMUNITY_Community 990|Community 990]]
- [[_COMMUNITY_Community 991|Community 991]]
- [[_COMMUNITY_Community 992|Community 992]]
- [[_COMMUNITY_Community 993|Community 993]]
- [[_COMMUNITY_Community 994|Community 994]]
- [[_COMMUNITY_Community 995|Community 995]]
- [[_COMMUNITY_Community 996|Community 996]]
- [[_COMMUNITY_Community 997|Community 997]]
- [[_COMMUNITY_Community 998|Community 998]]
- [[_COMMUNITY_Community 999|Community 999]]
- [[_COMMUNITY_Community 1000|Community 1000]]
- [[_COMMUNITY_Community 1001|Community 1001]]
- [[_COMMUNITY_Community 1002|Community 1002]]
- [[_COMMUNITY_Community 1003|Community 1003]]
- [[_COMMUNITY_Community 1004|Community 1004]]
- [[_COMMUNITY_Community 1005|Community 1005]]
- [[_COMMUNITY_Community 1006|Community 1006]]
- [[_COMMUNITY_Community 1007|Community 1007]]
- [[_COMMUNITY_Community 1008|Community 1008]]
- [[_COMMUNITY_Community 1009|Community 1009]]
- [[_COMMUNITY_Community 1010|Community 1010]]
- [[_COMMUNITY_Community 1011|Community 1011]]
- [[_COMMUNITY_Community 1012|Community 1012]]
- [[_COMMUNITY_Community 1013|Community 1013]]
- [[_COMMUNITY_Community 1014|Community 1014]]
- [[_COMMUNITY_Community 1015|Community 1015]]
- [[_COMMUNITY_Community 1016|Community 1016]]
- [[_COMMUNITY_Community 1017|Community 1017]]
- [[_COMMUNITY_Community 1018|Community 1018]]
- [[_COMMUNITY_Community 1019|Community 1019]]
- [[_COMMUNITY_Community 1020|Community 1020]]
- [[_COMMUNITY_Community 1021|Community 1021]]
- [[_COMMUNITY_Community 1022|Community 1022]]
- [[_COMMUNITY_Community 1023|Community 1023]]
- [[_COMMUNITY_Community 1024|Community 1024]]
- [[_COMMUNITY_Community 1025|Community 1025]]
- [[_COMMUNITY_Community 1026|Community 1026]]
- [[_COMMUNITY_Community 1027|Community 1027]]
- [[_COMMUNITY_Community 1028|Community 1028]]
- [[_COMMUNITY_Community 1029|Community 1029]]
- [[_COMMUNITY_Community 1030|Community 1030]]
- [[_COMMUNITY_Community 1031|Community 1031]]
- [[_COMMUNITY_Community 1032|Community 1032]]
- [[_COMMUNITY_Community 1033|Community 1033]]
- [[_COMMUNITY_Community 1034|Community 1034]]
- [[_COMMUNITY_Community 1035|Community 1035]]
- [[_COMMUNITY_Community 1036|Community 1036]]
- [[_COMMUNITY_Community 1037|Community 1037]]
- [[_COMMUNITY_Community 1038|Community 1038]]
- [[_COMMUNITY_Community 1039|Community 1039]]
- [[_COMMUNITY_Community 1040|Community 1040]]
- [[_COMMUNITY_Community 1041|Community 1041]]
- [[_COMMUNITY_Community 1042|Community 1042]]
- [[_COMMUNITY_Community 1043|Community 1043]]
- [[_COMMUNITY_Community 1044|Community 1044]]
- [[_COMMUNITY_Community 1045|Community 1045]]
- [[_COMMUNITY_Community 1046|Community 1046]]
- [[_COMMUNITY_Community 1047|Community 1047]]
- [[_COMMUNITY_Community 1048|Community 1048]]
- [[_COMMUNITY_Community 1049|Community 1049]]
- [[_COMMUNITY_Community 1050|Community 1050]]
- [[_COMMUNITY_Community 1051|Community 1051]]
- [[_COMMUNITY_Community 1052|Community 1052]]
- [[_COMMUNITY_Community 1053|Community 1053]]
- [[_COMMUNITY_Community 1054|Community 1054]]
- [[_COMMUNITY_Community 1055|Community 1055]]
- [[_COMMUNITY_Community 1056|Community 1056]]
- [[_COMMUNITY_Community 1057|Community 1057]]
- [[_COMMUNITY_Community 1058|Community 1058]]
- [[_COMMUNITY_Community 1059|Community 1059]]
- [[_COMMUNITY_Community 1060|Community 1060]]
- [[_COMMUNITY_Community 1061|Community 1061]]
- [[_COMMUNITY_Community 1062|Community 1062]]
- [[_COMMUNITY_Community 1063|Community 1063]]
- [[_COMMUNITY_Community 1064|Community 1064]]
- [[_COMMUNITY_Community 1065|Community 1065]]
- [[_COMMUNITY_Community 1066|Community 1066]]
- [[_COMMUNITY_Community 1067|Community 1067]]
- [[_COMMUNITY_Community 1068|Community 1068]]
- [[_COMMUNITY_Community 1069|Community 1069]]
- [[_COMMUNITY_Community 1070|Community 1070]]
- [[_COMMUNITY_Community 1071|Community 1071]]
- [[_COMMUNITY_Community 1072|Community 1072]]
- [[_COMMUNITY_Community 1073|Community 1073]]
- [[_COMMUNITY_Community 1074|Community 1074]]
- [[_COMMUNITY_Community 1075|Community 1075]]
- [[_COMMUNITY_Community 1076|Community 1076]]
- [[_COMMUNITY_Community 1077|Community 1077]]
- [[_COMMUNITY_Community 1078|Community 1078]]
- [[_COMMUNITY_Community 1079|Community 1079]]
- [[_COMMUNITY_Community 1080|Community 1080]]
- [[_COMMUNITY_Community 1081|Community 1081]]
- [[_COMMUNITY_Community 1082|Community 1082]]
- [[_COMMUNITY_Community 1083|Community 1083]]
- [[_COMMUNITY_Community 1084|Community 1084]]
- [[_COMMUNITY_Community 1085|Community 1085]]
- [[_COMMUNITY_Community 1086|Community 1086]]
- [[_COMMUNITY_Community 1087|Community 1087]]
- [[_COMMUNITY_Community 1088|Community 1088]]
- [[_COMMUNITY_Community 1089|Community 1089]]
- [[_COMMUNITY_Community 1090|Community 1090]]
- [[_COMMUNITY_Community 1091|Community 1091]]
- [[_COMMUNITY_Community 1092|Community 1092]]
- [[_COMMUNITY_Community 1093|Community 1093]]
- [[_COMMUNITY_Community 1094|Community 1094]]
- [[_COMMUNITY_Community 1095|Community 1095]]
- [[_COMMUNITY_Community 1096|Community 1096]]
- [[_COMMUNITY_Community 1097|Community 1097]]
- [[_COMMUNITY_Community 1098|Community 1098]]
- [[_COMMUNITY_Community 1099|Community 1099]]
- [[_COMMUNITY_Community 1100|Community 1100]]
- [[_COMMUNITY_Community 1101|Community 1101]]
- [[_COMMUNITY_Community 1102|Community 1102]]
- [[_COMMUNITY_Community 1103|Community 1103]]
- [[_COMMUNITY_Community 1104|Community 1104]]
- [[_COMMUNITY_Community 1105|Community 1105]]
- [[_COMMUNITY_Community 1106|Community 1106]]
- [[_COMMUNITY_Community 1107|Community 1107]]
- [[_COMMUNITY_Community 1108|Community 1108]]
- [[_COMMUNITY_Community 1109|Community 1109]]
- [[_COMMUNITY_Community 1110|Community 1110]]
- [[_COMMUNITY_Community 1111|Community 1111]]
- [[_COMMUNITY_Community 1112|Community 1112]]
- [[_COMMUNITY_Community 1113|Community 1113]]
- [[_COMMUNITY_Community 1114|Community 1114]]
- [[_COMMUNITY_Community 1115|Community 1115]]
- [[_COMMUNITY_Community 1116|Community 1116]]
- [[_COMMUNITY_Community 1117|Community 1117]]
- [[_COMMUNITY_Community 1118|Community 1118]]
- [[_COMMUNITY_Community 1119|Community 1119]]
- [[_COMMUNITY_Community 1120|Community 1120]]
- [[_COMMUNITY_Community 1121|Community 1121]]
- [[_COMMUNITY_Community 1122|Community 1122]]
- [[_COMMUNITY_Community 1123|Community 1123]]
- [[_COMMUNITY_Community 1124|Community 1124]]
- [[_COMMUNITY_Community 1125|Community 1125]]
- [[_COMMUNITY_Community 1126|Community 1126]]
- [[_COMMUNITY_Community 1127|Community 1127]]
- [[_COMMUNITY_Community 1128|Community 1128]]
- [[_COMMUNITY_Community 1129|Community 1129]]
- [[_COMMUNITY_Community 1130|Community 1130]]
- [[_COMMUNITY_Community 1131|Community 1131]]
- [[_COMMUNITY_Community 1132|Community 1132]]
- [[_COMMUNITY_Community 1133|Community 1133]]
- [[_COMMUNITY_Community 1134|Community 1134]]
- [[_COMMUNITY_Community 1135|Community 1135]]
- [[_COMMUNITY_Community 1136|Community 1136]]
- [[_COMMUNITY_Community 1137|Community 1137]]
- [[_COMMUNITY_Community 1138|Community 1138]]
- [[_COMMUNITY_Community 1139|Community 1139]]
- [[_COMMUNITY_Community 1140|Community 1140]]
- [[_COMMUNITY_Community 1141|Community 1141]]
- [[_COMMUNITY_Community 1142|Community 1142]]
- [[_COMMUNITY_Community 1143|Community 1143]]
- [[_COMMUNITY_Community 1144|Community 1144]]
- [[_COMMUNITY_Community 1145|Community 1145]]
- [[_COMMUNITY_Community 1146|Community 1146]]
- [[_COMMUNITY_Community 1147|Community 1147]]
- [[_COMMUNITY_Community 1148|Community 1148]]
- [[_COMMUNITY_Community 1149|Community 1149]]
- [[_COMMUNITY_Community 1150|Community 1150]]
- [[_COMMUNITY_Community 1151|Community 1151]]
- [[_COMMUNITY_Community 1152|Community 1152]]
- [[_COMMUNITY_Community 1153|Community 1153]]
- [[_COMMUNITY_Community 1154|Community 1154]]
- [[_COMMUNITY_Community 1155|Community 1155]]
- [[_COMMUNITY_Community 1156|Community 1156]]
- [[_COMMUNITY_Community 1157|Community 1157]]
- [[_COMMUNITY_Community 1158|Community 1158]]
- [[_COMMUNITY_Community 1159|Community 1159]]
- [[_COMMUNITY_Community 1160|Community 1160]]
- [[_COMMUNITY_Community 1161|Community 1161]]
- [[_COMMUNITY_Community 1162|Community 1162]]
- [[_COMMUNITY_Community 1163|Community 1163]]
- [[_COMMUNITY_Community 1164|Community 1164]]
- [[_COMMUNITY_Community 1165|Community 1165]]
- [[_COMMUNITY_Community 1166|Community 1166]]
- [[_COMMUNITY_Community 1167|Community 1167]]
- [[_COMMUNITY_Community 1168|Community 1168]]
- [[_COMMUNITY_Community 1169|Community 1169]]
- [[_COMMUNITY_Community 1170|Community 1170]]
- [[_COMMUNITY_Community 1171|Community 1171]]
- [[_COMMUNITY_Community 1172|Community 1172]]
- [[_COMMUNITY_Community 1173|Community 1173]]
- [[_COMMUNITY_Community 1174|Community 1174]]
- [[_COMMUNITY_Community 1175|Community 1175]]
- [[_COMMUNITY_Community 1176|Community 1176]]
- [[_COMMUNITY_Community 1177|Community 1177]]
- [[_COMMUNITY_Community 1178|Community 1178]]
- [[_COMMUNITY_Community 1179|Community 1179]]
- [[_COMMUNITY_Community 1180|Community 1180]]
- [[_COMMUNITY_Community 1181|Community 1181]]
- [[_COMMUNITY_Community 1182|Community 1182]]
- [[_COMMUNITY_Community 1183|Community 1183]]
- [[_COMMUNITY_Community 1184|Community 1184]]
- [[_COMMUNITY_Community 1185|Community 1185]]
- [[_COMMUNITY_Community 1186|Community 1186]]
- [[_COMMUNITY_Community 1187|Community 1187]]
- [[_COMMUNITY_Community 1188|Community 1188]]
- [[_COMMUNITY_Community 1189|Community 1189]]
- [[_COMMUNITY_Community 1190|Community 1190]]
- [[_COMMUNITY_Community 1191|Community 1191]]
- [[_COMMUNITY_Community 1192|Community 1192]]
- [[_COMMUNITY_Community 1193|Community 1193]]
- [[_COMMUNITY_Community 1194|Community 1194]]
- [[_COMMUNITY_Community 1195|Community 1195]]
- [[_COMMUNITY_Community 1196|Community 1196]]
- [[_COMMUNITY_Community 1197|Community 1197]]
- [[_COMMUNITY_Community 1198|Community 1198]]
- [[_COMMUNITY_Community 1199|Community 1199]]
- [[_COMMUNITY_Community 1200|Community 1200]]
- [[_COMMUNITY_Community 1201|Community 1201]]
- [[_COMMUNITY_Community 1202|Community 1202]]
- [[_COMMUNITY_Community 1203|Community 1203]]
- [[_COMMUNITY_Community 1204|Community 1204]]
- [[_COMMUNITY_Community 1205|Community 1205]]
- [[_COMMUNITY_Community 1206|Community 1206]]
- [[_COMMUNITY_Community 1207|Community 1207]]
- [[_COMMUNITY_Community 1208|Community 1208]]
- [[_COMMUNITY_Community 1209|Community 1209]]
- [[_COMMUNITY_Community 1210|Community 1210]]
- [[_COMMUNITY_Community 1211|Community 1211]]
- [[_COMMUNITY_Community 1212|Community 1212]]
- [[_COMMUNITY_Community 1213|Community 1213]]
- [[_COMMUNITY_Community 1214|Community 1214]]
- [[_COMMUNITY_Community 1215|Community 1215]]
- [[_COMMUNITY_Community 1216|Community 1216]]
- [[_COMMUNITY_Community 1217|Community 1217]]
- [[_COMMUNITY_Community 1218|Community 1218]]
- [[_COMMUNITY_Community 1219|Community 1219]]
- [[_COMMUNITY_Community 1220|Community 1220]]
- [[_COMMUNITY_Community 1221|Community 1221]]
- [[_COMMUNITY_Community 1222|Community 1222]]
- [[_COMMUNITY_Community 1223|Community 1223]]
- [[_COMMUNITY_Community 1224|Community 1224]]
- [[_COMMUNITY_Community 1225|Community 1225]]
- [[_COMMUNITY_Community 1226|Community 1226]]
- [[_COMMUNITY_Community 1227|Community 1227]]
- [[_COMMUNITY_Community 1228|Community 1228]]
- [[_COMMUNITY_Community 1229|Community 1229]]
- [[_COMMUNITY_Community 1230|Community 1230]]
- [[_COMMUNITY_Community 1231|Community 1231]]
- [[_COMMUNITY_Community 1233|Community 1233]]
- [[_COMMUNITY_Community 1234|Community 1234]]
- [[_COMMUNITY_Community 1235|Community 1235]]
- [[_COMMUNITY_Community 1236|Community 1236]]
- [[_COMMUNITY_Community 1237|Community 1237]]
- [[_COMMUNITY_Community 1238|Community 1238]]
- [[_COMMUNITY_Community 1239|Community 1239]]
- [[_COMMUNITY_Community 1240|Community 1240]]
- [[_COMMUNITY_Community 1241|Community 1241]]
- [[_COMMUNITY_Community 1242|Community 1242]]
- [[_COMMUNITY_Community 1243|Community 1243]]
- [[_COMMUNITY_Community 1244|Community 1244]]
- [[_COMMUNITY_Community 1245|Community 1245]]
- [[_COMMUNITY_Community 1246|Community 1246]]
- [[_COMMUNITY_Community 1247|Community 1247]]
- [[_COMMUNITY_Community 1248|Community 1248]]
- [[_COMMUNITY_Community 1249|Community 1249]]
- [[_COMMUNITY_Community 1250|Community 1250]]
- [[_COMMUNITY_Community 1251|Community 1251]]
- [[_COMMUNITY_Community 1252|Community 1252]]
- [[_COMMUNITY_Community 1253|Community 1253]]
- [[_COMMUNITY_Community 1254|Community 1254]]
- [[_COMMUNITY_Community 1255|Community 1255]]
- [[_COMMUNITY_Community 1256|Community 1256]]
- [[_COMMUNITY_Community 1257|Community 1257]]
- [[_COMMUNITY_Community 1258|Community 1258]]
- [[_COMMUNITY_Community 1259|Community 1259]]
- [[_COMMUNITY_Community 1260|Community 1260]]
- [[_COMMUNITY_Community 1261|Community 1261]]
- [[_COMMUNITY_Community 1262|Community 1262]]
- [[_COMMUNITY_Community 1263|Community 1263]]
- [[_COMMUNITY_Community 1264|Community 1264]]
- [[_COMMUNITY_Community 1265|Community 1265]]
- [[_COMMUNITY_Community 1267|Community 1267]]
- [[_COMMUNITY_Community 1268|Community 1268]]
- [[_COMMUNITY_Community 1269|Community 1269]]
- [[_COMMUNITY_Community 1270|Community 1270]]
- [[_COMMUNITY_Community 1271|Community 1271]]
- [[_COMMUNITY_Community 1272|Community 1272]]
- [[_COMMUNITY_Community 1273|Community 1273]]
- [[_COMMUNITY_Community 1274|Community 1274]]
- [[_COMMUNITY_Community 1275|Community 1275]]
- [[_COMMUNITY_Community 1276|Community 1276]]
- [[_COMMUNITY_Community 1277|Community 1277]]
- [[_COMMUNITY_Community 1278|Community 1278]]
- [[_COMMUNITY_Community 1279|Community 1279]]
- [[_COMMUNITY_Community 1280|Community 1280]]
- [[_COMMUNITY_Community 1281|Community 1281]]
- [[_COMMUNITY_Community 1282|Community 1282]]
- [[_COMMUNITY_Community 1283|Community 1283]]
- [[_COMMUNITY_Community 1284|Community 1284]]
- [[_COMMUNITY_Community 1285|Community 1285]]
- [[_COMMUNITY_Community 1286|Community 1286]]
- [[_COMMUNITY_Community 1287|Community 1287]]
- [[_COMMUNITY_Community 1288|Community 1288]]
- [[_COMMUNITY_Community 1289|Community 1289]]
- [[_COMMUNITY_Community 1290|Community 1290]]
- [[_COMMUNITY_Community 1291|Community 1291]]
- [[_COMMUNITY_Community 1292|Community 1292]]
- [[_COMMUNITY_Community 1293|Community 1293]]
- [[_COMMUNITY_Community 1294|Community 1294]]
- [[_COMMUNITY_Community 1295|Community 1295]]
- [[_COMMUNITY_Community 1296|Community 1296]]
- [[_COMMUNITY_Community 1297|Community 1297]]
- [[_COMMUNITY_Community 1298|Community 1298]]
- [[_COMMUNITY_Community 1299|Community 1299]]
- [[_COMMUNITY_Community 1300|Community 1300]]
- [[_COMMUNITY_Community 1301|Community 1301]]
- [[_COMMUNITY_Community 1302|Community 1302]]
- [[_COMMUNITY_Community 1303|Community 1303]]
- [[_COMMUNITY_Community 1304|Community 1304]]
- [[_COMMUNITY_Community 1305|Community 1305]]
- [[_COMMUNITY_Community 1306|Community 1306]]
- [[_COMMUNITY_Community 1307|Community 1307]]
- [[_COMMUNITY_Community 1308|Community 1308]]
- [[_COMMUNITY_Community 1309|Community 1309]]
- [[_COMMUNITY_Community 1310|Community 1310]]
- [[_COMMUNITY_Community 1311|Community 1311]]
- [[_COMMUNITY_Community 1312|Community 1312]]
- [[_COMMUNITY_Community 1313|Community 1313]]
- [[_COMMUNITY_Community 1314|Community 1314]]
- [[_COMMUNITY_Community 1315|Community 1315]]
- [[_COMMUNITY_Community 1316|Community 1316]]
- [[_COMMUNITY_Community 1317|Community 1317]]
- [[_COMMUNITY_Community 1318|Community 1318]]
- [[_COMMUNITY_Community 1319|Community 1319]]
- [[_COMMUNITY_Community 1320|Community 1320]]
- [[_COMMUNITY_Community 1321|Community 1321]]
- [[_COMMUNITY_Community 1322|Community 1322]]
- [[_COMMUNITY_Community 1325|Community 1325]]
- [[_COMMUNITY_Community 1326|Community 1326]]
- [[_COMMUNITY_Community 1327|Community 1327]]
- [[_COMMUNITY_Community 1328|Community 1328]]
- [[_COMMUNITY_Community 1329|Community 1329]]
- [[_COMMUNITY_Community 1330|Community 1330]]
- [[_COMMUNITY_Community 1331|Community 1331]]
- [[_COMMUNITY_Community 1332|Community 1332]]
- [[_COMMUNITY_Community 1333|Community 1333]]
- [[_COMMUNITY_Community 1334|Community 1334]]
- [[_COMMUNITY_Community 1335|Community 1335]]
- [[_COMMUNITY_Community 1337|Community 1337]]
- [[_COMMUNITY_Community 1340|Community 1340]]
- [[_COMMUNITY_Community 1341|Community 1341]]
- [[_COMMUNITY_Community 1342|Community 1342]]
- [[_COMMUNITY_Community 1343|Community 1343]]
- [[_COMMUNITY_Community 1344|Community 1344]]
- [[_COMMUNITY_Community 1345|Community 1345]]
- [[_COMMUNITY_Community 1346|Community 1346]]
- [[_COMMUNITY_Community 1347|Community 1347]]
- [[_COMMUNITY_Community 1348|Community 1348]]
- [[_COMMUNITY_Community 1349|Community 1349]]
- [[_COMMUNITY_Community 1350|Community 1350]]
- [[_COMMUNITY_Community 1351|Community 1351]]
- [[_COMMUNITY_Community 1352|Community 1352]]
- [[_COMMUNITY_Community 1353|Community 1353]]
- [[_COMMUNITY_Community 1354|Community 1354]]
- [[_COMMUNITY_Community 1355|Community 1355]]
- [[_COMMUNITY_Community 1356|Community 1356]]
- [[_COMMUNITY_Community 1357|Community 1357]]
- [[_COMMUNITY_Community 1358|Community 1358]]
- [[_COMMUNITY_Community 1359|Community 1359]]
- [[_COMMUNITY_Community 1360|Community 1360]]
- [[_COMMUNITY_Community 1361|Community 1361]]
- [[_COMMUNITY_Community 1362|Community 1362]]
- [[_COMMUNITY_Community 1363|Community 1363]]
- [[_COMMUNITY_Community 1364|Community 1364]]
- [[_COMMUNITY_Community 1365|Community 1365]]
- [[_COMMUNITY_Community 1366|Community 1366]]
- [[_COMMUNITY_Community 1367|Community 1367]]
- [[_COMMUNITY_Community 1368|Community 1368]]
- [[_COMMUNITY_Community 1369|Community 1369]]
- [[_COMMUNITY_Community 1370|Community 1370]]
- [[_COMMUNITY_Community 1371|Community 1371]]
- [[_COMMUNITY_Community 1373|Community 1373]]
- [[_COMMUNITY_Community 1374|Community 1374]]
- [[_COMMUNITY_Community 1379|Community 1379]]
- [[_COMMUNITY_Community 1380|Community 1380]]
- [[_COMMUNITY_Community 1381|Community 1381]]
- [[_COMMUNITY_Community 1382|Community 1382]]
- [[_COMMUNITY_Community 1383|Community 1383]]
- [[_COMMUNITY_Community 1384|Community 1384]]
- [[_COMMUNITY_Community 1385|Community 1385]]
- [[_COMMUNITY_Community 1386|Community 1386]]
- [[_COMMUNITY_Community 1387|Community 1387]]
- [[_COMMUNITY_Community 1388|Community 1388]]
- [[_COMMUNITY_Community 1389|Community 1389]]
- [[_COMMUNITY_Community 1390|Community 1390]]
- [[_COMMUNITY_Community 1392|Community 1392]]
- [[_COMMUNITY_Community 1393|Community 1393]]
- [[_COMMUNITY_Community 1394|Community 1394]]
- [[_COMMUNITY_Community 1395|Community 1395]]
- [[_COMMUNITY_Community 1396|Community 1396]]
- [[_COMMUNITY_Community 1397|Community 1397]]
- [[_COMMUNITY_Community 1398|Community 1398]]
- [[_COMMUNITY_Community 1399|Community 1399]]
- [[_COMMUNITY_Community 1400|Community 1400]]
- [[_COMMUNITY_Community 1401|Community 1401]]
- [[_COMMUNITY_Community 1402|Community 1402]]
- [[_COMMUNITY_Community 1403|Community 1403]]
- [[_COMMUNITY_Community 1404|Community 1404]]
- [[_COMMUNITY_Community 1405|Community 1405]]
- [[_COMMUNITY_Community 1406|Community 1406]]
- [[_COMMUNITY_Community 1407|Community 1407]]
- [[_COMMUNITY_Community 1408|Community 1408]]
- [[_COMMUNITY_Community 1409|Community 1409]]
- [[_COMMUNITY_Community 1410|Community 1410]]
- [[_COMMUNITY_Community 1411|Community 1411]]
- [[_COMMUNITY_Community 1412|Community 1412]]
- [[_COMMUNITY_Community 1413|Community 1413]]
- [[_COMMUNITY_Community 1414|Community 1414]]
- [[_COMMUNITY_Community 1415|Community 1415]]
- [[_COMMUNITY_Community 1416|Community 1416]]
- [[_COMMUNITY_Community 1417|Community 1417]]
- [[_COMMUNITY_Community 1418|Community 1418]]
- [[_COMMUNITY_Community 1419|Community 1419]]
- [[_COMMUNITY_Community 1420|Community 1420]]
- [[_COMMUNITY_Community 1421|Community 1421]]
- [[_COMMUNITY_Community 1422|Community 1422]]
- [[_COMMUNITY_Community 1423|Community 1423]]
- [[_COMMUNITY_Community 1424|Community 1424]]
- [[_COMMUNITY_Community 1425|Community 1425]]
- [[_COMMUNITY_Community 1426|Community 1426]]
- [[_COMMUNITY_Community 1427|Community 1427]]
- [[_COMMUNITY_Community 1429|Community 1429]]
- [[_COMMUNITY_Community 1430|Community 1430]]
- [[_COMMUNITY_Community 1431|Community 1431]]
- [[_COMMUNITY_Community 1432|Community 1432]]
- [[_COMMUNITY_Community 1433|Community 1433]]
- [[_COMMUNITY_Community 1434|Community 1434]]
- [[_COMMUNITY_Community 1435|Community 1435]]
- [[_COMMUNITY_Community 1436|Community 1436]]
- [[_COMMUNITY_Community 1437|Community 1437]]
- [[_COMMUNITY_Community 1438|Community 1438]]
- [[_COMMUNITY_Community 1439|Community 1439]]
- [[_COMMUNITY_Community 1440|Community 1440]]
- [[_COMMUNITY_Community 1441|Community 1441]]
- [[_COMMUNITY_Community 1442|Community 1442]]
- [[_COMMUNITY_Community 1443|Community 1443]]
- [[_COMMUNITY_Community 1444|Community 1444]]
- [[_COMMUNITY_Community 1445|Community 1445]]
- [[_COMMUNITY_Community 1446|Community 1446]]
- [[_COMMUNITY_Community 1447|Community 1447]]
- [[_COMMUNITY_Community 1450|Community 1450]]
- [[_COMMUNITY_Community 1451|Community 1451]]
- [[_COMMUNITY_Community 1452|Community 1452]]
- [[_COMMUNITY_Community 1453|Community 1453]]
- [[_COMMUNITY_Community 1454|Community 1454]]
- [[_COMMUNITY_Community 1455|Community 1455]]
- [[_COMMUNITY_Community 1456|Community 1456]]
- [[_COMMUNITY_Community 1457|Community 1457]]
- [[_COMMUNITY_Community 1458|Community 1458]]
- [[_COMMUNITY_Community 1459|Community 1459]]
- [[_COMMUNITY_Community 1462|Community 1462]]
- [[_COMMUNITY_Community 1463|Community 1463]]
- [[_COMMUNITY_Community 1464|Community 1464]]
- [[_COMMUNITY_Community 1465|Community 1465]]
- [[_COMMUNITY_Community 1466|Community 1466]]
- [[_COMMUNITY_Community 1467|Community 1467]]
- [[_COMMUNITY_Community 1468|Community 1468]]
- [[_COMMUNITY_Community 1469|Community 1469]]
- [[_COMMUNITY_Community 1470|Community 1470]]
- [[_COMMUNITY_Community 1471|Community 1471]]
- [[_COMMUNITY_Community 1472|Community 1472]]
- [[_COMMUNITY_Community 1473|Community 1473]]
- [[_COMMUNITY_Community 1474|Community 1474]]
- [[_COMMUNITY_Community 1475|Community 1475]]
- [[_COMMUNITY_Community 1476|Community 1476]]
- [[_COMMUNITY_Community 1478|Community 1478]]
- [[_COMMUNITY_Community 1479|Community 1479]]
- [[_COMMUNITY_Community 1480|Community 1480]]
- [[_COMMUNITY_Community 1481|Community 1481]]
- [[_COMMUNITY_Community 1482|Community 1482]]
- [[_COMMUNITY_Community 1483|Community 1483]]
- [[_COMMUNITY_Community 1484|Community 1484]]
- [[_COMMUNITY_Community 1485|Community 1485]]
- [[_COMMUNITY_Community 1486|Community 1486]]
- [[_COMMUNITY_Community 1488|Community 1488]]
- [[_COMMUNITY_Community 1490|Community 1490]]
- [[_COMMUNITY_Community 1491|Community 1491]]
- [[_COMMUNITY_Community 1494|Community 1494]]
- [[_COMMUNITY_Community 1495|Community 1495]]
- [[_COMMUNITY_Community 1496|Community 1496]]
- [[_COMMUNITY_Community 1497|Community 1497]]
- [[_COMMUNITY_Community 1498|Community 1498]]
- [[_COMMUNITY_Community 1509|Community 1509]]
- [[_COMMUNITY_Community 1510|Community 1510]]
- [[_COMMUNITY_Community 1511|Community 1511]]
- [[_COMMUNITY_Community 1512|Community 1512]]
- [[_COMMUNITY_Community 1513|Community 1513]]
- [[_COMMUNITY_Community 1514|Community 1514]]
- [[_COMMUNITY_Community 1515|Community 1515]]
- [[_COMMUNITY_Community 1516|Community 1516]]
- [[_COMMUNITY_Community 1517|Community 1517]]
- [[_COMMUNITY_Community 1518|Community 1518]]
- [[_COMMUNITY_Community 1519|Community 1519]]
- [[_COMMUNITY_Community 1520|Community 1520]]
- [[_COMMUNITY_Community 1523|Community 1523]]
- [[_COMMUNITY_Community 1525|Community 1525]]
- [[_COMMUNITY_Community 1526|Community 1526]]
- [[_COMMUNITY_Community 1529|Community 1529]]
- [[_COMMUNITY_Community 1531|Community 1531]]
- [[_COMMUNITY_Community 1532|Community 1532]]
- [[_COMMUNITY_Community 1533|Community 1533]]
- [[_COMMUNITY_Community 1534|Community 1534]]
- [[_COMMUNITY_Community 1535|Community 1535]]
- [[_COMMUNITY_Community 1537|Community 1537]]
- [[_COMMUNITY_Community 1538|Community 1538]]
- [[_COMMUNITY_Community 1540|Community 1540]]
- [[_COMMUNITY_Community 1541|Community 1541]]
- [[_COMMUNITY_Community 1542|Community 1542]]
- [[_COMMUNITY_Community 1543|Community 1543]]
- [[_COMMUNITY_Community 1546|Community 1546]]
- [[_COMMUNITY_Community 1547|Community 1547]]
- [[_COMMUNITY_Community 1548|Community 1548]]
- [[_COMMUNITY_Community 1551|Community 1551]]
- [[_COMMUNITY_Community 1553|Community 1553]]
- [[_COMMUNITY_Community 1556|Community 1556]]
- [[_COMMUNITY_Community 1557|Community 1557]]
- [[_COMMUNITY_Community 1559|Community 1559]]
- [[_COMMUNITY_Community 1561|Community 1561]]
- [[_COMMUNITY_Community 1568|Community 1568]]
- [[_COMMUNITY_Community 1569|Community 1569]]
- [[_COMMUNITY_Community 1571|Community 1571]]
- [[_COMMUNITY_Community 1576|Community 1576]]
- [[_COMMUNITY_Community 1577|Community 1577]]
- [[_COMMUNITY_Community 1578|Community 1578]]
- [[_COMMUNITY_Community 1579|Community 1579]]
- [[_COMMUNITY_Community 1619|Community 1619]]
- [[_COMMUNITY_Community 1620|Community 1620]]
- [[_COMMUNITY_Community 1621|Community 1621]]
- [[_COMMUNITY_Community 1622|Community 1622]]
- [[_COMMUNITY_Community 1623|Community 1623]]
- [[_COMMUNITY_Community 1624|Community 1624]]
- [[_COMMUNITY_Community 1626|Community 1626]]
- [[_COMMUNITY_Community 1627|Community 1627]]
- [[_COMMUNITY_Community 1628|Community 1628]]
- [[_COMMUNITY_Community 1629|Community 1629]]
- [[_COMMUNITY_Community 1630|Community 1630]]
- [[_COMMUNITY_Community 1631|Community 1631]]
- [[_COMMUNITY_Community 1632|Community 1632]]
- [[_COMMUNITY_Community 1633|Community 1633]]
- [[_COMMUNITY_Community 1634|Community 1634]]
- [[_COMMUNITY_Community 1635|Community 1635]]
- [[_COMMUNITY_Community 1636|Community 1636]]
- [[_COMMUNITY_Community 1637|Community 1637]]
- [[_COMMUNITY_Community 1638|Community 1638]]
- [[_COMMUNITY_Community 1639|Community 1639]]
- [[_COMMUNITY_Community 1640|Community 1640]]
- [[_COMMUNITY_Community 1641|Community 1641]]
- [[_COMMUNITY_Community 1642|Community 1642]]
- [[_COMMUNITY_Community 1643|Community 1643]]
- [[_COMMUNITY_Community 1644|Community 1644]]
- [[_COMMUNITY_Community 1645|Community 1645]]
- [[_COMMUNITY_Community 1646|Community 1646]]
- [[_COMMUNITY_Community 1647|Community 1647]]
- [[_COMMUNITY_Community 1648|Community 1648]]
- [[_COMMUNITY_Community 1649|Community 1649]]
- [[_COMMUNITY_Community 1650|Community 1650]]
- [[_COMMUNITY_Community 1651|Community 1651]]
- [[_COMMUNITY_Community 1652|Community 1652]]
- [[_COMMUNITY_Community 1653|Community 1653]]
- [[_COMMUNITY_Community 1654|Community 1654]]
- [[_COMMUNITY_Community 1656|Community 1656]]
- [[_COMMUNITY_Community 1657|Community 1657]]
- [[_COMMUNITY_Community 1658|Community 1658]]
- [[_COMMUNITY_Community 1659|Community 1659]]
- [[_COMMUNITY_Community 1660|Community 1660]]
- [[_COMMUNITY_Community 1661|Community 1661]]
- [[_COMMUNITY_Community 1662|Community 1662]]
- [[_COMMUNITY_Community 1663|Community 1663]]
- [[_COMMUNITY_Community 1664|Community 1664]]
- [[_COMMUNITY_Community 1665|Community 1665]]
- [[_COMMUNITY_Community 1666|Community 1666]]
- [[_COMMUNITY_Community 1667|Community 1667]]
- [[_COMMUNITY_Community 1668|Community 1668]]
- [[_COMMUNITY_Community 1670|Community 1670]]
- [[_COMMUNITY_Community 1671|Community 1671]]
- [[_COMMUNITY_Community 1674|Community 1674]]
- [[_COMMUNITY_Community 1676|Community 1676]]
- [[_COMMUNITY_Community 1678|Community 1678]]
- [[_COMMUNITY_Community 1688|Community 1688]]
- [[_COMMUNITY_Community 1689|Community 1689]]
- [[_COMMUNITY_Community 1691|Community 1691]]
- [[_COMMUNITY_Community 1697|Community 1697]]
- [[_COMMUNITY_Community 1703|Community 1703]]
- [[_COMMUNITY_Community 1704|Community 1704]]
- [[_COMMUNITY_Community 1705|Community 1705]]
- [[_COMMUNITY_Community 1712|Community 1712]]
- [[_COMMUNITY_Community 1714|Community 1714]]
- [[_COMMUNITY_Community 1715|Community 1715]]
- [[_COMMUNITY_Community 1717|Community 1717]]
- [[_COMMUNITY_Community 1726|Community 1726]]
- [[_COMMUNITY_Community 1727|Community 1727]]
- [[_COMMUNITY_Community 1728|Community 1728]]
- [[_COMMUNITY_Community 1729|Community 1729]]
- [[_COMMUNITY_Community 1730|Community 1730]]
- [[_COMMUNITY_Community 1731|Community 1731]]
- [[_COMMUNITY_Community 1732|Community 1732]]
- [[_COMMUNITY_Community 1733|Community 1733]]
- [[_COMMUNITY_Community 1735|Community 1735]]
- [[_COMMUNITY_Community 1738|Community 1738]]
- [[_COMMUNITY_Community 1739|Community 1739]]
- [[_COMMUNITY_Community 1740|Community 1740]]
- [[_COMMUNITY_Community 1741|Community 1741]]
- [[_COMMUNITY_Community 1742|Community 1742]]
- [[_COMMUNITY_Community 1743|Community 1743]]
- [[_COMMUNITY_Community 1744|Community 1744]]
- [[_COMMUNITY_Community 1745|Community 1745]]
- [[_COMMUNITY_Community 1746|Community 1746]]
- [[_COMMUNITY_Community 1747|Community 1747]]
- [[_COMMUNITY_Community 1748|Community 1748]]
- [[_COMMUNITY_Community 1749|Community 1749]]
- [[_COMMUNITY_Community 1750|Community 1750]]
- [[_COMMUNITY_Community 1751|Community 1751]]
- [[_COMMUNITY_Community 1752|Community 1752]]
- [[_COMMUNITY_Community 1753|Community 1753]]
- [[_COMMUNITY_Community 1754|Community 1754]]
- [[_COMMUNITY_Community 1755|Community 1755]]
- [[_COMMUNITY_Community 1756|Community 1756]]
- [[_COMMUNITY_Community 1757|Community 1757]]
- [[_COMMUNITY_Community 1758|Community 1758]]
- [[_COMMUNITY_Community 1759|Community 1759]]
- [[_COMMUNITY_Community 1760|Community 1760]]
- [[_COMMUNITY_Community 1761|Community 1761]]
- [[_COMMUNITY_Community 1762|Community 1762]]
- [[_COMMUNITY_Community 1763|Community 1763]]
- [[_COMMUNITY_Community 1764|Community 1764]]
- [[_COMMUNITY_Community 1765|Community 1765]]
- [[_COMMUNITY_Community 1766|Community 1766]]
- [[_COMMUNITY_Community 1767|Community 1767]]
- [[_COMMUNITY_Community 1768|Community 1768]]
- [[_COMMUNITY_Community 1769|Community 1769]]
- [[_COMMUNITY_Community 1770|Community 1770]]
- [[_COMMUNITY_Community 1771|Community 1771]]
- [[_COMMUNITY_Community 1772|Community 1772]]
- [[_COMMUNITY_Community 1773|Community 1773]]
- [[_COMMUNITY_Community 1774|Community 1774]]
- [[_COMMUNITY_Community 1775|Community 1775]]
- [[_COMMUNITY_Community 1776|Community 1776]]
- [[_COMMUNITY_Community 1777|Community 1777]]
- [[_COMMUNITY_Community 1778|Community 1778]]
- [[_COMMUNITY_Community 1779|Community 1779]]
- [[_COMMUNITY_Community 1780|Community 1780]]
- [[_COMMUNITY_Community 1781|Community 1781]]
- [[_COMMUNITY_Community 1782|Community 1782]]
- [[_COMMUNITY_Community 1783|Community 1783]]
- [[_COMMUNITY_Community 1784|Community 1784]]
- [[_COMMUNITY_Community 1785|Community 1785]]
- [[_COMMUNITY_Community 1786|Community 1786]]
- [[_COMMUNITY_Community 1787|Community 1787]]
- [[_COMMUNITY_Community 1788|Community 1788]]
- [[_COMMUNITY_Community 1789|Community 1789]]
- [[_COMMUNITY_Community 1790|Community 1790]]
- [[_COMMUNITY_Community 1791|Community 1791]]
- [[_COMMUNITY_Community 1792|Community 1792]]
- [[_COMMUNITY_Community 1794|Community 1794]]
- [[_COMMUNITY_Community 1795|Community 1795]]
- [[_COMMUNITY_Community 1796|Community 1796]]
- [[_COMMUNITY_Community 1797|Community 1797]]
- [[_COMMUNITY_Community 1798|Community 1798]]
- [[_COMMUNITY_Community 1799|Community 1799]]
- [[_COMMUNITY_Community 1800|Community 1800]]
- [[_COMMUNITY_Community 1801|Community 1801]]
- [[_COMMUNITY_Community 1802|Community 1802]]
- [[_COMMUNITY_Community 1803|Community 1803]]
- [[_COMMUNITY_Community 1804|Community 1804]]
- [[_COMMUNITY_Community 1805|Community 1805]]
- [[_COMMUNITY_Community 1806|Community 1806]]
- [[_COMMUNITY_Community 1807|Community 1807]]
- [[_COMMUNITY_Community 1808|Community 1808]]
- [[_COMMUNITY_Community 1809|Community 1809]]
- [[_COMMUNITY_Community 1810|Community 1810]]
- [[_COMMUNITY_Community 1811|Community 1811]]
- [[_COMMUNITY_Community 1812|Community 1812]]
- [[_COMMUNITY_Community 1813|Community 1813]]
- [[_COMMUNITY_Community 1814|Community 1814]]
- [[_COMMUNITY_Community 1815|Community 1815]]
- [[_COMMUNITY_Community 1816|Community 1816]]
- [[_COMMUNITY_Community 1818|Community 1818]]
- [[_COMMUNITY_Community 1819|Community 1819]]
- [[_COMMUNITY_Community 1820|Community 1820]]
- [[_COMMUNITY_Community 1821|Community 1821]]
- [[_COMMUNITY_Community 1822|Community 1822]]
- [[_COMMUNITY_Community 1823|Community 1823]]
- [[_COMMUNITY_Community 1824|Community 1824]]
- [[_COMMUNITY_Community 1825|Community 1825]]
- [[_COMMUNITY_Community 1826|Community 1826]]
- [[_COMMUNITY_Community 1827|Community 1827]]
- [[_COMMUNITY_Community 1828|Community 1828]]
- [[_COMMUNITY_Community 1829|Community 1829]]
- [[_COMMUNITY_Community 1830|Community 1830]]
- [[_COMMUNITY_Community 1831|Community 1831]]
- [[_COMMUNITY_Community 1832|Community 1832]]
- [[_COMMUNITY_Community 1833|Community 1833]]
- [[_COMMUNITY_Community 1834|Community 1834]]
- [[_COMMUNITY_Community 1835|Community 1835]]
- [[_COMMUNITY_Community 1836|Community 1836]]
- [[_COMMUNITY_Community 1837|Community 1837]]
- [[_COMMUNITY_Community 1838|Community 1838]]
- [[_COMMUNITY_Community 1840|Community 1840]]
- [[_COMMUNITY_Community 1843|Community 1843]]
- [[_COMMUNITY_Community 1844|Community 1844]]
- [[_COMMUNITY_Community 1845|Community 1845]]
- [[_COMMUNITY_Community 1846|Community 1846]]
- [[_COMMUNITY_Community 1847|Community 1847]]
- [[_COMMUNITY_Community 1848|Community 1848]]
- [[_COMMUNITY_Community 1849|Community 1849]]
- [[_COMMUNITY_Community 1850|Community 1850]]
- [[_COMMUNITY_Community 1851|Community 1851]]
- [[_COMMUNITY_Community 1852|Community 1852]]
- [[_COMMUNITY_Community 1853|Community 1853]]
- [[_COMMUNITY_Community 1854|Community 1854]]
- [[_COMMUNITY_Community 1855|Community 1855]]
- [[_COMMUNITY_Community 1856|Community 1856]]
- [[_COMMUNITY_Community 1857|Community 1857]]
- [[_COMMUNITY_Community 1858|Community 1858]]
- [[_COMMUNITY_Community 1859|Community 1859]]
- [[_COMMUNITY_Community 1860|Community 1860]]
- [[_COMMUNITY_Community 1861|Community 1861]]
- [[_COMMUNITY_Community 1862|Community 1862]]
- [[_COMMUNITY_Community 1863|Community 1863]]
- [[_COMMUNITY_Community 1864|Community 1864]]
- [[_COMMUNITY_Community 1865|Community 1865]]
- [[_COMMUNITY_Community 1866|Community 1866]]
- [[_COMMUNITY_Community 1867|Community 1867]]
- [[_COMMUNITY_Community 1868|Community 1868]]
- [[_COMMUNITY_Community 1869|Community 1869]]
- [[_COMMUNITY_Community 1870|Community 1870]]
- [[_COMMUNITY_Community 1871|Community 1871]]
- [[_COMMUNITY_Community 1872|Community 1872]]
- [[_COMMUNITY_Community 1873|Community 1873]]
- [[_COMMUNITY_Community 1874|Community 1874]]
- [[_COMMUNITY_Community 1878|Community 1878]]
- [[_COMMUNITY_Community 1879|Community 1879]]
- [[_COMMUNITY_Community 1880|Community 1880]]
- [[_COMMUNITY_Community 1881|Community 1881]]
- [[_COMMUNITY_Community 1882|Community 1882]]
- [[_COMMUNITY_Community 1883|Community 1883]]
- [[_COMMUNITY_Community 1885|Community 1885]]
- [[_COMMUNITY_Community 1886|Community 1886]]
- [[_COMMUNITY_Community 1887|Community 1887]]
- [[_COMMUNITY_Community 1888|Community 1888]]
- [[_COMMUNITY_Community 1889|Community 1889]]
- [[_COMMUNITY_Community 1890|Community 1890]]
- [[_COMMUNITY_Community 1891|Community 1891]]
- [[_COMMUNITY_Community 1892|Community 1892]]
- [[_COMMUNITY_Community 1893|Community 1893]]
- [[_COMMUNITY_Community 1894|Community 1894]]
- [[_COMMUNITY_Community 1895|Community 1895]]
- [[_COMMUNITY_Community 1896|Community 1896]]
- [[_COMMUNITY_Community 1897|Community 1897]]
- [[_COMMUNITY_Community 1898|Community 1898]]
- [[_COMMUNITY_Community 1899|Community 1899]]
- [[_COMMUNITY_Community 1900|Community 1900]]
- [[_COMMUNITY_Community 1901|Community 1901]]
- [[_COMMUNITY_Community 1902|Community 1902]]
- [[_COMMUNITY_Community 1903|Community 1903]]
- [[_COMMUNITY_Community 1904|Community 1904]]
- [[_COMMUNITY_Community 1905|Community 1905]]
- [[_COMMUNITY_Community 1906|Community 1906]]
- [[_COMMUNITY_Community 1907|Community 1907]]
- [[_COMMUNITY_Community 1908|Community 1908]]
- [[_COMMUNITY_Community 1909|Community 1909]]
- [[_COMMUNITY_Community 1910|Community 1910]]
- [[_COMMUNITY_Community 1911|Community 1911]]
- [[_COMMUNITY_Community 1912|Community 1912]]
- [[_COMMUNITY_Community 1914|Community 1914]]
- [[_COMMUNITY_Community 1915|Community 1915]]
- [[_COMMUNITY_Community 1916|Community 1916]]
- [[_COMMUNITY_Community 1917|Community 1917]]
- [[_COMMUNITY_Community 1918|Community 1918]]
- [[_COMMUNITY_Community 1919|Community 1919]]
- [[_COMMUNITY_Community 1920|Community 1920]]
- [[_COMMUNITY_Community 1921|Community 1921]]
- [[_COMMUNITY_Community 1922|Community 1922]]
- [[_COMMUNITY_Community 1923|Community 1923]]
- [[_COMMUNITY_Community 1924|Community 1924]]
- [[_COMMUNITY_Community 1925|Community 1925]]
- [[_COMMUNITY_Community 1926|Community 1926]]
- [[_COMMUNITY_Community 1927|Community 1927]]
- [[_COMMUNITY_Community 1928|Community 1928]]
- [[_COMMUNITY_Community 1929|Community 1929]]
- [[_COMMUNITY_Community 1930|Community 1930]]
- [[_COMMUNITY_Community 1931|Community 1931]]
- [[_COMMUNITY_Community 1932|Community 1932]]
- [[_COMMUNITY_Community 1933|Community 1933]]
- [[_COMMUNITY_Community 1934|Community 1934]]
- [[_COMMUNITY_Community 1935|Community 1935]]
- [[_COMMUNITY_Community 1936|Community 1936]]
- [[_COMMUNITY_Community 1937|Community 1937]]
- [[_COMMUNITY_Community 1939|Community 1939]]
- [[_COMMUNITY_Community 1944|Community 1944]]
- [[_COMMUNITY_Community 1945|Community 1945]]
- [[_COMMUNITY_Community 1946|Community 1946]]
- [[_COMMUNITY_Community 1947|Community 1947]]
- [[_COMMUNITY_Community 1948|Community 1948]]
- [[_COMMUNITY_Community 1949|Community 1949]]
- [[_COMMUNITY_Community 1950|Community 1950]]
- [[_COMMUNITY_Community 1951|Community 1951]]
- [[_COMMUNITY_Community 1954|Community 1954]]
- [[_COMMUNITY_Community 1955|Community 1955]]
- [[_COMMUNITY_Community 1956|Community 1956]]
- [[_COMMUNITY_Community 1958|Community 1958]]
- [[_COMMUNITY_Community 1959|Community 1959]]
- [[_COMMUNITY_Community 1961|Community 1961]]
- [[_COMMUNITY_Community 1962|Community 1962]]
- [[_COMMUNITY_Community 1963|Community 1963]]
- [[_COMMUNITY_Community 1964|Community 1964]]
- [[_COMMUNITY_Community 1966|Community 1966]]
- [[_COMMUNITY_Community 1967|Community 1967]]
- [[_COMMUNITY_Community 1968|Community 1968]]
- [[_COMMUNITY_Community 1969|Community 1969]]
- [[_COMMUNITY_Community 1970|Community 1970]]
- [[_COMMUNITY_Community 1971|Community 1971]]
- [[_COMMUNITY_Community 1972|Community 1972]]
- [[_COMMUNITY_Community 1973|Community 1973]]
- [[_COMMUNITY_Community 1974|Community 1974]]
- [[_COMMUNITY_Community 1979|Community 1979]]
- [[_COMMUNITY_Community 1980|Community 1980]]
- [[_COMMUNITY_Community 1981|Community 1981]]
- [[_COMMUNITY_Community 1982|Community 1982]]
- [[_COMMUNITY_Community 1983|Community 1983]]
- [[_COMMUNITY_Community 1985|Community 1985]]
- [[_COMMUNITY_Community 1986|Community 1986]]
- [[_COMMUNITY_Community 1987|Community 1987]]
- [[_COMMUNITY_Community 1988|Community 1988]]
- [[_COMMUNITY_Community 1989|Community 1989]]
- [[_COMMUNITY_Community 1990|Community 1990]]
- [[_COMMUNITY_Community 1991|Community 1991]]
- [[_COMMUNITY_Community 1992|Community 1992]]
- [[_COMMUNITY_Community 1994|Community 1994]]
- [[_COMMUNITY_Community 1995|Community 1995]]
- [[_COMMUNITY_Community 1996|Community 1996]]
- [[_COMMUNITY_Community 1997|Community 1997]]
- [[_COMMUNITY_Community 1998|Community 1998]]
- [[_COMMUNITY_Community 1999|Community 1999]]
- [[_COMMUNITY_Community 2000|Community 2000]]
- [[_COMMUNITY_Community 2001|Community 2001]]
- [[_COMMUNITY_Community 2002|Community 2002]]
- [[_COMMUNITY_Community 2003|Community 2003]]
- [[_COMMUNITY_Community 2004|Community 2004]]
- [[_COMMUNITY_Community 2005|Community 2005]]
- [[_COMMUNITY_Community 2006|Community 2006]]
- [[_COMMUNITY_Community 2007|Community 2007]]
- [[_COMMUNITY_Community 2008|Community 2008]]
- [[_COMMUNITY_Community 2009|Community 2009]]
- [[_COMMUNITY_Community 2010|Community 2010]]
- [[_COMMUNITY_Community 2011|Community 2011]]
- [[_COMMUNITY_Community 2012|Community 2012]]
- [[_COMMUNITY_Community 2013|Community 2013]]
- [[_COMMUNITY_Community 2014|Community 2014]]
- [[_COMMUNITY_Community 2015|Community 2015]]
- [[_COMMUNITY_Community 2016|Community 2016]]
- [[_COMMUNITY_Community 2018|Community 2018]]
- [[_COMMUNITY_Community 2020|Community 2020]]
- [[_COMMUNITY_Community 2021|Community 2021]]
- [[_COMMUNITY_Community 2022|Community 2022]]
- [[_COMMUNITY_Community 2025|Community 2025]]
- [[_COMMUNITY_Community 2026|Community 2026]]
- [[_COMMUNITY_Community 2027|Community 2027]]
- [[_COMMUNITY_Community 2028|Community 2028]]
- [[_COMMUNITY_Community 2029|Community 2029]]
- [[_COMMUNITY_Community 2030|Community 2030]]
- [[_COMMUNITY_Community 2031|Community 2031]]
- [[_COMMUNITY_Community 2032|Community 2032]]
- [[_COMMUNITY_Community 2033|Community 2033]]
- [[_COMMUNITY_Community 2034|Community 2034]]
- [[_COMMUNITY_Community 2035|Community 2035]]
- [[_COMMUNITY_Community 2036|Community 2036]]
- [[_COMMUNITY_Community 2037|Community 2037]]
- [[_COMMUNITY_Community 2038|Community 2038]]
- [[_COMMUNITY_Community 2039|Community 2039]]
- [[_COMMUNITY_Community 2042|Community 2042]]
- [[_COMMUNITY_Community 2045|Community 2045]]
- [[_COMMUNITY_Community 2046|Community 2046]]
- [[_COMMUNITY_Community 2047|Community 2047]]
- [[_COMMUNITY_Community 2048|Community 2048]]
- [[_COMMUNITY_Community 2049|Community 2049]]
- [[_COMMUNITY_Community 2050|Community 2050]]
- [[_COMMUNITY_Community 2051|Community 2051]]
- [[_COMMUNITY_Community 2052|Community 2052]]
- [[_COMMUNITY_Community 2054|Community 2054]]
- [[_COMMUNITY_Community 2055|Community 2055]]
- [[_COMMUNITY_Community 2056|Community 2056]]
- [[_COMMUNITY_Community 2058|Community 2058]]
- [[_COMMUNITY_Community 2059|Community 2059]]
- [[_COMMUNITY_Community 2060|Community 2060]]
- [[_COMMUNITY_Community 2061|Community 2061]]
- [[_COMMUNITY_Community 2063|Community 2063]]
- [[_COMMUNITY_Community 2064|Community 2064]]
- [[_COMMUNITY_Community 2065|Community 2065]]
- [[_COMMUNITY_Community 2066|Community 2066]]
- [[_COMMUNITY_Community 2077|Community 2077]]
- [[_COMMUNITY_Community 2078|Community 2078]]
- [[_COMMUNITY_Community 2083|Community 2083]]
- [[_COMMUNITY_Community 2089|Community 2089]]

## God Nodes (most connected - your core abstractions)
1. `Communities (2099 total, 583 thin omitted)` - 1263 edges
2. `Communities (2105 total, 599 thin omitted)` - 1254 edges
3. `Communities (2077 total, 573 thin omitted)` - 1251 edges
4. `Communities (2073 total, 589 thin omitted)` - 1238 edges
5. `Communities (2016 total, 576 thin omitted)` - 1201 edges
6. `Communities (2027 total, 587 thin omitted)` - 1186 edges
7. `Communities (1992 total, 588 thin omitted)` - 1174 edges
8. `Communities (1979 total, 590 thin omitted)` - 1158 edges
9. `Communities (1979 total, 600 thin omitted)` - 1154 edges
10. `Communities (1974 total, 601 thin omitted)` - 1149 edges

## Surprising Connections (you probably didn't know these)
- `_dmm_config_univariate()` --calls--> `DMMConfig`  [INFERRED]
  theory/figures/ch02/_fig42.py → docs/guide/moments.md
- `EARLY_EXPANSION()` --calls--> `Value`  [INFERRED]
  api/baml_client/type_builder.py → theory/chapters/00_stock_preselection.md
- `MID_EXPANSION()` --calls--> `Value`  [INFERRED]
  api/baml_client/type_builder.py → theory/chapters/00_stock_preselection.md
- `LATE_EXPANSION()` --calls--> `Value`  [INFERRED]
  api/baml_client/type_builder.py → theory/chapters/00_stock_preselection.md
- `RECESSION()` --calls--> `Value`  [INFERRED]
  api/baml_client/type_builder.py → theory/chapters/00_stock_preselection.md

## Hyperedges (group relationships)
- **Linear Alembic revision chain (down_revision linkage)** — ff232ce0534f_initial_schema, 1e14baf18033_add_server_defaults, cfc1deec33d6_add_yfinance_tables, 1c95f3fd3da4_remove_jsonb_columns [EXTRACTED 1.00]
- **Portfolio snapshot tables created then JSON-normalized** — s9t0u1v2w3x4_add_portfolio_tables, t0u1v2w3x4y5_normalize_json_columns, db_table_portfolio_snapshots [INFERRED 0.85]
- **macro_calibrations table created then extended with regime classification** — p6q7r8s9t0u1_add_macro_calibrations, b1c2d3e4f5g6_add_regime_classification, db_table_macro_calibrations [INFERRED 0.85]
- **Macro observation table migration lineage** — g7b8c9d0e1f2_drop_st_rate_forecast, h8c9d0e1f2g3_add_macro_observation_tables, i9d0e1f2g3h4_add_econ_indicator_observations, j0e1f2g3h4i5_add_macro_news_table [EXTRACTED 1.00]
- **ticker_news schema evolution migrations** — l2g3h4i5j6k7_add_ticker_news_full_content, m3h4i5j6k7l8_drop_ticker_news_related_tickers, n4i5j6k7l8m9_add_ticker_news_ticker_name [EXTRACTED 1.00]
- **API DB runtime core: settings, manager, ORM base** — config_settings, database_manager, models_shared_base [EXTRACTED 1.00]
- **background-job route pattern (202 + job_id, poll, cancellable worker)** — backtest_router, factors_router, macro_regime_router [INFERRED 0.85]
- **v1 router aggregation** — shared_router_api_router, main_create_application, dashboard_router [EXTRACTED 0.95]
- **centralized exception handling** — exceptions_base_api_exception, exceptions_setup_exception_handlers, exceptions_create_error_response [EXTRACTED 0.95]
- **Background-job 202/poll API routers sharing BackgroundJobService** — macro_calibration_router, yfinance_data_router, optimize_router [INFERRED 0.85]
- **Optimize endpoint to pipeline build/extract to execution persistence** — optimize_execute_persist, optimization_service_build_pipeline, execution_repository [INFERRED 0.75]
- **Stress scenario LLM design feeding synthetic data generation** — stress_scenarios_service, synthetic_service, synthetic_router [INFERRED 0.65]
- **BaseModel composes Base + UUID + Timestamp mixins** — base_model, base_uuid_mixin, base_timestamp_mixin [EXTRACTED 1.00]
- **views routes aggregate LLM/BL/opinion routers** — views_init, llm_moments_router, opinion_pooling_router [EXTRACTED 1.00]
- **execution runs link portfolio + background job** — execution_optimization_run, execution_backtest_run, background_job_model [INFERRED 0.85]
- **Instrument-rooted yfinance market-data tables** — universe_instrument, yfinance_data_price_history, yfinance_data_financial_statement [INFERRED 0.85]
- **PortfolioSnapshot normalized EAV child tables** — portfolio_portfolio_snapshot, portfolio_snapshot_weight, portfolio_snapshot_optimizer_param [EXTRACTED 0.95]
- **Domain repositories on shared RepositoryBase** — base_repository_base, dashboard_repository_dashboard_repository, execution_repository_execution_repository [EXTRACTED 0.95]
- **domain repositories extend RepositoryBase** — macro_regime_repository, yfinance_repository, portfolio_repository [INFERRED 0.85]
- **shared schema base layer** — base_camelcase_model, base_job_async_schemas, attribution_schema [INFERRED 0.75]
- **Async background job schema family** — shared_async_job_create_response, shared_async_job_progress, shared_camel_case_model [INFERRED 0.85]
- **Factor research request schema pipeline** — factors_factor_compute_request, factors_factor_score_request, factors_factor_select_request [INFERRED 0.75]
- **Rebalancing decide request/response flow** — rebalancing_decide_request, rebalancing_decide_response, rebalancing_trade_item [INFERRED 0.80]
- **Black-Litterman / pooling view schema family** — views_entropy_pooling_request, views_generate_views_schemas, views_opinion_pool_schemas [INFERRED 0.75]
- **Shared data-quality and resilience helpers** — trading_calendar_has_sufficient, json_safe_safe_float, notifications_notify_failure [INFERRED 0.65]
- **Daily pipeline: yfinance, macro fetch, news summarize** — scheduler_run_daily_pipeline, macro_regime_run_bulk_macro_fetch, macro_news_run_summarize [EXTRACTED 1.00]
- **Factor service split: compute, scoring, analysis** — factor_compute_service_module, factor_scoring_service_module, factor_analysis_service_module [EXTRACTED 1.00]
- **Macro ingestion via IlSole + TradingEconomics scrapers** — macro_regime_service_class, ilsole_scraper_class, tradingeconomics_scraper_class [EXTRACTED 1.00]
- **yfinance resilience shim layer over shared infrastructure** — retry_shim, circuit_breaker_shim, infra_shared [INFERRED 0.85]
- **module-level yfinance market sub-clients** — market_marketclient, sector_industry_client, screener_client [INFERRED 0.75]
- **yfinance bulk fetch orchestration** — yfinance_data_service_service, yfinance_data_service_bulkfetch, facade_yfinanceclient [INFERRED 0.85]
- **Ticker sub-clients extend BaseClient** — holders_holdersclient, analysis_analysisclient, financials_financialsclient [EXTRACTED 0.90]
- **Optimization, tuning, validation services share pipeline assembly** — optimization_service_build_pipeline, tuning_service_run_tune, validation_service_run_validation [INFERRED 0.75]
- **Trading212 instrument filters implementing InstrumentFilter** — liquidity_liquidityfilter, market_cap_marketcapfilter, data_coverage_datacoveragefilter [INFERRED 0.85]
- **Report generation aggregate-build-persist pipeline** — report_service_reportdataaggregator, report_service_pdfbuilder, report_service_reportservice [EXTRACTED 0.90]
- **UniverseBuilder injected protocol collaborators** — builder_universebuilder, protocols_trading212apiclient, protocols_universerepository [INFERRED 0.75]
- **Multi-LLM opinion pooling pipeline** — opinion_pooling_build_llm_opinion_pool, opinion_pooling_run_llm_experts, opinion_pooling_compute_ic_weights [EXTRACTED 0.90]
- **LLM Black-Litterman view generation flow** — view_generation_fetch_factor_data, view_generation_generate_views, view_generation_generatedviews [EXTRACTED 0.90]
- **News-sentiment Idzorek alpha adjustment** — sentiment_fetch_news_sentiment, sentiment_compute_sentiment_signal, sentiment_adjust_idzorek_alpha [EXTRACTED 0.90]
- **job-failure webhook dispatch chain** — app_services_jobs_background_job, app_services_shared_notifications, test_notifications_webhook [INFERRED 0.85]
- **flat-to-domain refactor regression suite** — test_routes_flat_to_domain, test_services_flat_to_domain, test_services_domain_imports [INFERRED 0.85]
- **SQLite SAVEPOINT test harness** — tests_conftest_db_session, tests_conftest_client, test_rebalance_preview_route [INFERRED 0.75]
- **yfinance market clients share resilience primitives** — screener_client, search_client, funds_client [INFERRED 0.75]
- **factor validation service orchestration** — factor_service, factor_repository, run_factor_validation [INFERRED 0.85]
- **extracted CamelCaseModel schema modules** — views_schemas, llm_moments_schemas, stress_scenarios_schemas [EXTRACTED 1.00]
- **Execution runs model + repository + migration** — optimization_run_model, execution_repository, migration_y5z6a7b8c9d0 [INFERRED 0.85]
- **Rebalancing policy model + repository + routes** — rebalancing_policy_model, rebalancing_repository, test_rebalance_policy_routes [INFERRED 0.75]
- **Scheduler liveness settings + lifespan + job repository** — settings_config, app_main_lifespan, background_job_repository [INFERRED 0.80]
- **Cooperative job cancellation: reaper, progress closure, service** — background_job_repository, shared_make_cancellable_progress, jobs_background_job_service [INFERRED 0.85]
- **Price data assembly from yfinance repository** — shared_price_fetcher_fetch_close_prices, attribution_service_fetch_ticker_returns, yfinance_repository [INFERRED 0.75]
- **Universe screen route, service, request schema** — universe_route_universe_screen, universe_screening_service, universe_schema_universe_screen_request [INFERRED 0.75]
- **Async background-job route pattern (create_job/start_background/get_job)** — factors_factor_compute_route, validate_validate_route, backtest_backtest_route [INFERRED 0.85]
- **BackgroundJob lifecycle: repository + service + cancellable progress** — background_job_repository_background_job_repository, background_job_background_job_service, shared_make_cancellable_progress [INFERRED 0.85]
- **Portfolio analytics routes share PortfolioRepository** — dashboard_dashboard_route, risk_analytics_route, portfolio_repository_portfolio_repository [INFERRED 0.75]
- **LLM Black-Litterman view generation pipeline** — view_generation_generate_views, view_generation_views_to_arrays, optimizer_views_config_black_litterman [INFERRED 0.75]
- **Multi-LLM opinion pooling flow** — opinion_pooling_run_llm_experts, opinion_pooling_compute_ic_weights, opinion_pooling_build_llm_opinion_pool [INFERRED 0.75]
- **Factor compute with point-in-time alignment** — factor_compute_service_run_factor_compute, factor_compute_service_load_fundamentals, optimizer_factors_align_to_pit [INFERRED 0.85]
- **Factor research pipeline: construction to scoring to selection** — factors_construction, factors_scoring, factors_selection [INFERRED 0.85]
- **Distance + clustering feed HRP/HERC/NCO optimizers** — distance_factory, cluster_factory, optimizer_init [INFERRED 0.75]
- **Validation, config and CS regression for factor IC** — factors_validation, factors_config, linear_model_factory [INFERRED 0.80]
- **Hierarchical optimizer family sharing common distance/clustering helpers** — optimization_hrp_build, optimization_herc_build, optimization_schur_build [INFERRED 0.85]
- **Mu + covariance estimators composed into prior** — moments_factory_build_mu_estimator, moments_factory_build_cov_estimator, moments_factory_build_prior [EXTRACTED 0.95]
- **Robust/DR-CVaR optimizers falling back to plain MeanRisk** — optimization_robust_build, optimization_dr_cvar_build, optimization_factory_build_mean_risk [INFERRED 0.85]
- **View integration prior factories** — views_factory_build_black_litterman, views_factory_build_entropy_pooling, views_factory_build_opinion_pooling [INFERRED 0.85]
- **Prices to validated weights orchestration** — orchestrator_run_full_pipeline, builder_build_portfolio_pipeline, orchestrator_optimize [INFERRED 0.85]
- **Uncertainty-set config validation and dispatch** — uncertainty_config_muuncertaintysetconfig, uncertainty_config_covarianceuncertaintysetconfig, uncertainty_config_validate_bootstrap_only_fields [INFERRED 0.85]
- **DB-to-DataFrame assembly orchestration** — data_orchestrator, data_container, data_equity_facade [INFERRED 0.85]
- **CLI parse-and-run chain** — cli_parser, cli_main, cli_dunder_main [EXTRACTED 0.95]
- **Macro regime data merge inputs** — data_macro, data_sentiment, data_regime [INFERRED 0.85]
- **research pipeline step orchestration** — load_load_data, optimize_optimize_portfolio, report_report_performance [INFERRED 0.85]
- **DB preflight check suite** — checks_check_universe_coverage, checks_check_price_staleness, checks_check_fred_freshness [EXTRACTED 0.95]
- **Top-4 retighten and sub-period Sharpe helpers** — retighten_solve_with_retighten, retighten_annualized_sharpe, rebalance_hockey_stick_warn [INFERRED 0.85]
- **Backtest chart generation suite** — plots_generate_backtest, plots_cumulative_returns, plots_factor_ic [EXTRACTED 1.00]
- **optimize() DB-to-weights orchestration** — strategies_optimize, strategies_build_optimizer, strategies_get_db_manager [EXTRACTED 1.00]
- **After-tax return reconstruction** — returns_compute_after_tax, returns_txn_cost, returns_tax_drag [EXTRACTED 1.00]

## Communities (2077 total, 582 thin omitted)

### Community 0 - "API Views & Scenarios"
Cohesion: 0.02
Nodes (114): TestRegionMap, set, TestEnums, Short leg must contain at most ceil(n_assets * quantile) assets., Long and short legs must be disjoint., Long leg assets must have strictly higher scores than short leg assets., Long leg must contain at most ceil(n_assets * quantile) assets., TestLegSizing (+106 more)

### Community 1 - "Optimizer Validation & Reporting"
Cohesion: 0.01
Nodes (180): Fig92RebalancingFrequency — rebalancing frequency tradeoff bar chart., Fig93TradeTriggers — calendar vs threshold trade trigger time series., Fig94GrossVsNet — gross vs net cumulative returns., LinkageMethodType, Configuration for hierarchical clustering selection.  The :class:`HierarchicalCl, Linkage method for agglomerative hierarchical clustering., DistanceEstimatorType, Configuration for distance estimator selection.  The :class:`DistanceConfig` is (+172 more)

### Community 2 - "Macro Regime API & Tests"
Cohesion: 0.09
Nodes (17): _make_bond_yield_obs(), _make_econ_obs(), _make_macro_news(), _make_mock_repo(), _make_te_obs(), _patch_repo(), Unit tests for macro regime data read endpoints.  All tests mock MacroRegimeRepo, Return a MagicMock repo with sensible empty defaults. (+9 more)

### Community 3 - "Async Job Endpoints"
Cohesion: 0.04
Nodes (72): AllocationDonutComponent, clearCssVars(), first, { fixture, store }, { fixture, store, host }, { host }, makeResult(), PALETTE (+64 more)

### Community 4 - "News Sentiment Pipeline"
Cohesion: 0.03
Nodes (95): makeAttrSvcStub(), makeAttrSvcMock(), ConcentrationAssetApi, StressScenarioItemApi, assertFieldParity(), jsTypeOf(), matchesProp(), matchesSchemaType() (+87 more)

### Community 5 - "Macro Calibration & BL Config"
Cohesion: 0.04
Nodes (47): MacroRegimeCalibration, build_bl_config_from_calibration(), _build_macro_summary(), _clamp_confidence(), _clamp_delta(), _clamp_tau(), classify_macro_regime(), Classify business cycle phase and return calibrated (δ, τ) for Black-Litterman. (+39 more)

### Community 6 - "Hierarchical Clustering Config"
Cohesion: 0.02
Nodes (71): assert_camel_case_keys(), assert_json_safe(), assert_no_snake_case_keys(), assert_response_matches_schema(), _assert_scalar_json_safe(), Shared, pure assertion helpers for API tests (issue #807).  No DB, no I/O — impo, Recursively reject non-JSON types, then catch NaN/inf via ``json.dumps``., Validate ``response_json`` against ``schema_class``; return the model. (+63 more)

### Community 7 - "Service Import Boundary Tests"
Cohesion: 0.01
Nodes (211): BacktestResultsPanelComponent, cells, DRAWDOWN_SUMMARY_KEYS, inSample, labels, alertEl, err, fixture (+203 more)

### Community 8 - "LLM Moments & Business Cycle"
Cohesion: 0.08
Nodes (10): _FakeDBManager, _make_session(), Foundational tests for ``app.services.pipeline_builder.steps`` (issue #696).  Co, test_when_custom_tickers_supplied_then_uses_them(), test_when_first_ticker_empty_then_falls_back_to_next(), test_when_first_ticker_has_rows_then_returns_dataframe(), test_when_no_instrument_matches_then_returns_none(), test_when_require_field_missing_then_raises_value_error() (+2 more)

### Community 9 - "Universe Screening & Selection"
Cohesion: 0.07
Nodes (52): BaseCurrencyEnum, BuildHistoryStepRequest, CostStepRequest, CoverageGateStepRequest, CreateSessionResponse, EmptyStepRequest, LoadStepRequest, Pydantic v2 schemas for the ``/pipeline-builder`` HTTP domain (issue #711).  Con (+44 more)

### Community 10 - "Risk Analytics API Tests"
Cohesion: 0.06
Nodes (22): _make_concentration_result(), _make_correlation_result(), _make_factor_exposure_result(), _make_liquidity_result(), _make_portfolio(), _make_snapshot(), _make_var_result(), Unit tests for risk analytics endpoints (issues #368, #369).  Covers:   - GET /a (+14 more)

### Community 11 - "Optimization & Tuning Schemas"
Cohesion: 0.04
Nodes (41): ACCEPTED, { comp, http }, { comp, store, http }, { comp, store, http, tick }, req, buildStepParams(), isParamStep(), PARAM_STEP_IDS (+33 more)

### Community 12 - "Factor & Macro Models"
Cohesion: 0.05
Nodes (21): _make_factor_scores(), _make_price_df(), Unit tests for RiskAnalyticsService (issues #368, #369).  Covers:   - compute_va, When every weight ticker is absent from price_history, the 400 path must still f, If only one ticker has DB prices, correlation must raise the existing 'at least, Short-lookback edge case: 30-day lookback should succeed when history is abundan, Historical VaR / CVaR with known synthetic data., Parametric (normal) VaR / CVaR. (+13 more)

### Community 13 - "BAML Type Builder"
Cohesion: 0.03
Nodes (37): BEARISH(), BULLISH(), BusinessCyclePhase(), BusinessCyclePhaseAst, BusinessCyclePhaseValues, BusinessCyclePhaseViewer, CovEstimatorChoice(), CovEstimatorChoiceAst (+29 more)

### Community 14 - "Optimizer Config Surface"
Cohesion: 0.01
Nodes (139): std, BlackLitterman, _compute_sharpe_scores(), Compute annualised Sharpe ratio as a composite-score proxy.      Parameters, _query_sector_and_mcap(), Query sector labels and market cap from the database.      Returns     -------, _cov_to_corr(), _query_sector_mapping() (+131 more)

### Community 15 - "Portfolio Routes & Jobs"
Cohesion: 0.06
Nodes (16): _make_account(), _make_portfolio(), _make_position(), _make_snapshot(), Unit tests for portfolio CRUD and broker sync endpoints.  All repositories and t, get_t212_client raises 503 when API key is absent., TestCreatePortfolio, TestCreateSnapshot (+8 more)

### Community 16 - "Resilience Infrastructure Clients"
Cohesion: 0.05
Nodes (57): AnalysisClient, BaseClient, LRUCache shim, CalendarsClient, CircuitBreaker, CircuitBreaker shim, CorporateActionsClient, ParseStructureError (+49 more)

### Community 17 - "Rebalancing & Risk Schemas"
Cohesion: 0.04
Nodes (36): DB seed builder for the rebalancing domain (FK-dependent on ``Portfolio``).  Gua, RebalancingSeed, seed_rebalancing(), DB seed builder for the risk domain (FK-dependent on ``Portfolio``).  Guards par, RiskSeed, seed_risk(), Pydantic schemas for rebalancing policy and decide/preview endpoints.  Covers re, Rebalancing scheduling configuration for a portfolio.      Unique constraint on (+28 more)

### Community 18 - "Cluster 18"
Cohesion: 0.06
Nodes (38): _build_extra_kwargs(), _build_ic_history(), _build_training_data(), _extract_in_sample_stats(), _extract_oos_stats(), _extract_vif(), _find_ic_result(), Factor validation and composite scoring service.  Responsibilities:   - Run in-s (+30 more)

### Community 19 - "Cluster 19"
Cohesion: 0.08
Nodes (19): _clamp_scenario(), _ensure_market_drawdown(), generate_stress_scenarios(), LLM-driven stress scenario design for forward-looking tail risk events.  Archite, Generate forward-looking stress scenarios via LLM.      Calls the BAML ``DesignS, Convert a StressScenario to sample_args for build_synthetic_data().      The ret, Return a copy of *scenario* with all fields clamped to valid ranges., Verify at least one scenario has a broad market drawdown (>10% on average). (+11 more)

### Community 20 - "Cluster 20"
Cohesion: 0.05
Nodes (51): _apply_tilts(), _build_composite_scores_series(), build_exposure_constraints_for_tickers(), _build_scores_wide(), _build_selection_config(), _build_tilt_config(), _compute_buffer_zone(), compute_quintile_spread_for_tickers() (+43 more)

### Community 21 - "Cluster 21"
Cohesion: 0.05
Nodes (35): build_walk_forward(), compute_optimal_folds(), Factory functions for building skfolio cross-validators., Run cross-validated prediction with a temporal cross-validator.      Thin wrappe, Compute optimal fold counts for CPCV.      Wraps :func:`skfolio.model_selection., Build a skfolio :class:`WalkForward` cross-validator from *config*.      Paramet, run_cross_val(), Tests for validation factory functions. (+27 more)

### Community 22 - "Cluster 22"
Cohesion: 0.03
Nodes (676): Communities (1933 total, 575 thin omitted), Communities (1948 total, 589 thin omitted), Communities (1958 total, 588 thin omitted), Communities (1974 total, 601 thin omitted), Communities (1979 total, 590 thin omitted), Communities (1979 total, 600 thin omitted), Communities (1992 total, 588 thin omitted), Communities (2016 total, 576 thin omitted) (+668 more)

### Community 23 - "Cluster 23"
Cohesion: 0.02
Nodes (70): _assert_at_least_two_assets(), _assert_sufficient_data(), _build_asset_exposures(), _build_concentration_assets(), _build_liquidity_asset(), _cluster_and_reorder(), _compute_concentration_summary(), _compute_corr_matrix() (+62 more)

### Community 24 - "Cluster 24"
Cohesion: 0.25
Nodes (7): _build_histogram(), MetricsMiddleware, HTTP request latency middleware for Prometheus instrumentation.  Single Responsi, Return the histogram to use, creating a registry-scoped one for tests., Starlette-compatible ASGI middleware that records HTTP request durations.      P, Return the FastAPI route template or ``<unmatched>`` for 404s.      Uses ``scope, _resolve_path_template()

### Community 25 - "Cluster 25"
Cohesion: 0.03
Nodes (137): AnalyticsPaneComponent, hasAnySignal(), MetricCard, allNull, btn, cardByIdValueClassList(), cardByIdValueText(), cards (+129 more)

### Community 26 - "Cluster 26"
Cohesion: 0.06
Nodes (24): ExecutionRepository, Repository for optimization and backtest execution run persistence., Update the status of an existing optimization run.          Args:             ru, Return a single BacktestRun by its primary-key UUID, or None., Return backtest runs with optional filtering.          Args:             portfol, Repository for :class:`OptimizationRun` and :class:`BacktestRun` persistence., Return the most recently created backtest run for *portfolio_id*.          Args:, Persist a new backtest run.          Args:             data: Dict of column name (+16 more)

### Community 27 - "Cluster 27"
Cohesion: 0.03
Nodes (99): baml_client.stream_types, baml_client.types (BAML pydantic types/enums), all_succeeded(), AssetFactorData, AssetView, BusinessCyclePhase, Check, Checked (+91 more)

### Community 28 - "Cluster 28"
Cohesion: 0.08
Nodes (19): _fit_weights(), main(), Distributionally Robust CVaR at three Wasserstein-ball epsilon levels.  Fits ``D, build_dr_cvar(), _build_empirical_cvar_fallback(), DRCVaRConfig, DistributionallyRobustCVaR configuration and factory.  ``epsilon=0`` falls back, Empirical-CVaR fallback for ``epsilon=0`` — plain :class:`MeanRisk`. (+11 more)

### Community 29 - "Cluster 29"
Cohesion: 0.08
Nodes (4): BamlCallOptions, BamlHttpRequestClient, BamlHttpStreamRequestClient, BamlSyncClient

### Community 30 - "Cluster 30"
Cohesion: 0.17
Nodes (12): _create_prereq_tables(), _load_migration(), Tests for migration y5z6a7b8c9d0: six new tables.  Covers: - Migration module im, Engine with prereq tables + the six new tables created via upgrade()., After downgrade(), none of the six tables must exist., Load the migration module from its file path., Create the tables that the six new tables reference via FK., Migration module must declare correct revision identifiers. (+4 more)

### Community 31 - "Cluster 31"
Cohesion: 0.04
Nodes (64): AnalystPriceTarget, AnalystRecommendation, Dividend, FinancialStatement, InsiderTransaction, InstitutionalHolder, MutualFundHolder, PriceHistory (+56 more)

### Community 32 - "Cluster 32"
Cohesion: 0.04
Nodes (9): Unit tests for factor utility endpoints:    - POST /api/v1/factors/select   - PO, POST /api/v1/factors/exposure-constraints returns serializable inequality matric, POST /api/v1/factors/quintile-spread returns quintile cumulative returns and spr, POST /api/v1/factors/regime-tilt applies macro regime tilts to group weights., POST /api/v1/factors/select selects stocks and returns turnover + buffer zone., TestPostExposureConstraints, TestPostFactorSelect, TestPostQuintileSpread (+1 more)

### Community 33 - "Cluster 33"
Cohesion: 0.09
Nodes (22): _capture_downgrade_sql(), _capture_upgrade_statements(), _count(), _create_tables(), _load_migration(), Tests for migration a7b8c9d0e1f2: seed_reference_indices_expanded (issue #430)., SQLite-compatible version of the migration's INSERT (for smoke testing only)., The static INDICES tuple must cover the nine new benchmarks. (+14 more)

### Community 34 - "Cluster 34"
Cohesion: 0.08
Nodes (32): buildBacktestRequest(), BUILDER_RESULT_DEBOUNCE_MS, BuilderResultService, buildOptRequest(), extractTickers(), isTerminal(), mapToBuilderBacktest(), mapToBuilderFrontier() (+24 more)

### Community 35 - "Cluster 35"
Cohesion: 0.09
Nodes (3): BamlAsyncClient, BamlHttpRequestClient, BamlHttpStreamRequestClient

### Community 36 - "Cluster 36"
Cohesion: 0.06
Nodes (46): frontier, buildAxis(), buildCalSeries(), buildScatterSeries(), EchartsEfficientFrontierComponent, FrontierClickPayload, FrontierPalette, pickTangencyPoint() (+38 more)

### Community 37 - "Cluster 37"
Cohesion: 0.06
Nodes (45): BamlAsyncClient, baml_client.globals, baml_client.inlinedbaml, baml_client (generated BAML client 'b'), baml_client.parser, baml_client.runtime, BamlSyncClient, baml_client.type_builder (TypeBuilder) (+37 more)

### Community 38 - "Cluster 38"
Cohesion: 0.01
Nodes (83): values(), map, data, EchartsCandlestickComponent, buildFrontierSeries(), container, EchartsFactorExposureComponent, EchartsGaugeComponent (+75 more)

### Community 39 - "Cluster 39"
Cohesion: 0.12
Nodes (18): compute_factor_scores(), Compute composite factor scores for tickers on a given date.      Args:, _make_factor_repo(), _make_factor_score(), _make_oos_result(), _make_price_rows(), _make_session(), _make_validation_report_result() (+10 more)

### Community 40 - "Cluster 40"
Cohesion: 0.06
Nodes (23): FactorValidationReport, Validation report from ``run_factor_validation()``.      Also covers ``run_facto, FactorRepository, Repository for factor research persistence operations., Return all factor scores recorded on *score_date*.          Args:             sc, Upsert a batch of factor scores using the unique constraint.          Delegates, Return validation reports filtered by optional criteria.          Args:, Repository for FactorScore and FactorValidationReport persistence.      Follows (+15 more)

### Community 41 - "Cluster 41"
Cohesion: 0.02
Nodes (114): _plot_heatmap(), Fig36Detoning — side-by-side heatmaps of full vs detoned correlation matrix., Render a correlation-matrix heatmap on the given axes.      Parameters     -----, _add_legend_patches(), Fig39HMMRegimes — three-panel HMM regime detection figure., Fill axis background with regime colour spans., Add coloured patch legend for regime shading., _shade_regimes() (+106 more)

### Community 42 - "Cluster 42"
Cohesion: 0.04
Nodes (47): fetch_single_country(), get_all_news_summaries(), get_bond_yield_observations(), get_bond_yields(), get_country_news_summary(), get_country_summary(), get_distinct_countries(), get_economic_indicator_observations() (+39 more)

### Community 43 - "Cluster 43"
Cohesion: 0.22
Nodes (19): _build_client(), _patch_industry(), _patch_sector(), Tests for issue #605: SectorIndustryClient adds 1.3.0 surface methods.  Five new, test_when_existing_fetch_industry_top_companies_called_then_still_returns_df(), test_when_existing_fetch_sector_overview_called_then_still_returns_dict(), test_when_fetch_industry_research_reports_called_then_yf_industry_attribute_returned(), test_when_fetch_industry_top_growth_companies_called_then_yf_industry_attribute_returned() (+11 more)

### Community 44 - "Cluster 44"
Cohesion: 0.07
Nodes (15): BackgroundJobRepository, Database operations for the ``background_jobs`` table., _make_stale(), Tests for BackgroundJobRepository — dialect-agnostic SQL (issue #314).  Covers c, cleanup_expired must use dialect-agnostic datetime arithmetic., get_latest_by_type returns the most recently finished job., Force the row's heartbeat past the default 5-minute timeout., reconcile_orphans marks pending/running rows as failed at startup. (+7 more)

### Community 45 - "Cluster 45"
Cohesion: 0.08
Nodes (28): create_limit(), delete_limit(), list_limits(), FastAPI router for risk limits CRUD endpoints (issue #370).  Routes are resource, Update ``current_value`` and ``is_breached`` for an existing risk limit., Delete a risk limit by ID. Returns 404 if the limit does not exist., Lookup portfolio by name; raise 404 if not found., Re-evaluate is_breached from stored current_value for each limit.      upper → b (+20 more)

### Community 46 - "Cluster 46"
Cohesion: 0.05
Nodes (42): Mark instruments that were active but absent from the latest T212 response., UniverseBuilder, Configuration for universe building from Trading212 API.      All thresholds and, UniverseBuilderConfig, YFinanceTickerMapper, _FakeRepo, _make_api_client(), _make_filter_pipeline() (+34 more)

### Community 47 - "Cluster 47"
Cohesion: 0.01
Nodes (142): apiHttpInterceptor(), BackoffFn, extractMessage(), isInternalRequest(), isRetriable(), normalize(), notifyIfNeeded(), RETRIABLE_STATUSES (+134 more)

### Community 48 - "Cluster 48"
Cohesion: 0.08
Nodes (28): _aggregate_totals(), _build_entries(), _build_row(), _build_target_list(), _build_trade(), _classify_action(), _collect_row_entries(), compute_drift() (+20 more)

### Community 49 - "Cluster 49"
Cohesion: 0.12
Nodes (15): _make_account(), _make_portfolio(), _make_prices(), _make_snapshot(), _make_snapshot_with_sectors(), Unit tests for dashboard route endpoints.  Mocks PortfolioRepository and Dashboa, Issue #460: benchmark ticker absent from instruments table., Issue #460: benchmark exists in instruments but has no price rows. (+7 more)

### Community 50 - "Cluster 50"
Cohesion: 0.07
Nodes (36): create_snapshot upsert on (portfolio_id, date, type), dashboard activity route, Portfolio model, portfolio repositories package init, portfolio ORM models, BrokerAccountSnapshot, PortfolioRepository, Portfolio Router (+28 more)

### Community 51 - "Cluster 51"
Cohesion: 0.03
Nodes (83): MacroSeed, _make_calibration(), _make_indicator(), DB seed builder for the macro domain.  Seeds one ``EconomicIndicator``, one ``Ma, seed_macro(), BondYieldObservation, EconomicIndicator, EconomicIndicatorObservation (+75 more)

### Community 52 - "Cluster 52"
Cohesion: 0.03
Nodes (60): BufferZone, FactorCompositeScoreResponse, FactorComputeRequest, FactorExposureConstraintsRequest, FactorExposureConstraintsResponse, FactorQuintileSpreadRequest, FactorQuintileSpreadResponse, FactorRegimeTiltRequest (+52 more)

### Community 53 - "Cluster 53"
Cohesion: 0.07
Nodes (33): PublicationLagConfig, Differentiated publication lags by data source type.      Each source has an ind, _build_score_rows(), _load_fundamentals(), _load_prices(), Factor computation service — DB fetch, compute, and persist factor scores.  Resp, Fetch financial statement data and apply PIT alignment.      Args:         sessi, Fetch price history and pivot to a dates x tickers matrix.      Args:         se (+25 more)

### Community 54 - "Cluster 54"
Cohesion: 0.24
Nodes (8): _build_macro_fetcher(), Unit tests for the macro-news sub-client.  Coverage target --------------- * app, Build MacroNewsFetcher with mocked internals., _stale_iso(), TestMacroNewsFetcherFetchAll, _today_iso(), _trusted_article(), _untrusted_article()

### Community 55 - "Cluster 55"
Cohesion: 0.06
Nodes (25): _get_last_refresh_time(), Run ``seed_reference_indices`` as a tracked background job.      Args:         l, Run ``seed_reference_indices`` as a tracked background job.      Args:         l, Incremental 30-minute news re-summarization.      Stateless: derives "last run", Incremental 30-minute news re-summarization.      Stateless: derives "last run", Return the most recent ``macro_news_summaries.updated_at``, or fallback., Return the most recent ``macro_news_summaries.updated_at``, or fallback., Return the most recent ``macro_news_summaries.updated_at``, or fallback. (+17 more)

### Community 56 - "Cluster 56"
Cohesion: 0.03
Nodes (78): cal, ChartTab, COMPOSITE_CHART_AXIS, COMPOSITE_SCORE_THRESHOLDS, COUNTRY_CODE_MAP, COUNTRY_NAME_MAP, DB_COUNTRIES, PHASE_DEFAULTS (+70 more)

### Community 57 - "Cluster 57"
Cohesion: 0.07
Nodes (15): get_log_level(), Get the log level for the BAML Python client., Get the log level for the BAML Python client., Set the log level for the BAML Python client, Set the log level for the BAML Python client, Set the log JSON mode for the BAML Python client., Set the log JSON mode for the BAML Python client., Set the maximum log chunk length for the BAML Python client. (+7 more)

### Community 58 - "Cluster 58"
Cohesion: 0.09
Nodes (14): _make_limit(), _make_portfolio(), Unit tests for risk limits CRUD endpoints (issue #370).  Covers:   - GET  /api/v, upper limit: current_value > threshold → breached., lower limit: current_value < threshold → breached., Tests for POST /risk/{portfolio_name}/limits., Tests for PUT /risk/{portfolio_name}/limits/{limit_id}., Tests for DELETE /risk/{portfolio_name}/limits/{limit_id}. (+6 more)

### Community 59 - "Cluster 59"
Cohesion: 0.05
Nodes (28): apply_lognormal_correction(), Log-normal moment scaling for multi-period investment horizons., Validate inputs and apply the log-normal moment correction.      A higher-level, Scale daily log-return moments to a multi-period horizon.      **Expected return, scale_moments_to_horizon(), daily_cov(), daily_mu(), Tests for log-normal moment scaling.  Covers apply_lognormal_correction and scal (+20 more)

### Community 60 - "Cluster 60"
Cohesion: 0.04
Nodes (40): ParseStructureError, Domain exceptions for web scraper modules., Raised when a scraper parses fewer rows than the minimum threshold.      Indicat, TradingEconomicsIndicatorsScraper, _bond_row(), _bond_soup(), _country_list_soup(), _country_row() (+32 more)

### Community 61 - "Cluster 61"
Cohesion: 0.04
Nodes (40): Branch-coverage tests for views service modules.  Targets the missed lines:  opi, When closes list is non-empty, pct_from_52w_high / _low are populated., Monotonically rising prices: current == max → pct_from_high == 0., target_upside is computed when profile has target_mean_price and current_price., When _build_factor_data returns None for a ticker, fetch_factor_data omits it., When all clipped weights are zero (impossible with 0.1 floor, but the guard, LLM returns empty dict; single group must default to 1.0 then rescale., Negative raw weights are clipped to 0.1 then rescaled. (+32 more)

### Community 62 - "Cluster 62"
Cohesion: 0.08
Nodes (34): Migration: remove JSONB raw_json/related_tickers columns, Migration: add server defaults to timestamp columns, Migration: rebuild macro tables to match ORM, Migration: expand reference-index seed to 10 benchmarks, Migration: normalize and optimize models, Migration: add regime_classification to macro_calibrations, Migration: align exchanges table with ORM, Migration: add worker liveness columns to background_jobs (+26 more)

### Community 63 - "Cluster 63"
Cohesion: 0.06
Nodes (32): _fully_fresh_staleness(), _make_repo(), _make_yf_client_silent(), Tests for yfinance timeout watchdog and incremental throughput improvements.  Co, A TimeoutError on profile is captured as an error; price fetch still runs., A TimeoutError on profile is captured as an error; price fetch still runs., TimeoutError on every category fills errors but returns a result dict., TimeoutError on every category fills errors but returns a result dict. (+24 more)

### Community 64 - "Cluster 64"
Cohesion: 0.04
Nodes (37): backtest._run_backtest_bg wrapper, optimize._run_optimize_bg wrapper, BackgroundJobService, app.services._shared.notifications (httpx.post), tune._run_tune_bg wrapper, validate._run_walk_forward_bg wrapper, _build_create_mock(), _default_job_dict() (+29 more)

### Community 65 - "Cluster 65"
Cohesion: 0.02
Nodes (65): fixture, Clock, ERROR_CLOCK, extractMessage(), GlobalErrorHandler, isHttpError(), err, httpErr (+57 more)

### Community 66 - "Cluster 66"
Cohesion: 0.09
Nodes (23): _bucket_bounds(), _count(), _label_set(), Tests for per-endpoint Prometheus latency histograms (Red phase first).  Accepta, A live /metrics scrape must surface all four histograms., Regression guard: the original generic histogram must still register., Each execution route must record a sample on its dedicated histogram.      The o, Return the upper-bound buckets registered for ``metric_name``. (+15 more)

### Community 67 - "Cluster 67"
Cohesion: 0.05
Nodes (18): _all_expected_paths(), Tests for domain directory scaffolding (issue #607)., Acceptance criterion: every new folder has __init__.py with docstring., Acceptance criterion: every new folder has __init__.py with docstring., Acceptance criterion: package imports succeed., Acceptance criterion: package imports succeed., Acceptance criterion: existing __init__.py files are untouched.      We verify b, Acceptance criterion: existing __init__.py files are untouched.      We verify b (+10 more)

### Community 68 - "Cluster 68"
Cohesion: 0.06
Nodes (5): Unit tests for POST /api/v1/factors/validate and POST /api/v1/factors/score.  Co, POST /api/v1/factors/score computes composite scores for a ticker universe., POST /api/v1/factors/validate runs factor validation and returns report., TestPostFactorScore, TestPostFactorValidate

### Community 69 - "Cluster 69"
Cohesion: 0.01
Nodes (327): Communities (1517 total, 771 thin omitted), Community 100 - "Community 100", Community 104 - "Community 104", Community 106 - "Community 106", Community 109 - "Community 109", Community 111 - "Community 111", Community 114 - "Community 114", Community 115 - "Community 115" (+319 more)

### Community 70 - "Cluster 70"
Cohesion: 0.05
Nodes (38): (a) Where the stateful DataAssembly lives between step calls, Additional Notes, (b) Single vs multi concurrent builder sessions, Build Sequence (Checklist), (c) Step 7 granularity, code:python (_api_path = Path(__file__).parent.parent.parent / "api"), code:python (_run_bulk_fetch pattern:), code:python (import sys) (+30 more)

### Community 71 - "Cluster 71"
Cohesion: 0.05
Nodes (32): event, TestMakeProgress, Thin wrapper managing job lifecycle around the service function., _run_news_summarize(), Thin wrapper managing job lifecycle around the service function.      Cancel-pol, _run_bulk_fetch(), FastAPI router for walk-forward validation endpoints.  Endpoints:   POST /valida, Start a walk-forward validation background job.      Returns 202 + job_id immedi (+24 more)

### Community 72 - "Cluster 72"
Cohesion: 0.1
Nodes (13): Request body for POST /risk/{portfolio_name}/limits., Request body for PUT /risk/{portfolio_name}/limits/{limit_id}., List of risk limit responses with breach summary., RiskLimitCreate, RiskLimitListResponse, RiskLimitUpdate, Tests for api/app/schemas/risk.py — risk limit schemas.  Covers (TDD Red → Green, RiskLimitListResponse wraps items with breach count. (+5 more)

### Community 73 - "Cluster 73"
Cohesion: 0.08
Nodes (25): _default_breaker(), _default_cache(), _default_limiter(), _extract_close(), FxRateProvider, Per-day spot FX rate provider (issue #775).  Returns `float | None` for (from_cc, Spot-FX provider with per-day cache and infrastructure-grade resilience., _reject_pence() (+17 more)

### Community 74 - "Cluster 74"
Cohesion: 0.08
Nodes (11): Integration tests: service sub-packages resolve from domain folders (issue #611), scrapers sub-package must resolve from macro domain., yfinance sub-package must resolve from market_data domain., services/__init__.py re-exports must resolve from new locations., trading212 sub-package must resolve from universe domain., TestScrapersDomainImport, TestServicesInitReExports, TestTrading212DomainImport (+3 more)

### Community 75 - "Cluster 75"
Cohesion: 0.04
Nodes (45): _add_weight_rows(), _make_account(), _make_portfolio(), _make_position(), PortfolioSeed, DB seed builder for the portfolio domain.  Populates the parent ``Portfolio`` +, seed_portfolio(), _seed_snapshot() (+37 more)

### Community 77 - "Cluster 77"
Cohesion: 0.05
Nodes (71): InputsPaneComponent, ACCORDION_LABELS, ACCORDION_SECTIONS, AccordionSectionId, BUILDER_STAGES, BuilderStage, SECTION_STEP_MAP, sectionForStep() (+63 more)

### Community 78 - "Cluster 78"
Cohesion: 0.02
Nodes (27): BlockEvent, EventCollectorInternal, InternalEventBindings, VarEvent, News fetching and article scraping., ArticleResult, Protocol, All abstract interfaces (ISP). (+19 more)

### Community 79 - "Cluster 79"
Cohesion: 0.03
Nodes (65): FactorBuildHealth, Diagnostic report from build_factor_scores_history().      Parameters     ------, Diagnostic report from build_factor_scores_history().      Parameters     ------, build_factor_scores_history(), Factor scores history building utilities.  This module orchestrates point-in-tim, Build a time-series of factor scores over rolling rebalancing periods.      Para, Return a point-in-time cross-section of fundamentals indexed by ticker.      Par, _slice_fundamentals_at() (+57 more)

### Community 80 - "Cluster 80"
Cohesion: 0.09
Nodes (16): AsyncStreamingClient, Sub-client for WebSocket streaming via ``yf.WebSocket`` / ``yf.AsyncWebSocket``., Synchronous WebSocket wrapper around ``yf.WebSocket``., Async WebSocket wrapper around ``yf.AsyncWebSocket``., StreamingClient, Cycle 4 streaming lock + handler-first contract.  Validates: 1. ``StreamingClien, test_when_20_tasks_subscribe_async_then_yf_async_websocket_constructed_once(), test_when_20_threads_subscribe_then_yf_websocket_constructed_once() (+8 more)

### Community 81 - "Cluster 81"
Cohesion: 0.04
Nodes (715): Communities (1569 total, 577 thin omitted), Communities (1574 total, 615 thin omitted), Communities (1593 total, 611 thin omitted), Communities (1599 total, 620 thin omitted), Communities (1603 total, 594 thin omitted), Communities (1604 total, 617 thin omitted), Communities (1612 total, 626 thin omitted), Communities (1620 total, 626 thin omitted) (+707 more)

### Community 82 - "Cluster 82"
Cohesion: 0.11
Nodes (21): fetch_close_prices(), Shared price-fetching helper (issue #382).  Single Responsibility: fetch close p, Fetch close prices for each ticker from price_history table.      Args:, Unit tests for ``_shared/_price_fetcher.fetch_close_prices`` (issue #826).  NOTE, _row(), TestFetchClosePrices, _make_repo(), _make_row() (+13 more)

### Community 83 - "Cluster 83"
Cohesion: 0.07
Nodes (30): BacktestRunListResponse, BacktestRunResponse, AllocationResponse, EquityCurveResponse, KpiItem, PerformanceMetricsResponse, FactorScoreResponse, FactorValidationReportResponse (+22 more)

### Community 84 - "Cluster 84"
Cohesion: 0.06
Nodes (17): In-memory cache mapping (symbol, exchange) → yfinance ticker.      One instance, TickerMappingCache, _mapper_with_info(), Covers: ticker_mapper.py lines 123-124, 163-184., TestFetchBasicDataBranches, Line 159: get_ticker_cache() returns a TickerMappingCache., TestGetTickerCache, Unit tests for TickerMappingCache.  TTL/capacity-eviction acceptance items are N (+9 more)

### Community 85 - "Cluster 85"
Cohesion: 0.07
Nodes (13): ActionBarComponent, labelFor(), b, btn(), { fixture, host }, { fixture, host, store }, { host }, optSpy (+5 more)

### Community 86 - "Cluster 86"
Cohesion: 0.1
Nodes (16): _make_job_row(), _parse_sse_events(), Tests for GET /api/v1/jobs/{job_id}/stream SSE endpoint (issue #374).  Covers:, Unknown job_id returns 404 (not SSE stream)., A job already in terminal status sends a single event: done and closes., Running jobs push event: progress then event: done on completion., The repository must be instantiated on each poll (fresh session per iteration)., Build a minimal mock BackgroundJob ORM row. (+8 more)

### Community 87 - "Cluster 87"
Cohesion: 0.08
Nodes (20): T212 ticker suffix resolver (issue #774).  Pure function. Strips Trading 212 ven, Result of parsing a raw T212 ticker., Strip the T212 venue suffix and infer the Yahoo Finance suffix., resolve_t212_suffix(), ResolvedSymbol, Tests for resolve_t212_suffix + ResolvedSymbol (issue #774)., `AIRp_pp_EQ` must match `_pp_EQ`, not be greedily eaten by `_p_EQ`., ≥20 distinct ticker patterns drawn from real T212 payloads. (+12 more)

### Community 88 - "Cluster 88"
Cohesion: 0.14
Nodes (16): _build_frontier(), extract_results(), Build result dict from fitted Portfolio., Extract weights, metrics, risk contributions, and efficient frontier., Convert list of Portfolio objects to {return, risk, weights} dicts., _to_result(), _make_mock_pipeline(), _make_mock_portfolio() (+8 more)

### Community 89 - "Cluster 89"
Cohesion: 0.12
Nodes (4): RateLimiter, Shim-parity tests for the yfinance infrastructure re-export layer (issue #823)., TestShimAllExports, TestShimIdentity

### Community 90 - "Cluster 90"
Cohesion: 0.09
Nodes (21): _fail_run(), get_backtest_run(), get_backtest_status(), FastAPI router for backtest endpoints.  Always runs as a background job — POST r, Return the :class:`BacktestRun` row with matching ``run_id`` (issue #464)., Return the :class:`BacktestRun` row with matching ``run_id`` (issue #464)., Poll a backtest job for status and progress., Poll a backtest job for status and progress. (+13 more)

### Community 91 - "Cluster 91"
Cohesion: 0.08
Nodes (28): UniverseBuilder.build, UniverseBuilder._mark_delisted_instruments, UniverseBuilder._process_single_instrument, UniverseBuilder, InstitutionalFieldSpec, LiquidityTier, UniverseBuilderConfig, DataCoverageFilter (+20 more)

### Community 92 - "Cluster 92"
Cohesion: 0.08
Nodes (16): FxPriceConverter, Return feature names (pass-through)., Convert local-currency prices to base-currency prices.      Multiplies each tick, fx_rates(), Tests for FxPriceConverter., Tests for FxPriceConverter.transform()., Tests for sklearn API compliance., Tests for fill_limit exhaustion NaN warning. (+8 more)

### Community 93 - "Cluster 93"
Cohesion: 0.04
Nodes (54): alertEl, ASYNC_RESPONSE, body, capture(), COMPUTE_PROGRESS, FWD, JOB_ENC, poll (+46 more)

### Community 94 - "Cluster 94"
Cohesion: 0.06
Nodes (26): BaseCovariance, _build_regime_probabilities(), main(), Regime-blended Mean-Risk with externally-supplied regime probabilities.  Builds, Two-regime soft labels driven by 21-day cross-section volatility., build_regime_blended_mean_risk(), _ExternallyControlledRegimeCovariance, Regime-blended MeanRisk configuration and factory.  Composes :class:`_Externally (+18 more)

### Community 95 - "Cluster 95"
Cohesion: 0.06
Nodes (38): _make_client(), _mock_429_error(), _mock_http_error(), _mock_response(), _raise(), Unit tests for Trading212Client — all HTTP calls mocked via requests., Helper: make side_effect raise an exception from a mock_get call., test_calls_correct_endpoint() (+30 more)

### Community 96 - "Cluster 96"
Cohesion: 0.15
Nodes (11): compute_asset_class_returns(), Compute sector return = weighted average of ticker returns.      Uses within-sec, Compute sector returns over 1D, 1W, 1M, and YTD periods.      Args:         weig, _sector_return_for_period(), _make_prices(), Unit tests for compute_asset_class_returns — pure computation, no DB., Regression for #420.          pandas 3.x rejects direct comparisons between a ``, Regression for #459.          ``dashboard_repository.get_multi_ticker_prices`` p (+3 more)

### Community 97 - "Cluster 97"
Cohesion: 0.06
Nodes (35): _compute_accruals(), _compute_amihud_illiquidity(), _compute_asset_growth(), _compute_book_to_price(), _compute_cash_flow_yield(), _compute_dividend_yield(), _compute_earnings_yield(), _compute_ebitda_to_ev() (+27 more)

### Community 98 - "Cluster 98"
Cohesion: 0.08
Nodes (19): All-NaN series → col.empty after dropna → no synthetic price., TestApplyDelistingReturns, _apply_delisting_returns(), Append a synthetic delisting-date price row for each delisted instrument.      F, Tests for the pure _apply_delisting_returns function., when no delistings, original prices returned unchanged., when delisting return given, synthetic price = last_price * (1 + r)., when ticker is absent from price columns, it is silently skipped. (+11 more)

### Community 99 - "Cluster 99"
Cohesion: 0.06
Nodes (27): BaseClient, _corp_client(), _fin_client(), _holders_client(), _make_infra(), Unit tests for ticker sub-clients: corporate_actions, holders, financials.  Cove, fetch_sec_filings uses ``is_valid=lambda v: v is not None``, so [] is valid., Empty list is a valid result (is_valid only rejects None). (+19 more)

### Community 100 - "Cluster 100"
Cohesion: 0.04
Nodes (45): mount(), setup(), badges, baseCases, build(), Harness, items, RESULT (+37 more)

### Community 101 - "Cluster 101"
Cohesion: 0.12
Nodes (16): type, additionalProperties, description, title, type, currentWeights, targetWeights, tradeWeights (+8 more)

### Community 102 - "Cluster 102"
Cohesion: 0.08
Nodes (21): ActivityEvent, BrokerPosition, Real brokerage position synced from Trading 212., Cross-cutting activity log for portfolio events., _make_event(), _make_portfolio(), _make_snapshot(), Branch coverage for PortfolioRepository (target: ≥80%).  Missed lines targeted - (+13 more)

### Community 103 - "Cluster 103"
Cohesion: 0.09
Nodes (9): Tests for models/ and schemas/ domain file migration (issue #609)., Ensure critical imports and app factory work after migration., from app.models import PriceHistory, Portfolio, MacroNews, from app.schemas import OptimizeRequest, PortfolioResponse, Acceptance criterion: All files moved to domain sub-folders via git mv., Each domain __init__.py must have docstring and re-export contained modules., TestAppBootsAfterReorganization, TestDomainInitPyReExports (+1 more)

### Community 104 - "Cluster 104"
Cohesion: 0.07
Nodes (12): Unit tests for POST /api/v1/universe/screen (issue #361).  Covers:   - Screen wi, When preset is provided, the corresponding factory method is used., When individual config fields are provided, they override defaults., Empty instruments table returns empty result, not a 500., Invalid request bodies return 422 Unprocessable Entity., Issue #827: runtime ValueError from run_universe_screen → 422., No preset, no custom fields — uses default thresholds., TestScreenCustomThresholds (+4 more)

### Community 105 - "Cluster 105"
Cohesion: 0.04
Nodes (46): assemble_analyst_data(), assemble_financial_statements(), assemble_fundamentals(), assemble_insider_data(), _compute_asset_growth_from_statements(), _enrich_from_financial_statements(), Equity fundamentals, financial statements, analyst and insider assembly function, Compute asset_growth from two most recent annual Total Assets values.      Mutat (+38 more)

### Community 106 - "Cluster 106"
Cohesion: 0.15
Nodes (15): cached_property thread-safe sub-client construction (#601), valuation/eps statement_type-period_type-currency triples, YFinanceDataService.fetch_and_store, FinancialsClient, FinancialsClientProtocol, seed_reference_indices service, _run_seed worker, start_seed endpoint (+7 more)

### Community 107 - "Cluster 107"
Cohesion: 0.05
Nodes (37): anyOf, default, title, format, title, type, anyOf, default (+29 more)

### Community 108 - "Cluster 108"
Cohesion: 0.09
Nodes (12): build_risk_budgeting(), RiskBudgeting configuration and factory.  Wraps :class:`skfolio.optimization.Ris, Build a skfolio :class:`RiskBudgeting` optimiser from *config*.      Parameters, Build a skfolio :class:`RiskBudgeting` optimiser from *config*.      Parameters, Immutable configuration for :class:`skfolio.optimization.RiskBudgeting`.      Se, RiskBudgetingConfig, Tests for the RiskBudgeting factory and configuration., returns() (+4 more)

### Community 109 - "Cluster 109"
Cohesion: 0.05
Nodes (37): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, commit_enabled, current_cycle, cycle5_decisions (+29 more)

### Community 110 - "Cluster 110"
Cohesion: 0.1
Nodes (9): Application configuration using Pydantic Settings v2, Application settings with environment variable support, Settings, BaseSettings, Settings exposure for liveness reaper (issue #590)., Module-level BackgroundJobService instances pick up the cadence setting., TestLifespanForwardsTimeout, TestLivenessSettings (+1 more)

### Community 111 - "Cluster 111"
Cohesion: 0.08
Nodes (7): Tests for _shared_ file migration (issue #608)., Ensure the app factory can be imported without error., Acceptance criterion: All 16 files moved to _shared_ via git mv., Each _shared/__init__.py must re-export contained modules., TestAppBootsAfterReorganization, TestFilesMovedToShared, TestSharedInitPyReexports

### Community 112 - "Cluster 112"
Cohesion: 0.07
Nodes (22): Immutable configuration for building a scoring function.      When ``ratio_measu, ScorerConfig, for_quick_search(), for_thorough_search(), GridSearchConfig, RandomizedSearchConfig, Configuration for hyperparameter tuning., Immutable configuration for :class:`sklearn.model_selection.GridSearchCV`. (+14 more)

### Community 113 - "Cluster 113"
Cohesion: 0.18
Nodes (7): _factor(), _generated_views(), _price_frame(), Route tests for the view-generation + entropy-pooling endpoints (issue #817).  C, Issue #827: views.py line 106 — Q shape guard → 500., TestEntropyPooling, TestGenerateViews

### Community 114 - "Cluster 114"
Cohesion: 0.05
Nodes (38): assemble_bond_observations(), assemble_fred_series(), assemble_macro_data(), assemble_macro_timeseries(), assemble_te_observations(), Macro-economic data assembly — GDP, yields, bonds, FRED series.  Extracted from, Build a multi-row macro DataFrame from observation tables.      Queries ``tradin, Build a dates x indicator_key DataFrame of Trading Economics observations. (+30 more)

### Community 115 - "Cluster 115"
Cohesion: 0.06
Nodes (34): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, current_cycle, cycle5_decisions, cycles (+26 more)

### Community 116 - "Cluster 116"
Cohesion: 0.04
Nodes (37): Classification thresholds for the composite macro regime scorer.      All eight, Classification thresholds for the composite macro regime scorer.      All eight, RegimeThresholdConfig, TestRegimeThresholdConfig, _build_regime_series(), _compute_period_metrics(), for_research(), _identify_subperiods() (+29 more)

### Community 117 - "Cluster 117"
Cohesion: 0.02
Nodes (94): CorrelationPanelComponent, RollingCorrPoint, EchartsHeatmapComponent, BIG_ASSETS, BIG_MATRIX, HeatmapOption, opt, SMALL_ASSETS (+86 more)

### Community 118 - "Cluster 118"
Cohesion: 0.07
Nodes (19): FactorScore, SQLAlchemy ORM models for factor research persistence., Per-ticker, per-date factor score from ``compute_all_factors()``.      Unique co, FactorsSeed, _make_report(), _make_score(), DB seed builder for the factors domain.  Seeds one ``FactorScore`` and one (aggr, seed_factors() (+11 more)

### Community 119 - "Cluster 119"
Cohesion: 0.11
Nodes (11): build_nco(), NCOConfig, NestedClustersOptimization configuration and factory.  No matrix inversion — rob, Immutable configuration for :class:`NestedClustersOptimization`.      Inner and, Build a skfolio :class:`NestedClustersOptimization` from *config*.      Paramete, Tests for NestedClustersOptimization factory and configuration., returns(), TestBuildNCO (+3 more)

### Community 120 - "Cluster 120"
Cohesion: 0.1
Nodes (22): activate_rebalance_policy(), create_rebalance_policy(), list_rebalance_policies(), FastAPI router for rebalancing policy CRUD and activate endpoints.  Routes:   GE, Activate a rebalancing policy, deactivating all others for the portfolio.      R, Return all rebalancing policies for the named portfolio.      Returns 404 when t, Create a new rebalancing policy.      Returns 404 when the portfolio does not ex, _resolve_portfolio_or_404() (+14 more)

### Community 121 - "Cluster 121"
Cohesion: 0.03
Nodes (75): ActivityFeedResponse, ActivityItem, AllocationChild, AllocationNode, AllocationResponse, AssetClassReturnRow, AssetClassReturnsResponse, DriftEntry (+67 more)

### Community 122 - "Cluster 122"
Cohesion: 0.09
Nodes (32): attribution_service _fetch_ticker_returns, get_db FastAPI dependency, init_db startup function, DatabaseManager, macro repositories package init, macro_regime ORM models, market_data package, market_data repositories package init (+24 more)

### Community 123 - "Cluster 123"
Cohesion: 0.17
Nodes (24): research.cli.__main__ entry point, research.cli __init__ re-export, _load_market_proxy, research.cli._main.main orchestrator, research.cli._parser build_parser, _RegimeRepoPersistence adapter, data_assembly re-export facade, data._container DataAssembly value object (+16 more)

### Community 124 - "Cluster 124"
Cohesion: 0.2
Nodes (7): _make_ep_result(), _make_prices_df(), Unit tests for POST /api/v1/views/entropy-pooling endpoint.  Covers:   - mean_vi, Solver convergence failure → 500., Happy-path tests for each view type and combined views., TestEntropyPoolingSolverFailure, TestEntropyPoolingSuccess

### Community 125 - "Cluster 125"
Cohesion: 0.1
Nodes (9): LRUCache, _Clock, Unit tests for the shared ``LRUCache`` resilience primitive (issue #823).  Cover, Mutable monotonic-clock stand-in., TestContainsAndKeys, TestEviction, TestGetPut, TestThreadSafety (+1 more)

### Community 126 - "Cluster 126"
Cohesion: 0.08
Nodes (20): _coerce_flag(), _coerce_flag_list(), FlagInstance, NormalizedPosition, PositionFlag, NormalizedPosition + PositionFlag + FlagInstance.  Transient (non-persisted) Pyd, Diagnostic flags emitted alongside a normalized position., Diagnostic flags emitted alongside a normalized position. (+12 more)

### Community 127 - "Cluster 127"
Cohesion: 0.08
Nodes (23): _make_asset_view(), _make_factor_data(), _make_generated_views(), _make_view_output(), Unit tests for LLM-driven Black-Litterman view generation., 200 bps with direction +1 → Q = +0.02., Each view string must contain '==' — required by skfolio BlackLitterman., LLM may hallucinate a ticker not in the universe — must be dropped. (+15 more)

### Community 128 - "Cluster 128"
Cohesion: 0.08
Nodes (24): _annualized_return(), compute_performance_metrics(), compute_rolling_metrics(), get_market_snapshot(), Pure computation for dashboard performance metrics.  All functions are stateless, Compute all 7 KPIs with sparklines and change deltas.      Args:         weights, Compute rolling Sharpe, annualized vol, and beta series over *window* days., Compute market snapshot from pre-fetched data.      Args:         fred_data: {se (+16 more)

### Community 129 - "Cluster 129"
Cohesion: 0.08
Nodes (35): _minimal_repo(), _minimal_yf_client(), Branch-coverage tests for yfinance_data_service.py and reference_index_seeder.py, Line 133: _timed wraps fn in call_with_timeout when timeout is set., Line 131-132: _timed calls fn() directly when no timeout., Lines 165-179: repo.get_staleness_info raises → staleness=None → full path., Staleness query failure must be logged at WARNING., Line 268: incremental + fresh profile → 'profile' in skipped. (+27 more)

### Community 130 - "Cluster 130"
Cohesion: 0.14
Nodes (3): DoNotUseDirectlyCallManager, _ResolvedBamlOptions, BamlStreamClient

### Community 131 - "Cluster 131"
Cohesion: 0.13
Nodes (23): HierarchicalClusteringConfig, build_hierarchical_clustering, cluster package, DistanceConfig, build_distance, distance package, factors config, factors construction (+15 more)

### Community 132 - "Cluster 132"
Cohesion: 0.05
Nodes (37): _country_weights(), _eval_metric_threshold(), _project_rule_for_json(), Step 7b — Checklist validation and terminal gate.  Extracted from ``stock_select, Persist Cycle 4 §9.3 metrics block to ``metrics.json`` (Cycle 5 input)., Persist Cycle 4 §10 checklist results to ``checklist.json``., Persist final portfolio weights to ``weights.csv`` sorted desc., Print the measured-vs-target table for failing checklist rules only. (+29 more)

### Community 133 - "Cluster 133"
Cohesion: 0.06
Nodes (32): DashboardRepository, Repository for dashboard data queries., Return ``{ticker: (price_row_count, latest_price_date)}``.          Tickers with, Return (yield_value, day_change) for US 10Y bond.          Returns None if no ro, Return the reference_date for US 10Y bond yield., Read-only repository for dashboard-specific data access., Return True if an Instrument row with the given yfinance_ticker exists., Fetch close prices for multiple tickers as a pivoted DataFrame.          Returns (+24 more)

### Community 134 - "Cluster 134"
Cohesion: 0.12
Nodes (19): Return current UTC time., utc_now(), baml_test(), create_item(), delete_item(), echo_get(), echo_post(), get_item() (+11 more)

### Community 135 - "Cluster 135"
Cohesion: 0.05
Nodes (24): AnalysisClient, Sub-client for analyst recommendations, estimates, and sustainability., Wraps ``yf.Ticker`` analyst/research attributes., Sub-client for dividends, splits, actions, capital gains, and shares., Sub-client for financial statements and SEC filings., Sub-client for ETF/mutual fund data: holdings, sectors, bonds, performance., Sub-client for holder information (institutional, mutual fund, insider)., Ticker-scoped sub-clients (extend BaseClient). (+16 more)

### Community 136 - "Cluster 136"
Cohesion: 0.15
Nodes (12): BrokerSyncResult, _empty_client(), _make_repo(), Empty-data and exception-path tests for broker_sync_service (issue #825).  Cover, T212 client that returns empty collections everywhere., _run(), TestWhenAccountSyncRaisesErrorCaptured, TestWhenEmptyPositionsThenSyncedIsZero (+4 more)

### Community 137 - "Cluster 137"
Cohesion: 0.16
Nodes (10): _make_apscheduler_job(), _make_bg_job(), _make_scheduler(), Tests for GET /api/v1/scheduler/status endpoint (issue #375).  Tests written FIR, Endpoint returns safe defaults when scheduler is None or not running., last_run_time and last_status are null when no background_jobs rows exist., Endpoint returns job statuses when scheduler is active., TestSchedulerStatusMissingHistory (+2 more)

### Community 138 - "Cluster 138"
Cohesion: 0.16
Nodes (7): OptimizationRun, SQLAlchemy ORM models for execution result persistence.  Stores per-run records, Persisted result of a single call to ``POST /api/v1/optimize``.      ``portfolio, OptimizationRun exposes portfolio and job relationship attributes., OptimizationRun rows can be inserted with required and optional fields., TestOptimizationRunInsertion, TestOptimizationRunRelationships

### Community 139 - "Cluster 139"
Cohesion: 0.01
Nodes (326): Communities (1539 total, 775 thin omitted), Community 0 - "Community 0", Community 101 - "Community 101", Community 102 - "Community 102", Community 103 - "Community 103", Community 105 - "Community 105", Community 107 - "Community 107", Community 108 - "Community 108" (+318 more)

### Community 140 - "Cluster 140"
Cohesion: 0.1
Nodes (21): FundsClient, Wraps ``yf.Ticker.funds_data`` attributes., Return cached ``quote_type`` (uppercased) for *symbol*, or ``None``., Return ``funds_data`` for *symbol*, short-circuiting non-fund tickers., _build_client(), Tests for issue #603: FundsClient._get_funds_data quote_type allowlist guard.  E, Mimics yfinance's FastInfo proxy with optional ``quote_type``., Counts ``fast_info`` and ``funds_data`` attribute reads. (+13 more)

### Community 141 - "Cluster 141"
Cohesion: 0.06
Nodes (35): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, commit_enabled, current_cycle, cycle5_decisions (+27 more)

### Community 142 - "Cluster 142"
Cohesion: 0.09
Nodes (18): EntropyPoolingConfig, Immutable configuration for the Entropy Pooling prior.      All parameters map 1, build_entropy_pooling(), _merge_mean_views(), Merge equality and inequality mean views into a single list.      skfolio's Entr, Build a skfolio Entropy Pooling prior from *config*.      Parameters     -------, mean_inequality_views field stores inequality views (issue #69)., TestEntropyPoolingConfig (+10 more)

### Community 143 - "Cluster 143"
Cohesion: 0.09
Nodes (23): make_client(), make_fx_provider(), Shared T212 payload fixtures for Cycle 1 normalizer e2e tests (issue #778)., Mock FxRateProvider that looks up rates from _FX_RATES., _position_by_t212(), End-to-end fixture-based unit tests for T212 normalizer (issue #778)., sum(eur_value) = invested * 1.005 → within 1.5% gate., sum(eur_value) = invested * 1.05 → outside 1.5% gate. (+15 more)

### Community 144 - "Cluster 144"
Cohesion: 0.14
Nodes (19): _assert_cancellable(), cancel_job(), _fetch_job(), get_job(), _get_repo(), _job_to_summary(), JobListResponse, JobSummary (+11 more)

### Community 145 - "Cluster 145"
Cohesion: 0.08
Nodes (32): FreshnessConfig, Per-environment freshness rules for the position normalizer., Convert one raw T212 position dict into a `NormalizedPosition`., Convert one raw T212 position dict into a `NormalizedPosition`., T212PositionMapper, TestFreshnessConfigShape, _flag_for(), _make_fx() (+24 more)

### Community 146 - "Cluster 146"
Cohesion: 0.07
Nodes (22): DataManagementPanelComponent, h, banner, c, del, fx, HEALTH, rows (+14 more)

### Community 147 - "Cluster 147"
Cohesion: 0.15
Nodes (7): _actual_weights_from_prices(), compute_drift(), Compute drifted weights from price changes since snapshot date., Compute per-ticker drift between target and actual weights.      Args:         t, Unit tests for drift analysis — pure computation, no DB., TestActualWeightsFromPrices, TestComputeDrift

### Community 148 - "Cluster 148"
Cohesion: 0.04
Nodes (46): DiagnosticEntry, DiagnosticEntry — Cycle 4 aggregate-diagnostic row schema (issue #792).  Per-fla, One entry inside `DriftDiagnostics.entries`., BaseToggle, _check_current_weight(), _check_delta_weight(), _check_target_weight(), _check_weight() (+38 more)

### Community 149 - "Cluster 149"
Cohesion: 0.08
Nodes (24): _aggregate_by_group(), _ensure_output_dir(), generate_backtest_plots(), plot_country_allocation(), plot_cumulative_returns(), plot_drawdowns(), plot_factor_ic(), plot_rolling_sharpe() (+16 more)

### Community 150 - "Cluster 150"
Cohesion: 0.09
Nodes (15): _new_repo(), _pending(), Branch-coverage tests for app/repositories/jobs/background_job_repository.py.  T, Create a pending job and return its id., _ensure_tables_exist has two nested exception handlers; exercise both.      The, TestBuildValuesMerge, TestCleanupExpiredNoSuchTable, TestCreate (+7 more)

### Community 151 - "Cluster 151"
Cohesion: 0.05
Nodes (24): create_session(), delete_session(), get_job_service(), Insert a new session and return its hex id., Insert a new session and return its hex id., Remove the session and any cached job service. Idempotent., Remove the session and any cached job service. Idempotent., Return the cached job service for ``session_id``, creating it on first call. (+16 more)

### Community 152 - "Cluster 152"
Cohesion: 0.06
Nodes (25): Re-export from shared infrastructure — keeps yfinance import paths stable., Re-export from shared infrastructure — keeps yfinance import paths stable., Shared resilience primitives for all external service clients., Re-export from shared infrastructure — keeps yfinance import paths stable., _full_jitter(), is_transient_network_error(), Generic retry helper with exponential backoff.  Provides resilience primitives f, Detect transient network errors: HTTP rate limits and TCP resets. (+17 more)

### Community 153 - "Cluster 153"
Cohesion: 0.05
Nodes (22): Repository for yfinance data access with PostgreSQL upsert support., Upsert a ticker profile from yf.Ticker.info dict., Upsert daily OHLCV rows from a yfinance history DataFrame., Upsert financial statement rows (EAV format).          yfinance returns DataFram, Upsert dividend data from yfinance Series (index=date, value=amount)., Convert pandas/numpy types to Python natives, NaN/NaT to None., Upsert stock split data from yfinance Series (index=date, value=ratio)., Upsert analyst recommendations from recommendations_summary DataFrame. (+14 more)

### Community 154 - "Cluster 154"
Cohesion: 0.06
Nodes (41): _build_tune_args(), _make_request(), _mock_search_cv(), Empty-data and exception-path tests for tuning_service (issue #825).  Existing t, Non-'randomized' search_type falls through to grid search factory., on_progress is called with status='running' then 'completed'., Default noop callback must not raise., Single-entry param_grid produces a valid TuneResult without raising.      Note: (+33 more)

### Community 155 - "Cluster 155"
Cohesion: 0.05
Nodes (27): Verify FactorCoverageError is part of the exception hierarchy., TestFactorCoverageError, FactorCoverageError, Factor history build failed: too few rebalancing dates succeeded., _check_factor_coverage(), _missing_gics_sectors(), Steps 3-5 — Factor history, IS validation, OOS validation, coverage gate.  Extra, Run rolling walk-forward OOS factor validation.      Fix issue #239: parameters (+19 more)

### Community 156 - "Cluster 156"
Cohesion: 0.1
Nodes (12): generate_scenarios(), Fit a SyntheticData estimator and return (scenarios_matrix, columns).      Args:, _make_mock_sd(), Unit tests for POST /synthetic/scenario endpoint (issue #366).  TDD: Red phase —, Unit tests for generate_scenarios() pure function., Fewer than 60 rows of returns data should raise ValueError., Tests for POST /api/v1/synthetic/scenario returning inline JSON., Return a mock SyntheticData estimator with return_distribution_ set. (+4 more)

### Community 157 - "Cluster 157"
Cohesion: 0.06
Nodes (30): PdfBuilder, Renders section data into a PDF document using reportlab.      Produces text and, Renders section data into a PDF document using reportlab.      Produces text and, PdfBuilder renders section data into PDF bytes., TestPdfBuilder, _make_aggregator(), _make_story_and_styles(), Branch-coverage tests for report_service.py missed lines.  Targets:   - Lines 85 (+22 more)

### Community 158 - "Cluster 158"
Cohesion: 0.05
Nodes (18): AttributionComponent, AttributionSvcMock, attrSvc, consoleErrorSpy, ctx, CtxMock, el, emptySnapshotApi (+10 more)

### Community 159 - "Cluster 159"
Cohesion: 0.2
Nodes (12): lifespan(), FastAPI lifespan context manager for startup and shutdown events., BackgroundJobRepository, jobs SSE stream endpoint, jobs cancel route, app.api.v1.jobs.scheduler, Liveness reaper heartbeat/orphan settings (issue #590), repositories package (+4 more)

### Community 160 - "Cluster 160"
Cohesion: 0.11
Nodes (20): dict_table renderer, error/success/warning/info panels, _aggregate_by_group weight grouping, plot_country_allocation, plot_cumulative_returns, plot_drawdowns underwater chart, plot_factor_ic IS vs OOS bars, generate_backtest_plots orchestrator (+12 more)

### Community 161 - "Cluster 161"
Cohesion: 0.04
Nodes (46): close_db(), database_transaction(), DatabaseManager, execute_raw_sql(), get_db(), get_db_status(), get_session(), init_db() (+38 more)

### Community 162 - "Cluster 162"
Cohesion: 0.1
Nodes (67): AuthenticationError, AuthorizationError, AuthServiceUnavailableError, BaseAPIException, CacheError, ConflictError, DatabaseConnectionError, DatabaseError (+59 more)

### Community 163 - "Cluster 163"
Cohesion: 0.1
Nodes (22): add_and_flush(), Shared internals for the per-domain seed builders (issue #804).  Builders insert, Add a single ORM row and flush so its PK / FKs are assigned., Repository for sentiment-related database queries., Sync repository for instrument lookups and news retrieval., Return the instrument UUID for *ticker*, or ``None``., Return news rows published after *cutoff* in ascending order., Search ``macro_news`` for articles relevant to *ticker*.          Uses a cascadi (+14 more)

### Community 165 - "Cluster 165"
Cohesion: 0.03
Nodes (87): DEFERRED_RULES, FocusState, loadPage(), ROUTES, WCAG_TAGS, errors, FRED_FIXTURE, registerExternalStubs() (+79 more)

### Community 166 - "Cluster 166"
Cohesion: 0.03
Nodes (50): Thin wrapper managing job lifecycle around the service function., Thin wrapper managing job lifecycle around the service function., Thin wrapper managing job lifecycle around the service function., _run_bulk_fetch(), _run_fred_fetch(), _run_macro_news_fetch(), fred_scraper(), get_portfolio_countries() (+42 more)

### Community 167 - "Cluster 167"
Cohesion: 0.08
Nodes (24): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, current_cycle, cycles, effort_hints (+16 more)

### Community 168 - "Cluster 168"
Cohesion: 0.11
Nodes (9): Tests for repositories/ domain file migration (issue #610)., All repo files moved to correct domain sub-folders via git mv., Each domain __init__.py re-exports contained repository classes., repositories/__init__.py uses new sub-package paths, no old flat imports., Critical imports and app factory work after migration., TestAppBootsAfterReorganization, TestDomainInitPyReExports, TestFilesMovedToDomainDirs (+1 more)

### Community 169 - "Cluster 169"
Cohesion: 0.08
Nodes (20): _make_asset_factor_data(), _make_empty_view_output(), _make_pool_result(), _make_view_output(), Unit tests for Multi-LLM Opinion Pooling service and endpoint., LLM view on unknown ticker should be filtered out., TestBuildLLMOpinionPool, TestComputeICWeights (+12 more)

### Community 170 - "Cluster 170"
Cohesion: 0.1
Nodes (21): _build_broker_universe(), _compute_trades(), Derive non-HOLD trade rows sorted by descending |delta_eur|., Derive non-HOLD trade rows sorted by descending |delta_eur|., Resolve T212 instruments to yfinance tickers (filters unmapped)., Resolve T212 instruments to yfinance tickers (filters unmapped)., TestBuildBrokerUniverse, TestComputeDrift (+13 more)

### Community 171 - "Cluster 171"
Cohesion: 0.11
Nodes (13): _make_key(), Seed an ``ApiKey`` row and return the plaintext token., Seed an ``ApiKey`` row and return the plaintext token., A seeded, active key grants access to protected routes., A seeded, active key grants access to protected routes., Missing / malformed / revoked API keys must all return 401., Missing / malformed / revoked API keys must all return 401., A token with the right shape that was never stored is still 401. (+5 more)

### Community 172 - "Cluster 172"
Cohesion: 0.07
Nodes (25): Request body for the reference-index seed endpoint., ReferenceIndexSeedRequest, Thin wrapper managing job lifecycle around the seeder service., _run_seed(), Request body for bulk yfinance data fetch., YFinanceFetchRequest, _noop_progress(), Branch-coverage tests for market_data route wrappers (missed lines).  yfinance_d (+17 more)

### Community 173 - "Cluster 173"
Cohesion: 0.09
Nodes (32): ApiKey model, auth models __init__, BackgroundJobService, BackgroundJobError model, JobAlreadyRunningError, BackgroundJob model, backtest route, Base DeclarativeBase (+24 more)

### Community 174 - "Cluster 174"
Cohesion: 0.07
Nodes (14): BottomTabBarComponent, labels, links, GlobalSearchComponent, GlobalSearchService, LayoutComponent, PAGE_ROUTES, routerTransition (+6 more)

### Community 175 - "Cluster 175"
Cohesion: 0.03
Nodes (69): series, _compute_monthly_snapshots(), Fig07RollingIC, _momentum_score(), Fig07RollingIC — Rolling 12-month information coefficient time series., Synthetic IC series for illustration., Resample prices to month-end and compute returns for IC calculation.      Return, 12-1 month momentum at a monthly snapshot. (+61 more)

### Community 176 - "Cluster 176"
Cohesion: 0.03
Nodes (71): _aggregate_outcome(), call_with_timeout(), _fetch_one_ticker(), _InstrumentSpec, _load_instrument_specs(), Service layer orchestrating yfinance data fetching and storage.  Bulk-ingestion, Execute *fn*, enforcing ``self._request_timeout`` if set., Execute *fn*, enforcing ``self._request_timeout`` if set. (+63 more)

### Community 177 - "Cluster 177"
Cohesion: 0.05
Nodes (37): _build_backtest_args(), _build_optimize_args(), _build_validate_args(), _enable_webhook(), _new_run_id(), _patch_inner_to_raise(), _patch_inner_to_succeed(), Integration tests: webhook fires when a route's job-wrapper raises.  Sibling to (+29 more)

### Community 178 - "Cluster 178"
Cohesion: 0.08
Nodes (32): table, Run in-sample factor validation (IC, VIF, quintile spreads)., validate_is(), dict_table(), error_panel(), _get_console(), info_panel(), list_table() (+24 more)

### Community 179 - "Cluster 179"
Cohesion: 0.04
Nodes (47): ExpertPersona, CamelCaseModel, MacroCalibrationResponse, Calibrated Black-Litterman parameters from LLM macro regime classification., StressScenarioRequest, Tests for schema extraction issue #352.  Verifies that all inline schemas have b, MacroCalibrationResponse must live in api/app/schemas/macro_regime., api/app/schemas/views.py must exist and contain the expected schemas. (+39 more)

### Community 180 - "Cluster 180"
Cohesion: 0.04
Nodes (68): block, Convert prices from local currencies to the base currency.          Parameters, arrayToHash(), balanced(), braceExpand(), childrenIgnored(), cleanUpNextTick(), collectNonEnumProps() (+60 more)

### Community 181 - "Cluster 181"
Cohesion: 0.04
Nodes (25): HierarchicalClusteringConfig, Immutable configuration for hierarchical clustering construction.      Parameter, build_hierarchical_clustering(), Factory for skfolio hierarchical clustering., Build a skfolio :class:`HierarchicalClustering` from *config*.      Parameters, Tests for hierarchical clustering factory., returns(), test_when_dispatched_then_linkage_method_forwarded() (+17 more)

### Community 182 - "Cluster 182"
Cohesion: 0.26
Nodes (15): _build_client(), _patch_search(), Tests for issue #604: SearchClient.search exposes news_count + extras flags.  Fo, test_when_all_flags_true_then_all_keys_present(), test_when_include_lists_true_then_lists_key_present(), test_when_include_nav_true_then_nav_key_present(), test_when_include_research_true_then_research_key_present(), test_when_lists_attribute_missing_then_value_is_none() (+7 more)

### Community 183 - "Cluster 183"
Cohesion: 0.06
Nodes (34): _get_yf_client(), _adjusted_nvda_fixture(), client(), _history_fixture(), _install_ticker(), Cycle 3 regression: kwarg forwarding + NVDA split-day continuity (hermetic).  Lo, Synthetic ``Ticker.history`` payload that passes the ``min_rows=10`` guard., _raw_nvda_fixture() (+26 more)

### Community 184 - "Cluster 184"
Cohesion: 0.14
Nodes (9): _build_repo(), _build_yf_client(), Regression tests for issue #591: dead `fetch_earnings` path removal.  Asserts th, Stub financials sub-client whose ``fetch_earnings`` would raise the     deprecat, Return a MagicMock yf client whose only real attribute is ``financials``., _run_fetch_and_store(), _StubFinancials, test_when_fetch_and_store_runs_then_no_ticker_earnings_deprecation_warning() (+1 more)

### Community 185 - "Cluster 185"
Cohesion: 0.26
Nodes (8): _make_portfolio(), _make_prices(), _make_snapshot(), Unit tests for the equity-curve route endpoint.  Mocks PortfolioRepository and D, Issue #460: benchmark ticker absent from instruments table., Issue #460: benchmark exists in instruments but has no price rows., test_all_period_values(), TestGetEquityCurve

### Community 186 - "Cluster 186"
Cohesion: 0.42
Nodes (16): _Assembly, _fetch(), _make_weights(), Tests for ``step_rebalance_decision`` (issue #707 — Step 11)., _result(), _seed(), test_when_decision_false_and_not_cold_start_then_no_write(), test_when_force_cold_start_then_prev_weights_ignored() (+8 more)

### Community 187 - "Cluster 187"
Cohesion: 0.01
Nodes (183): appConfig, ICON_PROVIDER, icons, fixture, FORBIDDEN_COPY, all, brinsonReqs, factorReqs (+175 more)

### Community 188 - "Cluster 188"
Cohesion: 0.07
Nodes (52): _(), Ao(), Bi(), c(), Cn(), di(), dt(), Eo() (+44 more)

### Community 189 - "Cluster 189"
Cohesion: 0.17
Nodes (11): bootstrap_benchmarks(), _compute_delta(), Startup-time bootstrap for reference-index benchmarks.  Ensures every ticker lis, Return tickers whose price history is missing or stale., Seed any benchmark whose price history is missing or stale.      Parameters, _cov(), Unit tests for ``_shared/_benchmark_bootstrap`` (issue #826).  NOTE on AC: the c, _seed_result() (+3 more)

### Community 190 - "Cluster 190"
Cohesion: 0.09
Nodes (13): _compute_ic_series_cs_regression(), Per-period CS regression slope as IC.      Drops periods with fewer than ``min_o, CSLinearRegressionConfig, Configuration for cross-sectional linear regression.  Wraps :class:`skfolio.line, Immutable configuration for a CS linear regression estimator.      Parameters, build_cs_linear_regression(), Factory for skfolio cross-sectional linear regression., Build a skfolio :class:`CSLinearRegression` from *config*.      Parameters     - (+5 more)

### Community 191 - "Cluster 191"
Cohesion: 0.18
Nodes (16): _patched_startup(), Tests for FastAPI lifespan reconcile_orphans wiring (issues #559, #588)., Order guarantee: reconcile_orphans completes before scheduler.start., Two lifespan invocations in the same interpreter ⇒ one reconcile call., Failed reconcile must leave the sentinel False so the next lifespan retries., Issue #588: ensure each test starts with a clean per-process sentinel., Patch lifespan side-effects so only reconcile_orphans is exercised., _reset_sentinel() (+8 more)

### Community 192 - "Cluster 192"
Cohesion: 0.2
Nodes (9): _make_instrument(), _ok_result(), _patch_module(), Tests for the parallel bulk yfinance fetch path (issue #575).  Patches ``databas, Records every session opened, indexed by the thread that opened it., Patch the module-level dependencies used by the parallel fetcher., _SessionTracker, TestParallelDispatch (+1 more)

### Community 193 - "Cluster 193"
Cohesion: 0.18
Nodes (5): Unit tests for GET /api/v1/market/snapshot.  Mocks DashboardRepository at the ro, Issue #461: benchmark ticker absent from instruments table., Issue #461: instrument exists but has insufficient price data., Configure mock with valid default data., TestGetMarketSnapshot

### Community 194 - "Cluster 194"
Cohesion: 0.05
Nodes (31): DeclarativeBase, _diff_from_default(), _flatten_metrics(), _iter_flat(), persist_research_run(), Optional DB write-back for the research pipeline (Cycle 5 §12).  Bridges the res, Persist one research run as a ``snapshot_type='research_run'`` snapshot.      ``, Return ``dataclasses.asdict`` fields where ``cfg`` differs from defaults. (+23 more)

### Community 196 - "Cluster 196"
Cohesion: 0.13
Nodes (7): OpinionPoolingConfig, Immutable configuration for the Opinion Pooling prior.      The ``estimators`` a, build_opinion_pooling(), Build a skfolio Opinion Pooling prior from *config*.      Parameters     -------, Sum > 1.0 raises ValueError (issue #70)., TestOpinionPoolingConfig, TestBuildOpinionPooling

### Community 197 - "Cluster 197"
Cohesion: 0.07
Nodes (16): DataAssembly container — frozen value object for the data-assembly stage., Equity assembly facade — re-exports from split sub-modules.  All public names pr, Shared constants and pure utility functions for data assembly.  Extracted from `, assemble_fundamental_history(), _empty_history_df(), Historical fundamental panel and delisting return assembly.  Extracted from ``da, Build a ``(period_date, ticker)`` panel from financial_statements EAV.      Quer, Top-level orchestrator — FX rates and the all-in-one assembly entry point.  Extr (+8 more)

### Community 198 - "Cluster 198"
Cohesion: 0.13
Nodes (17): compute_factor_attribution, run_factor_attribution DB wrapper, compute_composite_score (optimizer), select_stocks_for_tickers, run_factor_compute, FactorRepository, compute_factor_scores composite, validate_factors (+9 more)

### Community 199 - "Cluster 199"
Cohesion: 0.06
Nodes (36): _exec_result(), _make_session(), Tests for pure and DB-dependent functions in cli/data_assembly.py.  Covers:   -, Cross-listed tickers: lower currency rank wins, info log emitted., Two listings with same currency rank: one row kept, info log emitted., Single listing per ticker: no warning emitted., No instruments in DB → early return., Return a mock whose .all() yields *rows*. (+28 more)

### Community 200 - "Cluster 200"
Cohesion: 0.06
Nodes (35): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, commit_enabled, current_cycle, cycle5_decisions (+27 more)

### Community 201 - "Cluster 201"
Cohesion: 0.08
Nodes (24): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, current_cycle, cycles, effort_hints (+16 more)

### Community 202 - "Cluster 202"
Cohesion: 0.08
Nodes (24): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, current_cycle, cycles, effort_hints (+16 more)

### Community 203 - "Cluster 203"
Cohesion: 0.08
Nodes (33): main(), Covariance forecast evaluation: rank estimators independent of optimizer.  Compa, CovarianceForecastConfig, _evaluate_offline(), _evaluate_online(), OnlineCovarianceForecastConfig, Covariance forecast evaluation (offline + online).  Covariance forecast evaluati, Rank a set of covariance estimators using walk-forward evaluation.      Paramete (+25 more)

### Community 204 - "Cluster 204"
Cohesion: 0.01
Nodes (217): FactorIntegrationConfig, MacroRegime, Macro-economic regime classification., Configuration for stock selection from scored universe.      Parameters     ----, Configuration for stock selection from scored universe.      Parameters     ----, Configuration for macro regime factor tilts.      Per-regime multiplicative tilt, Configuration for macro regime factor tilts.      Per-regime multiplicative tilt, Dynamic macro-regime sector weight bands for optimizer constraints.      Stores (+209 more)

### Community 205 - "Cluster 205"
Cohesion: 0.14
Nodes (14): description, title, type, MacroCalibrationResponse, description, properties, required, title (+6 more)

### Community 206 - "Cluster 206"
Cohesion: 0.09
Nodes (17): _fetch_from_profiles(), Unified ticker → sector resolver shared by Attribution and Dashboard (issue #427, Return ``{ticker: sector}`` covering every input ticker.      Order of precedenc, Join ``TickerProfile`` via ``Instrument.yfinance_ticker`` — skip NULL sectors., resolve_sector_map(), _profile_rows(), Unit tests for ``_shared/_sector_resolver.resolve_sector_map`` (issue #826).  Se, TestResolveSectorMap (+9 more)

### Community 207 - "Cluster 207"
Cohesion: 0.17
Nodes (7): _format_articles(), _get_countries_for_article(), Map an article to its target countries via ticker or query lookup.      Returns, Format articles into numbered text for the LLM, capped at _MAX_ARTICLES., _make_article(), TestFormatArticles, TestGetCountriesForArticle

### Community 208 - "Cluster 208"
Cohesion: 0.07
Nodes (16): make_flag_instance(), Single source of truth for per-`PositionFlag` human reason copy (issue #793).  U, Build a `FlagInstance` from `code` and optional template kwargs.      Raises `Ke, Tests for `flag_reasons` module (issue #793)., Defensive guard: any future PositionFlag without an entry must raise., Module must not perform I/O or service calls at import time., TestFlagReasonsCompleteness, TestMakeFlagInstance (+8 more)

### Community 209 - "Cluster 209"
Cohesion: 0.07
Nodes (15): inspect(), TestBackgroundJobLivenessColumns, Tests for OptimizationRun and BacktestRun SQLAlchemy models.  Covers: - Table cr, Verify that expected indexes are defined on the optimization_runs table., Verify that expected indexes are defined on the backtest_runs table., Base.metadata.create_all() must succeed for both tables., TestBacktestRunIndexes, TestOptimizationRunIndexes (+7 more)

### Community 210 - "Cluster 210"
Cohesion: 0.11
Nodes (12): DatabaseAdminRepository, Truncate a single table (with CASCADE).          Raises ValueError for unknown t, Truncate multiple tables. Returns ``(cleared, errors)``., Sync repository for database introspection and truncation., Run ``SELECT 1`` and return ``(healthy, latency_ms)``., Branch-coverage tests for app/repositories/_shared/database_admin_repository.py., TestCheckHealthFailure, TestCheckHealthReal (+4 more)

### Community 211 - "Cluster 211"
Cohesion: 0.07
Nodes (24): begin, btn, element, end, getCellValue(), header, helpCheck, line_height (+16 more)

### Community 212 - "Cluster 212"
Cohesion: 0.13
Nodes (10): Acceptance criteria from issue #24., ICIR_WEIGHTED weights are non-negative and normalised to 1., A group with ICIR = 0 is excluded from the composite., Stable factor (low mean IC, low std) outweighs volatile factor., Falls back to equal weight when all groups have ICIR = 0., Tests for group_weights parameter in ICIR_WEIGHTED (issue #81)., compute_icir_weighted_composite with group_weights differs from without., compute_composite_score with ICIR_WEIGHTED forwards group_weights. (+2 more)

### Community 214 - "Cluster 214"
Cohesion: 0.06
Nodes (35): title, type, properties, title, type, default, title, type (+27 more)

### Community 215 - "Cluster 215"
Cohesion: 0.39
Nodes (14): _Assembly, _checklist_rules(), _fetch(), _is_report(), _metrics(), _oos_result(), _optimize_result(), Tests for ``step_report`` (issue #709 — Step 13). (+6 more)

### Community 216 - "Cluster 216"
Cohesion: 0.04
Nodes (56): POST /api/v1/attribution/brinson route, POST /api/v1/backtest route, app.services.backtest.backtest_service, MacroRegimeRepository.upsert_regime_classification, POST /api/v1/optimize route, GET /api/v1/rebalance/preview route, POST /api/v1/universe/screen route, smoke_prices.sql CI fixture (+48 more)

### Community 217 - "Cluster 217"
Cohesion: 0.05
Nodes (40): FilterParams, get_current_user(), get_optional_user(), get_rate_limiter(), get_user_id(), PaginationParams, RateLimiter, Global dependencies for the application (+32 more)

### Community 218 - "Cluster 218"
Cohesion: 0.09
Nodes (35): main(), One-off: pull live T212 positions, FX-normalize, write a portfolio_snapshots row, _assign_weights(), _attach_flag(), _attach_reconciliation_flag(), _build_default_mapper(), _count_flag(), _empty_result() (+27 more)

### Community 219 - "Cluster 219"
Cohesion: 0.1
Nodes (15): compute_binding_constraints(), Return labels for constraint rows where ``A @ w - b >= -tol``.      The slack ``, _build_opt(), _build_region_matrix(), Research-side wiring tests for ``build_region_linear_constraints`` (issue #552)., The 'Other' catch-all bucket is excluded from constraint emission.          Tick, Build (A, b, labels) for region-cap rows on the given ticker order., Build (A, b, labels) for region-cap rows on the given ticker order. (+7 more)

### Community 220 - "Cluster 220"
Cohesion: 0.1
Nodes (11): CovarianceUncertaintySetConfig, MuUncertaintySetConfig, Configuration for skfolio uncertainty-set estimators.  Two parallel Configs (mu,, Immutable configuration for a covariance uncertainty-set estimator.      Paramet, Immutable configuration for a covariance uncertainty-set estimator.      Paramet, Reject bootstrap-only fields when kind is EMPIRICAL.      Parameters     -------, Immutable configuration for a mu uncertainty-set estimator.      Parameters, Immutable configuration for a mu uncertainty-set estimator.      Parameters (+3 more)

### Community 221 - "Cluster 221"
Cohesion: 0.15
Nodes (21): list, AnalystPriceTarget, AnalystRecommendation, Dividend, FetchProgress, FinancialStatement, InsiderTransaction, InstitutionalHolder (+13 more)

### Community 222 - "Cluster 222"
Cohesion: 0.27
Nodes (12): _build_client(), _patch_yf_screen(), Tests for issue #606: ScreenerClient.screen_etfs_predefined convenience method., test_when_default_size_used_then_count_is_25(), test_when_invalid_name_then_value_error_lists_canonical_names(), test_when_invalid_name_then_yf_screen_not_called(), test_when_name_case_differs_then_value_error_raised(), test_when_offset_passed_then_forwarded_to_yf_screen() (+4 more)

### Community 223 - "Cluster 223"
Cohesion: 0.08
Nodes (8): _complete_data_coverage_dict(), _make_hist(), Unit tests for Trading212 universe filters and FilterPipelineImpl.  Covers: - Ma, Return a DataFrame with *n_rows* rows (column content irrelevant)., Build a dict that satisfies every *required* InstitutionalFieldSpec., TestDataCoverageFilter, TestHistoricalDataFilter, TestLiquidityFilter

### Community 224 - "Cluster 224"
Cohesion: 0.09
Nodes (16): load_result(), Synthetic scenario generation service (issue #366).  Single Responsibility: each, Persist *result* as a gzip-compressed JSON file.      Args:         result: Arbi, Load a previously stored result by *download_id*.      Returns:         The stor, store_result(), Branch-coverage tests for scenarios service modules.  Targets the missed lines i, When the stored payload lacks __expires_at, load_result returns None., When expires_at is stored without timezone, it must be treated as UTC. (+8 more)

### Community 225 - "Cluster 225"
Cohesion: 0.23
Nodes (5): Request body for POST /synthetic/scenario., ScenarioRequest, Validate that Pydantic schema enforces field constraints., Values exactly at ±1 are excluded (must be strictly inside (-1, 1))., TestScenarioRequestSchema

### Community 226 - "Cluster 226"
Cohesion: 0.13
Nodes (5): Catalog membership tests for FRED_SERIES sub-dicts.  Guards against drift betwee, TestFredSeriesUnion, TestGdpSeriesDict, TestRateSeriesIncludesShortAndLongTreasuries, TestRecessionSeriesIncludesUSRECDM

### Community 227 - "Cluster 227"
Cohesion: 0.09
Nodes (21): _apply_terminal_gate(), Cycle 4 §10 terminal gate: 17/17 → exit 0 + weights.csv; else exit 1., TestApplyTerminalGate, _all_pass_rules(), _baseline_exit_code(), _baseline_has_artifacts(), _compare_json_values(), _one_fail_rules() (+13 more)

### Community 228 - "Cluster 228"
Cohesion: 0.14
Nodes (14): db_clear_all(), db_clear_table(), db_health(), db_status(), db_tables(), _get_repo(), _mask_url(), FastAPI router for database management endpoints. (+6 more)

### Community 229 - "Cluster 229"
Cohesion: 0.22
Nodes (5): _make_event(), _make_portfolio(), Unit tests for the portfolio activity feed endpoint.  Mocks PortfolioRepository, All response keys should be camelCase (items/total are single-word)., TestGetActivity

### Community 230 - "Cluster 230"
Cohesion: 0.14
Nodes (13): Branch-coverage tests for ViewGenerationRepository.  Covers the missed lines rep, _seed_instrument_with_ticker(), _seed_price(), _seed_profile(), TestGetClosePrices, TestGetInstrumentByTicker, TestGetTickerProfile, Repository for view generation database queries. (+5 more)

### Community 231 - "Cluster 231"
Cohesion: 0.05
Nodes (24): _mock_profile(), Tests for cli/_currency.py — minor-unit currency normalization., When Instrument.currency_code is None, use TickerProfile.currency., yfinance sometimes uses 'GBp' for pence., Create a mock TickerProfile with an associated Instrument., test_major_unchanged(), test_minor_to_major(), TestBuildCurrencyMap (+16 more)

### Community 232 - "Cluster 232"
Cohesion: 0.2
Nodes (11): _mock_dependencies(), _payload(), Integration tests for POST /api/v1/optimize.  Exercises the full route → service, Patch price fetcher and repository so the route runs without touching DB., Build a deterministic positive-trending price panel for optimiser fit., End-to-end POST /api/v1/optimize with real skfolio wiring., Regression for #419: the duplicate-kwarg crash must be gone., Fitted MeanRisk portfolio weights sum to 1.0 (budget constraint). (+3 more)

### Community 233 - "Cluster 233"
Cohesion: 0.17
Nodes (13): cleanup_backtest_runs(), _patch_worker_session(), _payload(), _poll_until_done(), Integration tests for POST /api/v1/backtest (issue #422).  Exercises the full ro, Regression for #422: the TypeError on ``Index`` must be gone., Delete BacktestRun rows after each test so the shared in-memory DB stays clean., Build a price panel with a plain ``Index[object]`` of ``datetime.date``.      Th (+5 more)

### Community 234 - "Cluster 234"
Cohesion: 0.09
Nodes (11): compute_factor(), Compute a single factor.      Parameters     ----------     factor_type : Factor, Regression for issue #289: value factors must NOT be 100× deflated.      After a, Pre-fix (GBX market_cap) produces 100× deflated ratio., Pre-fix earnings_yield is 100× too small., The normalised:deflated ratio must be exactly 100 for value factors., EBITDA/EV is also 100× deflated when EV is in GBX., Cover all analyst-data paths of the recommendation-change factor. (+3 more)

### Community 235 - "Cluster 235"
Cohesion: 0.09
Nodes (26): _load_market_proxy(), main(), Entry point for ``python -m research.cli``., Run the full stock selection pipeline., Run the full stock selection pipeline., Run the full stock selection pipeline., Return a single-column close-price DataFrame for the market proxy.      Tries ``, Return a single-column close-price DataFrame for the market proxy.      Tries `` (+18 more)

### Community 236 - "Cluster 236"
Cohesion: 0.1
Nodes (19): Analysis: Splitting the API (LLM/BAML vs Optimization/Data), API Structure, code:block1 (api/), code:block2 (┌─────────────────────────┐), code:block3 (api/), Conclusion, Coupling verdict — key finding, Directory layout (+11 more)

### Community 237 - "Cluster 237"
Cohesion: 0.11
Nodes (13): CompositeScoringConfig, Configuration for composite score construction.      Parameters     ----------, compute_equal_weight_composite(), Equal-weight composite with core/supplementary tiering.      Parameters     ----, Tests for renormalized weighted average over available groups (issue #242)., Ticker missing a group gets composite from available groups only., Ticker with all NaN group scores gets NaN composite., With all available scores = 1.0, composite = 1.0 regardless of coverage. (+5 more)

### Community 238 - "Cluster 238"
Cohesion: 0.08
Nodes (27): _build_band_rows(), build_research_optimizer(), _make_builder(), _make_opt_config(), Configuration for portfolio optimization models., Build the Cycle-3 §7.1 hard-constrained ``MeanRiskConfig``., Build the Cycle-3 §7.1 hard-constrained ``MeanRiskConfig``., Minimum-variance portfolio. (+19 more)

### Community 239 - "Cluster 239"
Cohesion: 0.1
Nodes (108): BacktestRunResponse, Response schema for a single backtest run row., FactorScoreResponse, FactorValidationReportResponse, Response schema for a single factor score row., Response schema for a factor validation report row., MacroNewsSummarizeJobResponse, MacroNewsSummarizeProgress (+100 more)

### Community 240 - "Cluster 240"
Cohesion: 0.06
Nodes (30): Empty-data and exception-path tests for validation_service (issue #825).  No exi, serialize_population handles empty and non-iterable inputs gracefully., TypeError from iterating → falls back to extracting a single Portfolio., _extract_portfolio catches exceptions on weights_dict access., _compute_aggregate_score returns 0.0 when no portfolios have valid sharpe., run_validation invokes on_progress after fold serialisation., build_cv raises ValueError for unregistered cv_type strings., build_cv succeeds for every registered cv_type with default config. (+22 more)

### Community 241 - "Cluster 241"
Cohesion: 0.05
Nodes (43): build, extract-i18n, serve, test, builder, configurations, defaultConfiguration, options (+35 more)

### Community 242 - "Cluster 242"
Cohesion: 0.11
Nodes (11): GET /api/v0/history/dividends → {items, nextPageCursor}, Fetch all pages of dividend history., General-purpose GET with retry/rate-limit logic. Returns parsed JSON., Auto-paginate a cursor-based endpoint. Returns all items.          Raises Runtim, Legacy method — delegates to _get for backwards compatibility., GET /api/v0/equity/account/cash → {blocked, free, invested, pieCash, result, tot, GET /api/v0/equity/account/info → {currencyCode, id}, GET /api/v0/equity/portfolio → list of open positions. (+3 more)

### Community 243 - "Cluster 243"
Cohesion: 0.14
Nodes (10): classify_regime(), Classify the current macro-economic regime.      Uses a simple heuristic based o, Verify composite path dispatch with merged indicators (#237)., All three composite indicators signal expansion., All three composite indicators signal recession., Composite path uses sentiment when available., Single composite column triggers composite dispatch., GDP-only data still uses the original heuristic. (+2 more)

### Community 244 - "Cluster 244"
Cohesion: 0.05
Nodes (32): for_default(), _matrix_to_bands_tuple(), Macro-regime sector weight bands for dynamic portfolio constraints.  Each regime, Return sector ``(floor, cap)`` bands for the given macro regime.      Performs a, Flatten ``SECTOR_REGIME_BANDS`` into a serialisable tuple.      Returns a tuple, resolve_sector_bands(), Unit tests for optimizer.factors._sector_bands and SectorRegimeBandsConfig., Mutating the returned dict must not affect the module-level matrix. (+24 more)

### Community 245 - "Cluster 245"
Cohesion: 0.04
Nodes (36): DataCoverageFilter, HistoricalDataFilter, LiquidityFilter, MarketCapFilter, FilterPipelineImpl, PriceFilter, for_regime(), InstitutionalFieldSpec (+28 more)

### Community 246 - "Cluster 246"
Cohesion: 0.11
Nodes (16): Direct unit tests for the service function., TestRunEntropyPoolingService, fetch_prices_df(), Entropy Pooling service: wraps build_entropy_pooling() from the optimizer librar, Fit an Entropy Pooling prior on *returns* and return posterior moments.      Arg, Fetch close prices, accepting ISO date strings (delegates to fetch_close_prices), run_entropy_pooling(), _make_returns() (+8 more)

### Community 247 - "Cluster 247"
Cohesion: 0.09
Nodes (10): for_equilibrium(), for_factor_model(), for_group_views(), for_idzorek(), for_mean_views(), Configuration for view integration frameworks., Tests for view integration configs and enums., tau=0 raises ValueError (issue #68). (+2 more)

### Community 248 - "Cluster 248"
Cohesion: 0.16
Nodes (6): _make_policy(), _make_portfolio(), Unit tests for rebalancing policy CRUD and activate endpoints.  TDD Red → Green, TestActivatePolicy, TestCreatePolicy, TestListPolicies

### Community 249 - "Cluster 249"
Cohesion: 0.03
Nodes (49): stubFor(), post, settle(), coldBootCtx, CONCENTRATION_RESPONSE, consoleErrorSpy, CORRELATION_RESPONSE, ctx (+41 more)

### Community 250 - "Cluster 250"
Cohesion: 0.3
Nodes (6): _make_portfolio(), _make_prices(), _make_snapshot(), Unit tests for the asset-class-returns endpoint.  Mocks PortfolioRepository and, Deterministic prices starting well before Jan 1 of current year., TestGetAssetClassReturns

### Community 251 - "Cluster 251"
Cohesion: 0.31
Nodes (6): _make_portfolio(), _make_position(), _make_prices(), _make_snapshot(), Unit tests for the drift analysis route endpoint.  Mocks PortfolioRepository and, TestGetDrift

### Community 252 - "Cluster 252"
Cohesion: 0.04
Nodes (92): ACCEPTED, acceptResponse(), cov, defaultSubmit(), expand(), { fixture, host, http }, { fixture, http }, { host, http } (+84 more)

### Community 253 - "Cluster 253"
Cohesion: 0.18
Nodes (11): Cycle-3 §7.3 Top-4 retighten loop.      Fit the optimiser; if ``sum(sorted(weigh, _solve_with_retighten(), _builder_from_sequence(), _config(), _FakeMeanRisk, Cycle-3 §7.3 Top-4 retighten loop tests (issue #537)., Stand-in for ``skfolio.MeanRisk`` used by the retighten loop., Builder that yields a fresh ``_FakeMeanRisk`` per call. (+3 more)

### Community 254 - "Cluster 254"
Cohesion: 0.05
Nodes (27): _build_screener_client(), _build_search_client(), _build_sector_client(), _mock_search_instance(), Unit tests for market sub-clients: search, sector_industry, screener.  Coverage, Uses _is_non_empty_df guard — empty DataFrame yields None., Uses _is_non_empty_df guard., test_when_asset_type_valid_then_correct_method_called() (+19 more)

### Community 255 - "Cluster 255"
Cohesion: 0.24
Nodes (13): build_entropy_pooling (optimizer), CamelCaseModel base, EntropyPoolingRequest schema, run_entropy_pooling service, app.schemas.views.llm_moments, app.services.optimization.optimization_service, skfolio MeanRisk, app.schemas.scenarios.stress_scenarios (+5 more)

### Community 256 - "Cluster 256"
Cohesion: 0.12
Nodes (18): create_application(), FastAPI application factory for FastAPI Template, Create and configure the FastAPI application, Create and configure the FastAPI application, Create and configure the FastAPI application, Conditionally mount the Prometheus /metrics endpoint., Setup health check and monitoring endpoints, Conditionally mount the Prometheus /metrics endpoint. (+10 more)

### Community 257 - "Cluster 257"
Cohesion: 0.14
Nodes (8): notify_failure(), Webhook notification service for pipeline failure alerts.  Supports any service, POST a failure notification to a Discord/Slack-compatible webhook.      Args:, Gap-fill: webhook error branch is LOGGED, not silently dropped (issue #826).  ``, TestWebhookErrorIsLogged, test_notifications, Unit tests for the webhook notification service., TestNotifyFailure

### Community 258 - "Cluster 258"
Cohesion: 0.13
Nodes (15): ApiKey, ApiKey SQLAlchemy model with HMAC-signed key storage., Stores hashed API keys for request authentication., db(), _make_key(), _make_test_app(), _pinned_factory(), Tests for ApiKeyAuthMiddleware and ApiKey model.  Covers: - ApiKey model: table (+7 more)

### Community 259 - "Cluster 259"
Cohesion: 0.09
Nodes (25): BackgroundJobRepository, BackgroundJobRepository.reconcile_orphans (dead-worker reaper), Status-guarded UPDATE closes worker-vs-reaper race, RepositoryBase + BaseRepository, RepositoryBase._upsert (ON CONFLICT DO UPDATE), DashboardRepository, APP_TABLES allowlist, DatabaseAdminRepository (+17 more)

### Community 260 - "Cluster 260"
Cohesion: 0.14
Nodes (23): DriftOverlayComponent, badges, byTicker, clearCssVars(), diagnosticsFor(), donutBtn, { fixture }, { fixture, host } (+15 more)

### Community 261 - "Cluster 261"
Cohesion: 0.12
Nodes (13): Unit tests for ``_shared/trading_calendar`` (issue #826).  NOTE on AC: this modu, test_when_non_year_period_then_none(), test_when_year_period_then_parsed(), TestExpectedTradingSessions, TestHasSufficientHistory, TestParsePeriodYears, get_expected_trading_sessions(), has_sufficient_history() (+5 more)

### Community 262 - "Cluster 262"
Cohesion: 0.08
Nodes (13): _information_ratio(), _project_metrics(), Annualised IR = mean(active) / std(active) × √252 (Cycle 4 §9.3)., Cast numpy scalars to float; replace NaN with None for strict JSON., Convert display-key metrics dict to JSON-safe schema dict., _to_json_safe(), Tests for research.pipeline._metrics — pure metric computation functions., TestAnnualizedReturn (+5 more)

### Community 263 - "Cluster 263"
Cohesion: 0.11
Nodes (11): build_herc(), HERCConfig, HierarchicalEqualRiskContribution configuration and factory.  No matrix inversio, Immutable configuration for :class:`HierarchicalEqualRiskContribution`.      Par, Build a skfolio :class:`HierarchicalEqualRiskContribution` from *config*.      P, Tests for HierarchicalEqualRiskContribution factory and configuration., returns(), TestBuildHERC (+3 more)

### Community 264 - "Cluster 264"
Cohesion: 0.13
Nodes (15): _make_dividend(), _make_repo_mock(), _make_t212_client_with_dividends(), Unit tests for sync_portfolio() — broker order deduplication (issue #310)., When add_event_idempotent returns None (conflict), dividends_inserted stays 0., First dividend inserts, second is a duplicate., More than 20 dividends in history — only the first 20 are processed., Dividends with no reference field pass external_id=None (no dedup). (+7 more)

### Community 265 - "Cluster 265"
Cohesion: 0.06
Nodes (34): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, current_cycle, cycle5_decisions, cycles (+26 more)

### Community 266 - "Cluster 266"
Cohesion: 0.04
Nodes (47): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, current_cycle, cycles, effort_hints, issues (+39 more)

### Community 267 - "Cluster 267"
Cohesion: 0.05
Nodes (43): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, commit_enabled, current_cycle, cycle5_decisions (+35 more)

### Community 268 - "Cluster 268"
Cohesion: 0.04
Nodes (45): activity_event_metadata, activity_events, analyst_price_targets, analyst_recommendations, background_job_errors, background_jobs, bond_yield_observations, bond_yields (+37 more)

### Community 269 - "Cluster 269"
Cohesion: 0.06
Nodes (35): $ref, items, title, type, DriftResponse, description, properties, required (+27 more)

### Community 270 - "Cluster 270"
Cohesion: 0.13
Nodes (17): flagsByTicker(), aaplBadges, actionCol, badgeText(), byTicker, exportBtn, { fixture, store }, { fixture, store, host } (+9 more)

### Community 271 - "Cluster 271"
Cohesion: 0.08
Nodes (24): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, current_cycle, cycles, effort_hints (+16 more)

### Community 272 - "Cluster 272"
Cohesion: 0.04
Nodes (47): dependencies, @angular/animations, @angular/common, @angular/compiler, @angular/core, @angular/forms, @angular/platform-browser, @angular/router (+39 more)

### Community 273 - "Cluster 273"
Cohesion: 0.08
Nodes (19): numeric(), now, downgrade(), add server defaults to timestamp columns  Revision ID: 1e14baf18033 Revises: c51, Add server_default=now() to all timestamp columns., Remove server defaults from timestamp columns., upgrade(), downgrade() (+11 more)

### Community 274 - "Cluster 274"
Cohesion: 0.23
Nodes (4): Tests for POST /api/v1/jobs/{job_id}/cancel (issues #560, #561)., End-to-end coverage of POST /api/v1/jobs/{job_id}/cancel., _seed(), TestCancelJob

### Community 275 - "Cluster 275"
Cohesion: 0.08
Nodes (23): _baseline_country_map(), _baseline_inputs(), _baseline_metrics(), _baseline_net_returns(), _baseline_sector_mapping(), _baseline_weights(), _perturb_metric(), _perturbation_health_care() (+15 more)

### Community 276 - "Cluster 276"
Cohesion: 0.2
Nodes (5): compute_allocation(), Group ticker weights by sector for a sunburst chart.      Args:         weights:, compute_allocation with empty weights returns a safe zero-node result., TestComputeAllocationEmptyData, TestComputeAllocation

### Community 277 - "Cluster 277"
Cohesion: 0.03
Nodes (32): Exception, PipelineSessionCapacityError, Raised when ``create_session`` would exceed ``MAX_CONCURRENT_SESSIONS``., mock_job_service(), _patch_step_handler(), End-to-end integration tests for the pipeline_builder HTTP layer (issue #716)., Validates issue #712 wiring — global handler maps to 422., Return a MagicMock service; patched into the steps router. (+24 more)

### Community 278 - "Cluster 278"
Cohesion: 0.17
Nodes (13): Settings (Pydantic Settings v2), Migration: drop st_rate_forecast, Migration: add macro observation tables, Migration: add economic_indicator_observations, Migration: add macro_news table, Migration: add ticker_news.full_content, Migration: drop ticker_news.related_tickers, Prometheus metrics module (+5 more)

### Community 279 - "Cluster 279"
Cohesion: 0.28
Nodes (13): CountryNewsFetcher, _is_article_recent, _parse_article_date, NewsClient, ArticleScraperProtocol, SearchClientProtocol, YFinanceClientProtocol, _classify_themes (+5 more)

### Community 280 - "Cluster 280"
Cohesion: 0.19
Nodes (13): StressScenarioItem.synthetic_data_args (build_synthetic_data sample_args), ScenarioRequest / ScenarioInlineResponse / ScenarioStoredResponse, BAML DesignStressScenarios, _clamp_scenario, _ensure_market_drawdown rationale, generate_stress_scenarios, scenario_to_synthetic_data_args, optimizer.synthetic.build_synthetic_data (+5 more)

### Community 281 - "Cluster 281"
Cohesion: 0.06
Nodes (34): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, current_cycle, cycle5_decisions, cycles (+26 more)

### Community 282 - "Cluster 282"
Cohesion: 0.37
Nodes (14): _Assembly, _fetch(), _health(), Tests for ``step_build_history`` (issue #701 — Step 5 of the wizard)., Stub for ``DataAssembly`` — handler does not introspect fields., The proxy helper must complete (and release the DB connection)     before ``buil, _seed(), test_when_assembly_missing_then_value_error_raised() (+6 more)

### Community 283 - "Cluster 283"
Cohesion: 0.12
Nodes (17): main(), Robust mean-risk with ellipsoidal mu uncertainty.  Compares standard ``MeanRisk`, build_robust_mean_risk(), Build a robust ``MeanRisk`` optimiser from *config*.      When both uncertainty, Build a robust ``MeanRisk`` optimiser from *config*.      When both uncertainty, Immutable configuration for the robust ``MeanRisk`` family.      Parameters, RobustMeanRiskConfig, TestBuildRobustMeanRisk (+9 more)

### Community 284 - "Cluster 284"
Cohesion: 0.05
Nodes (40): Algorithm, Algorithm, Algorithm, Algorithm, Algorithm, apply_delisting_returns, code:python (import pandas as pd), code:block10 (apply_delisting_returns() → DataValidator → OutlierTreater →) (+32 more)

### Community 285 - "Cluster 285"
Cohesion: 0.13
Nodes (16): Setup all exception handlers for the application, setup_exception_handlers(), _fake_request(), _handlers(), Branch coverage for app/exceptions.py.  Covers every exception class constructor, Build a minimal FastAPI app, wire handlers, then extract handler callables     f, Return a MagicMock that mimics a FastAPI ``Request``., loc with only one element (e.g. ``('body',)``) produces empty field string. (+8 more)

### Community 286 - "Cluster 286"
Cohesion: 0.09
Nodes (22): additionalProperties, description, title, type, description, title, type, description (+14 more)

### Community 287 - "Cluster 287"
Cohesion: 0.13
Nodes (7): HHI, effective-N, and top-N concentration math tests., When n > number of assets, top_n_ratio equals sum of all weights., ADDV-based days-to-liquidate and liquidity cost tests., Partial response: AAPL has data, MSFT does not., Weighted avg days uses only assets with valid ADDV., TestComputeConcentration, TestComputeLiquidity

### Community 288 - "Cluster 288"
Cohesion: 0.09
Nodes (15): _make_policy(), _make_portfolio(), _make_snapshot(), Unit tests for POST /api/v1/rebalance/decide and GET /api/v1/rebalance/preview., Calendar policy decide endpoint., Hybrid policy decide endpoint., Regression for #425: preview returns 200 with empty state when the     portfolio, When a policy exists but no snapshot, policy_type should still be populated. (+7 more)

### Community 289 - "Cluster 289"
Cohesion: 0.18
Nodes (16): ICResult, Information coefficient analysis results for a single factor., _make_assembly(), _make_oos_result(), _make_result(), _make_validation_report(), _patch_persist_factory(), _patch_pipeline() (+8 more)

### Community 290 - "Cluster 290"
Cohesion: 0.07
Nodes (30): Ad-hoc backtest portfolio_id=None fallback contract, JobAlreadyRunningError, 202-accept background-job + poll pattern, BacktestRun model, ExecutionRepository, app.metrics, observe_endpoint_latency, time_endpoint context manager (+22 more)

### Community 291 - "Cluster 291"
Cohesion: 0.24
Nodes (6): _compute_change(), _is_plausible(), Compute change = current_period_kpi - prior_period_kpi.      Defensive against n, Return True when ``value`` is finite and within the KPI sanity bound., Defensive contract: _compute_change returns a finite, bounded float.      The fu, TestComputeChange

### Community 292 - "Cluster 292"
Cohesion: 0.2
Nodes (15): CanvasStateOverlayComponent, RetryFn, btn, dimWrapper, { fixture, el }, HostComponent, overlay, projected (+7 more)

### Community 293 - "Cluster 293"
Cohesion: 0.08
Nodes (15): _mock_service_calls(), Unit tests for POST /api/v1/optimize and GET /api/v1/optimize/{run_id}.  Covers:, When tickers > threshold, job is created and 202 returned., Unknown optimizer_type raises ValueError → 422., GET /api/v1/optimize/{run_id} retrieves a completed run or returns 404., A run that exists in the DB is returned with 200., A non-existent run_id returns 404., An invalid UUID string returns 422. (+7 more)

### Community 294 - "Cluster 294"
Cohesion: 0.17
Nodes (6): Integration tests: route files resolve from domain folders (issue #613).  Verifi, Flat files moved to differently-named domain dirs → ModuleNotFoundError., TestBacktestRoutes, TestFactorsRoutes, TestOldFlatPathsRaiseModuleNotFound, TestReportsRoutes

### Community 295 - "Cluster 295"
Cohesion: 0.03
Nodes (49): _aggregate_by_sector(), AttributionError, BrinsonDecomposition, _check_sector_coverage(), compute_brinson_attribution(), compute_factor_attribution(), _compute_factor_return(), FactorAttributionResult (+41 more)

### Community 296 - "Cluster 296"
Cohesion: 0.18
Nodes (12): ActivityEvent model, ActivityEventDetail model (EAV), BrokerAccountSnapshot model, BrokerPosition model, Portfolio model, PortfolioSnapshot model, SnapshotOptimizerParam model (EAV), SnapshotSectorMapping model (+4 more)

### Community 297 - "Cluster 297"
Cohesion: 0.12
Nodes (11): A £20M micro-cap stored as 2B GBX should become 20M GBP., Israeli Agorot should be divided by 100., yfinance 'GBp' variant should also be divided by 100., Ensure the original DataFrame is not mutated., Currency map entry for a ticker not in the DataFrame is harmless., Columns listed but absent from DataFrame don't cause errors., NaN values should remain NaN after normalization., TestNormalizeFundamentals (+3 more)

### Community 298 - "Cluster 298"
Cohesion: 0.06
Nodes (25): All tickers share the base currency → no FX needed., GBP→USD: mock yf.download returns flat Close column → 'GBP' in result., TestAssembleFxRates, assemble_fx_rates(), Fetch FX rates from yfinance for all foreign currencies in the map.      Paramet, build_fx_pair_ticker(), compute_cross_rate(), FX rate pair construction and alignment utilities. (+17 more)

### Community 299 - "Cluster 299"
Cohesion: 0.06
Nodes (38): OAS(), MomentEstimationConfig, build_cov_estimator(), build_mu_estimator(), build_prior(), Factory functions for building skfolio moment estimators and priors.  ``Variance, Build a skfolio covariance estimator from *config*.      Parameters     --------, Build a skfolio covariance estimator from *config*.      Parameters     -------- (+30 more)

### Community 300 - "Cluster 300"
Cohesion: 0.04
Nodes (45): Analyst Sentiment and Revisions, Black-Litterman with Factor Views, Buffer Zones and Hysteresis, Composite Scoring, Cross-Factor Correlation Structure, Cross-Sectional Standardization, Data Limitations, Detection Lag and Out-of-Sample Efficacy (+37 more)

### Community 301 - "Cluster 301"
Cohesion: 0.05
Nodes (39): Average Drawdown, Conditional Drawdown-at-Risk, Conditional Value-at-Risk, Custom Risk Budgets, Distance Correlation, Distance Measures and Codependence, Entropic Drawdown-at-Risk, Entropic Value-at-Risk (+31 more)

### Community 302 - "Cluster 302"
Cohesion: 0.1
Nodes (24): _empty_macro(), _fred_df(), Regression tests for assemble_regime_data() ffill limit and staleness warning., A UserWarning is emitted for each column that is stale at the tail., Stale PMI triggers UserWarning mentioning the column name., Warning message contains fill_limit value and actual observation date., One warning is emitted per stale column., All columns are non-NaN at the final row when data is fresh. (+16 more)

### Community 303 - "Cluster 303"
Cohesion: 0.47
Nodes (13): _Assembly, _fetch(), Tests for ``step_persist`` (issue #710 — terminal step)., _report(), _result(), _seed(), test_when_force_persist_and_checklist_passed_then_persisted(), test_when_force_persist_but_checklist_failed_then_not_persisted() (+5 more)

### Community 304 - "Cluster 304"
Cohesion: 0.09
Nodes (12): DataAssembly, Frozen value object holding all data-assembly outputs.      All fields are set a, Return a flat summary dict of key assembly metrics., _make_assembly(), Tests for research/data/_container.py — DataAssembly frozen value object., TestComputeAssemblyHash, TestDataAssemblyDefaults, TestDataAssemblyEquality (+4 more)

### Community 305 - "Cluster 305"
Cohesion: 0.16
Nodes (13): _aggregate_diagnostics(), _norm(), _pos(), Tests for `_aggregate_diagnostics` entries + reconciliation aggregate (#796)., len(input) == len(holdings) + len(UNMAPPED entries from drops)., _row(), TestComputeDriftEndToEndAggregate, TestEntriesFromDroppedTickers (+5 more)

### Community 306 - "Cluster 306"
Cohesion: 0.12
Nodes (18): Thin wrapper managing job lifecycle around the service function., Execute batch macro calibration for multiple countries.      Args:         count, Execute batch macro calibration for multiple countries.      Args:         count, run_bulk_calibrate(), _has_failed_call(), _has_running_with_total(), _no_failed_call(), Pure-unit tests for the _run_bulk_calibrate background-job wrapper.  Calls the w (+10 more)

### Community 307 - "Cluster 307"
Cohesion: 0.38
Nodes (7): _build_repo_and_service(), _build_session_with_nyse(), _fake_session_ctx(), _index_of_first_call_with(), Progress-callback ordering contract for seed_reference_indices (#572).  Verifies, Failed NYSE lookup must not emit a misleading total sentinel., TestSeedReferenceIndicesProgressOrdering

### Community 308 - "Cluster 308"
Cohesion: 0.2
Nodes (6): fresh_client(), _make_counting_init(), Cycle 4 torture test: sub-client properties migrate to ``functools.cached_proper, Yield a freshly-built singleton; reset before and after each test., Wrap *original_init* so each invocation increments ``counters[name]``., test_when_50_threads_first_access_each_subclient_then_constructor_runs_once()

### Community 309 - "Cluster 309"
Cohesion: 0.13
Nodes (10): cleanup_backtest_runs(), _create_backtest_run(), _pending_job(), Unit tests for POST /api/v1/backtest and GET /api/v1/backtest/{job_id}.  Covers:, GET /api/v1/backtest/{job_id} polls progress for a background job., GET /api/v1/backtest/runs/{run_id} returns the persisted BacktestRun (issue #464, Insert a minimal BacktestRun row covering every NOT NULL column., Delete all BacktestRun rows after each test.      The POST endpoint calls ``db.c (+2 more)

### Community 310 - "Cluster 310"
Cohesion: 0.41
Nodes (14): _Assembly, _fetch(), _passing(), Tests for ``step_screen`` (issue #699 — Step 3 of the wizard)., Minimal stub exposing fields used by ``step_screen``., _seed(), test_when_assembly_missing_then_value_error_raised(), test_when_band_breached_above_then_band_warning_true_no_exception() (+6 more)

### Community 311 - "Cluster 311"
Cohesion: 0.14
Nodes (9): _exercise_wrapper(), _make_db_mock(), Branch coverage for optimization route helpers and background workers.  Covers:, Import and call a background worker with controlled patches., _statuses(), TestOptimizeFailRun, TestOptimizeValidateType, TestTuneWrapper (+1 more)

### Community 312 - "Cluster 312"
Cohesion: 0.1
Nodes (21): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md, prompt-mav-security.md (+13 more)

### Community 313 - "Cluster 313"
Cohesion: 0.11
Nodes (11): CalendarsClient, Sub-client for market calendars: earnings, IPO, splits, economic events., Wraps ``yf.Calendars`` for market-wide calendar data., Module-level API clients (no BaseClient)., Sub-client for market status and summary via ``yf.Market``., _collect_extras(), Sub-client for search and lookup via ``yf.Search`` and ``yf.Lookup``., Return enabled-extras keyed by attribute, ``None`` when absent. (+3 more)

### Community 314 - "Cluster 314"
Cohesion: 0.09
Nodes (17): _make_cpcv_folds(), Generate combinatorial purged cross-validation folds.      Divides *dates* into, Number of folds matches C(n_folds, n_test_folds)., When cpcv_config is given, rolling config is ignored., Purging excludes dates adjacent to test boundaries from train., Train and test dates must never overlap., TestCPCVPath, CPCVConfig (+9 more)

### Community 315 - "Cluster 315"
Cohesion: 0.06
Nodes (31): type, title, type, anyOf, title, title, type, holding_count (+23 more)

### Community 316 - "Cluster 316"
Cohesion: 0.1
Nodes (10): compute_quintile_spread(), Compute quintile portfolio returns and spread for a single factor.      At each, Tests for quintile spread return analysis., When factor scores strongly predict returns, Q5 > Q1 on average., TestAnnualisation, TestEdgeCases, TestQuintileOrdering, TestQuintileShape (+2 more)

### Community 317 - "Cluster 317"
Cohesion: 0.13
Nodes (11): Aligned bullish news + bullish view → alpha goes up., Conflicting bearish news + bullish view → alpha goes down., Zero sentiment signal → alpha unchanged (after clamping)., Even extreme conflicting signal → alpha ≥ 0.01., Even extreme aligned signal → alpha ≤ 0.99., Bearish news + bearish view (direction=-1) should boost alpha., Bullish news + bearish view (direction=-1) should reduce alpha., TestAdjustIdzorekAlpha (+3 more)

### Community 319 - "Cluster 319"
Cohesion: 0.11
Nodes (11): compute_composite_score(), Compute composite score from standardized factors.      Parameters     ---------, Compute composite score from standardized factors.      Parameters     ---------, Tests for min_coverage_groups config field (issue #242)., With min_coverage_groups=0, no tickers are filtered out., Ticker with fewer groups than threshold gets NaN., Ticker with exactly min_coverage_groups is included., Tests for return_coverage config field (issue #242). (+3 more)

### Community 320 - "Cluster 320"
Cohesion: 0.12
Nodes (9): Service returns ValueError when tickers not found → 422., Correlation views must use (ASSET1, ASSET2) == value format., Request validation before any service calls., Correlation views must be parseable as tuple format., TestCorrelationViewFormat, TestEntropyPoolingNoPriceData, TestEntropyPoolingValidation, EntropyPoolingRequest (+1 more)

### Community 321 - "Cluster 321"
Cohesion: 0.02
Nodes (78): aapl, barsBtn, donutBtn, driftWithFlags, { fixture, host }, { fixture, store }, { fixture, store, host }, flagList (+70 more)

### Community 322 - "Cluster 322"
Cohesion: 0.11
Nodes (24): sync_portfolio service, BackgroundJobService, optimization services __init__, intentional private exports for test-patching, _build_optimizer, build_pipeline service, _run_sync worker, trigger_sync endpoint (+16 more)

### Community 323 - "Cluster 323"
Cohesion: 0.11
Nodes (30): aa(), be(), bn(), ca(), da(), dn(), Ei(), H() (+22 more)

### Community 324 - "Cluster 324"
Cohesion: 0.13
Nodes (15): description, title, type, anyOf, default, description, title, portfolioName (+7 more)

### Community 325 - "Cluster 325"
Cohesion: 0.06
Nodes (35): base_commit, cache_prewarmed, cache_ttl_probe, client_alive_at, codex_model, commit_enabled, current_cycle, cycle5_decisions (+27 more)

### Community 326 - "Cluster 326"
Cohesion: 0.09
Nodes (15): for_monthly_rolling(), for_quarterly_expanding(), for_quarterly_rolling(), for_robustness_check(), MultipleRandomizedCVConfig, Configuration for model selection and cross-validation., Configuration for :class:`skfolio.model_selection.MultipleRandomizedCV`.      Du, build_multiple_randomized_cv() (+7 more)

### Community 327 - "Cluster 327"
Cohesion: 0.01
Nodes (166): err, req, ctx, mapHttpError(), completeSpy, errorA, errorB, errorSpy (+158 more)

### Community 328 - "Cluster 328"
Cohesion: 0.06
Nodes (26): _ast_imports(), _check_no_circular_import(), Cycle 2 boundary gate — circular imports, lint, mypy, size.  Issue #679: Cross-c, research.factors must import cleanly in a fresh process., research.reporting must import cleanly in a fresh process., All three packages imported together must not cause cross-package cycles., research.optimization.__all__ must be non-empty., build_research_optimizer must be present in research.optimization.__all__. (+18 more)

### Community 329 - "Cluster 329"
Cohesion: 0.16
Nodes (14): CountrySummaryResult, Macro news summary service with country mapping and LLM summarization.  Workflow, Result of a single country's news summarization., Summarize news for a single country. Returns None if skipped., Summarize a single country with error isolation.      Returns "updated", "skippe, Summarize a single country with error isolation.      Returns "updated", "skippe, Summarize a single country with error isolation.      Returns "updated", "skippe, Execute news summarization in the service layer.      Args:         request: ``M (+6 more)

### Community 330 - "Cluster 330"
Cohesion: 0.12
Nodes (15): PaginationParams, RateLimiter (dependency), BaseAPIException, create_error_response, RateLimitError, setup_exception_handlers, create_application, lifespan (+7 more)

### Community 331 - "Cluster 331"
Cohesion: 0.06
Nodes (39): attribution router, run_brinson_attribution, run_factor_attribution, backtest router, market router, DashboardRepository, resolve_sector_map (shared resolver, issue #427), dashboard portfolio-analytics router (+31 more)

### Community 332 - "Cluster 332"
Cohesion: 0.22
Nodes (10): LLM moments router, select_cov_regime_endpoint, generate_opinion_pool endpoint, _parse_personas helper, _resolve_ic_histories helper, opinion pooling router, entropy_pooling endpoint, generate_bl_views endpoint (+2 more)

### Community 333 - "Cluster 333"
Cohesion: 0.06
Nodes (27): fit_gbt_composite(), fit_ridge_composite(), predict_composite_scores(), ML-based composite scoring: ridge regression and gradient-boosted trees., Apply a fitted ridge or GBT model to produce normalised composite scores.      T, Fit a ridge regression model mapping factor scores to forward returns.      Para, Fit a gradient-boosted tree model mapping factor scores to forward returns., current_scores() (+19 more)

### Community 334 - "Cluster 334"
Cohesion: 0.1
Nodes (10): _build_response_with_every_flag(), _entry(), _every_code(), Round-trip tests for FlagInstance + DiagnosticEntry + extended DriftDiagnostics, TestDiagnosticEntryShape, TestDriftDiagnosticsExtension, TestDriftResponseFullRoundTrip, TestFlagInstanceEquality (+2 more)

### Community 335 - "Cluster 335"
Cohesion: 0.14
Nodes (12): Naive datetimes should not raise and produce a valid signal., Bullish news from today + bullish view → alpha rises., Build a sentiment Series with publish times ``ages_days`` ago., Article published exactly half_life_days ago should have weight 0.5., Recent news outweighs identical old news., Sum of two fresh articles with opposite signs cancels out., _series(), TestComputeSentimentSignal (+4 more)

### Community 336 - "Cluster 336"
Cohesion: 0.08
Nodes (19): check_survivorship_bias(), FactorPCAResult, flag_redundant_factors(), Multicollinearity diagnostics for factor score matrices., Return factor names whose VIF exceeds *vif_threshold*.      A VIF above the thre, Check for potential survivorship bias in a return panel.      Survivorship bias, Principal component analysis result for a factor score matrix.      Attributes, collinear_scores() (+11 more)

### Community 337 - "Cluster 337"
Cohesion: 0.09
Nodes (24): additionalProperties, type, additionalProperties, description, title, type, additionalProperties, description (+16 more)

### Community 338 - "Cluster 338"
Cohesion: 0.08
Nodes (16): _fit_weights(), main(), SchurComplementary gamma sweep: HRP anchor → MVP anchor.  Fits ``SchurComplement, build_schur_complementary(), SchurComplementary configuration and factory.  No matrix inversion — robust to s, Build a skfolio :class:`SchurComplementary` optimiser from *config*.      Parame, Immutable configuration for :class:`SchurComplementary`.      Parameters     ---, Build a skfolio :class:`SchurComplementary` optimiser from *config*.      Parame (+8 more)

### Community 339 - "Cluster 339"
Cohesion: 0.1
Nodes (16): auth_engine(), auth_session(), production_app(), Integration tests for ApiKeyAuthMiddleware activation in production (issue #429), Middleware is live: protected routes require a valid X-API-Key., Middleware is live: protected routes require a valid X-API-Key., Public paths declared in ``ApiKeyAuthMiddleware.PUBLIC_PATHS`` must not 401., Public paths declared in ``ApiKeyAuthMiddleware.PUBLIC_PATHS`` must not 401. (+8 more)

### Community 340 - "Cluster 340"
Cohesion: 0.12
Nodes (11): TestToFloat, Coerce a DB value (Decimal / int / None) to float., _to_float(), _to_float(2.5) returns 2.5., _to_float(0) returns 0.0., _to_float(Decimal('-3.14')) returns -3.14., Tests for _to_float coercion helper., _to_float(None) returns None. (+3 more)

### Community 341 - "Cluster 341"
Cohesion: 0.12
Nodes (15): 1. Result service + store wiring, 2. Allocation donut + weight bars, 3. Efficient frontier with "you are here", 4. Backtest sparkline, 5. Canvas view toggle, 6. Right analytics pane, 7. Live-state UX, Constraints (+7 more)

### Community 342 - "Cluster 342"
Cohesion: 0.12
Nodes (17): description, items, $ref, title, type, items, total, trades (+9 more)

### Community 343 - "Cluster 343"
Cohesion: 0.08
Nodes (24): repo, full, host, name, owner, _make_prices(), Tests for survivorship-bias fix in run_full_pipeline (issue #274)., Tickers not in the DataFrame are filtered out, no error raised. (+16 more)

### Community 344 - "Cluster 344"
Cohesion: 0.09
Nodes (23): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md, prompt-mav-security.md (+15 more)

### Community 345 - "Cluster 345"
Cohesion: 0.17
Nodes (9): _build_country_fetcher(), _make_article(), _make_yf_client(), Unit tests for news sub-clients: client + aggregator.  Coverage targets --------, Return a mock YFinanceClientProtocol with ticker.news configured.      Pass ``ne, TestCountryNewsFetcher, TestNewsClientFetch, _today_iso() (+1 more)

### Community 346 - "Cluster 346"
Cohesion: 0.11
Nodes (6): _pending_job(), Unit tests for POST /api/v1/validate/walk-forward and GET /api/v1/validate/walk-, GET /api/v1/validate/walk-forward/{job_id} polls job progress., POST /api/v1/validate/walk-forward starts a background job., TestGetValidateWalkForward, TestPostValidateWalkForward

### Community 347 - "Cluster 347"
Cohesion: 0.05
Nodes (13): Tests for moment estimation factory functions., Existing presets must survive the new field additions., The match dispatch rejects unknown estimator values (defensive guard)., Existing presets must survive the new field additions., Integration tests using real skfolio fit/predict., Integration tests using real skfolio fit/predict., TestBuildCovEstimator, TestBuildCovEstimatorNested (+5 more)

### Community 348 - "Cluster 348"
Cohesion: 0.08
Nodes (26): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-ldb-debug.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md (+18 more)

### Community 349 - "Cluster 349"
Cohesion: 0.06
Nodes (21): for_custom(), _build_ir_scorer(), build_scorer(), Factory functions for building scoring functions., Build a scoring callable compatible with sklearn cross-validation.      Paramete, Build an annualised Information Ratio scorer from benchmark returns.      IR = a, Tests for scoring factory functions., All RatioMeasureType members except IR build without benchmark_returns. (+13 more)

### Community 350 - "Cluster 350"
Cohesion: 0.05
Nodes (27): Benchmark Tracking, Budget Constraint, Conditional Stress Testing, Constraints, Covariance Uncertainty Sets, Custom Linear Constraints, Distributionally Robust CVaR, Ensemble Optimization (+19 more)

### Community 351 - "Cluster 351"
Cohesion: 0.06
Nodes (28): _build_factor_scores_dict(), _build_multiindex_factor_df(), _build_multiindex_returns(), _build_returns_from_price_rows(), _build_standardized_scores_df(), _fetch_price_rows(), _notify(), Shared helpers and constants for the factor service modules.  Used across factor (+20 more)

### Community 352 - "Cluster 352"
Cohesion: 0.05
Nodes (38): 1. `validate` -- DataValidator, 2. `outliers` -- OutlierTreater, 3. `impute` -- SectorImputer, 4. `select_complete` -- SelectComplete, 5. `drop_zero_variance` -- DropZeroVariance, 6. `drop_correlated` -- DropCorrelated, 7. `select_k` -- SelectKExtremes (optional), 8. `select_pareto` -- SelectNonDominated (optional) (+30 more)

### Community 354 - "Cluster 354"
Cohesion: 0.12
Nodes (13): compute_group_scores(), compute_ic_weighted_composite(), Average factor scores within each group.      Parameters     ----------     stan, IC-weighted composite score.      Uses trailing information coefficient history, IC-weighted composite score.      Uses trailing information coefficient history, No warning when at least one group has positive IC., Tests for IC_WEIGHTED clamping negative IC to zero (issue #55)., A group with negative mean IC should get zero weight. (+5 more)

### Community 355 - "Cluster 355"
Cohesion: 0.22
Nodes (6): generate_country_summaries(), Generate daily news summaries for mapped countries.      Args:         session:, Generate daily news summaries for mapped countries.      Args:         session:, _make_llm_output(), TestGenerateCountrySummaries, TestSummarizeCountry

### Community 356 - "Cluster 356"
Cohesion: 0.2
Nodes (11): RateLimitingMiddleware, Rate limiting middleware for API protection, Simple in-memory rate limiting middleware for basic protection, Simple in-memory rate limiting middleware for basic protection, Cleanup old entries from all clients to prevent memory leaks, Cleanup old entries from all clients to prevent memory leaks, _call_next_200(), _make_request() (+3 more)

### Community 357 - "Cluster 357"
Cohesion: 0.44
Nodes (12): _Assembly, _fetch(), _oos(), _opt_result(), Tests for ``step_optimize`` (issue #706 — Step 10 of the wizard)., _seed(), test_when_hockey_stick_warning_logged_then_payload_flag_true(), test_when_no_country_map_in_run_config_then_country_breakdown_empty() (+4 more)

### Community 358 - "Cluster 358"
Cohesion: 0.33
Nodes (3): _make_etf_instrument(), Unit tests for GET /api/v1/market/indices.  Mocks DashboardRepository at the rou, TestGetMarketIndices

### Community 359 - "Cluster 359"
Cohesion: 0.02
Nodes (109): HelpTooltipComponent, a, AdaptFactorWeightsRequest, AdaptFactorWeightsResponse, AssetViewResponse, CalibrateDeltaRequest, CalibrateDeltaResponse, CovEstimatorType (+101 more)

### Community 360 - "Cluster 360"
Cohesion: 0.1
Nodes (19): 10. Accessibility + interaction baseline (real-user reachability), 11. Green-gate the whole tree, 1. API endpoint contract coverage (routes layer), 2. API service logic coverage (services layer), 3. Background jobs, scheduler, and pipeline-builder session lifecycle, 4. Frontend service coverage (28 services), 5. Frontend component coverage — pages and features (129 components), 6. Frontend shared component coverage (`shared/`) (+11 more)

### Community 361 - "Cluster 361"
Cohesion: 0.09
Nodes (9): _completed_job(), _pending_job(), Unit tests for POST /api/v1/reports/generate and related endpoints.  TDD: tests, POST /api/v1/reports/generate validates the request body., GET /api/v1/reports/jobs/{job_id} polls job progress., POST /api/v1/reports/generate returns 202 and job_id., TestGetReportJobStatus, TestPostGenerateReport (+1 more)

### Community 362 - "Cluster 362"
Cohesion: 0.36
Nodes (12): _Assembly, _fetch(), _make_prices(), Tests for ``step_slice`` (issue #698 — Step 2 of the wizard)., Insert a real session and overwrite its assembly field., _seed_session(), test_when_both_dates_none_then_no_op_payload_returned(), test_when_both_dates_set_then_assembly_replaced_and_payload_reports_slice() (+4 more)

### Community 363 - "Cluster 363"
Cohesion: 0.15
Nodes (25): B(), Br(), ci(), cs(), en(), Go(), hi(), k() (+17 more)

### Community 364 - "Cluster 364"
Cohesion: 0.09
Nodes (23): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md, prompt-mav-security.md (+15 more)

### Community 365 - "Cluster 365"
Cohesion: 0.13
Nodes (13): SchedulerStatusPanelComponent, banner, fx, jobs, labels, orphanList, renderedNameCells, SchedulerJobStatusDto (+5 more)

### Community 366 - "Cluster 366"
Cohesion: 0.15
Nodes (39): ai(), an(), ba(), de(), ds(), er(), es(), fi() (+31 more)

### Community 367 - "Cluster 367"
Cohesion: 0.06
Nodes (27): daily_dates(), gross(), prices(), Tests for research/_returns.py — Cycle 4 §9.2 after-tax returns., portfolio_value <= 0 → skip tax (no division by zero)., 20 business days for a backtest series., Default tax rate is 0.26 (Italy capital-gains)., Issue #555 — gap coverage on top of TestComputeAfterTaxReturns.      Closes cove (+19 more)

### Community 368 - "Cluster 368"
Cohesion: 0.06
Nodes (18): _add_existing_flags(), _add_new_flags(), build_parser(), _parse_iso_date(), Argparse surface for research pipeline (Cycle 5 §13).  Exposes the 9-flag CLI as, Parse an ISO ``YYYY-MM-DD`` string; raise on invalid input., Build the 9-flag argparse parser for the research pipeline., Tests for ``research/cli/_parser.py`` — issue #550 (9-flag CLI surface). (+10 more)

### Community 369 - "Cluster 369"
Cohesion: 0.05
Nodes (38): Architecture, code:bash (pip install portopt), code:bash (pip install -e ".[dev]"), code:bash (# Start PostgreSQL), code:bash (git clone https://github.com/SilvioBaratto/optimizer.git), code:python (from optimizer.optimization import MeanRiskConfig, build_mea), code:block4 (prices -> returns -> [preprocess -> pre-select -> optimize] ), code:python (MeanRiskConfig.for_max_sharpe()           # maximize Sharpe ) (+30 more)

### Community 370 - "Cluster 370"
Cohesion: 0.1
Nodes (13): Report generation service.  SOLID design:   - ReportDataAggregator: single respo, Query latest completed optimization run weights via ExecutionRepository., Query latest completed optimization run weights via ExecutionRepository., Query latest completed backtest summary_stats via ExecutionRepository., Query latest completed backtest summary_stats via ExecutionRepository., Parse an optional UUID string. ``None`` passes through (issue #463)., Return latest portfolio weights., Return latest portfolio weights. (+5 more)

### Community 371 - "Cluster 371"
Cohesion: 0.03
Nodes (106): Atomically replace ``session_id`` with the patched dataclass., Atomically replace ``session_id`` with the patched dataclass., update_session(), _breakdown(), _coverage_membership(), _high_vif_factors(), _HockeyStickWatcher, _ic_records() (+98 more)

### Community 372 - "Cluster 372"
Cohesion: 0.15
Nodes (21): ar(), cr(), Do(), dr(), ha(), Ir(), lr(), lt() (+13 more)

### Community 373 - "Cluster 373"
Cohesion: 0.18
Nodes (8): Shared helpers for JSON-safe numeric conversion.  PostgreSQL's JSONB type (and s, Return ``v`` as a finite float, or ``None`` for NaN/Inf/None/unparsable.      Ar, safe_float(), Unit tests for ``_shared/_json_safe.safe_float`` (issue #826)., test_when_inf_then_returns_none(), test_when_nan_then_returns_none(), test_when_non_castable_then_returns_none(), TestSafeFloat

### Community 374 - "Cluster 374"
Cohesion: 0.05
Nodes (38): 10. SSR Notes, 11. Gotchas Checklist, 12. Minimal Project Layout, 13. Reference Links, 1. Why Raw ECharts (No Wrapper), 2. Installation, 3. Tree-Shaking with Dynamic Imports, 4. Global Theme via `APP_INITIALIZER` (+30 more)

### Community 375 - "Cluster 375"
Cohesion: 0.13
Nodes (21): make_cancellable_progress cancel-aware closure, BackgroundJobService, ExecutionRepository, run_and_persist, _run_backtest_bg, start_backtest, FRED_SERIES, get_t212_client dependency (+13 more)

### Community 376 - "Cluster 376"
Cohesion: 0.08
Nodes (16): DistanceConfig, Immutable configuration for distance estimator construction.      Parameters, main(), HRP with mutual-information distance and Ward clustering.  Hierarchical Risk Par, build_hrp(), for_distance(), HRPConfig, HierarchicalRiskParity configuration and factory.  No matrix inversion — robust (+8 more)

### Community 377 - "Cluster 377"
Cohesion: 0.06
Nodes (34): Code Examples, code:block1 (|-------- train --------|-- test --|), code:python (factor_scores_history, returns_history, build_health = build), code:python (from optimizer.validation import WalkForwardConfig), code:python (from optimizer.validation import CPCVConfig), code:python (from optimizer.validation import MultipleRandomizedCVConfig), code:python (from optimizer.validation import WalkForwardConfig, run_cros), code:python (from optimizer.validation import compute_optimal_folds) (+26 more)

### Community 378 - "Cluster 378"
Cohesion: 0.08
Nodes (18): apply_regime_tilts(), Apply regime-conditional multiplicative tilts to group weights.      Parameters, Cycle-2 spec: RECESSION dampens VALUE (multiplier < 1.0)., Cycle-2 spec: EXPANSION boosts VALUE (multiplier > 1.0)., Tests for capped tilt multipliers and weight floor (issue #279)., A raw tilt of 10x is clamped to max_tilt_multiplier., Tilts within the cap are applied without modification., A suppressed group is raised to min_post_tilt_weight * total. (+10 more)

### Community 379 - "Cluster 379"
Cohesion: 0.09
Nodes (13): compute_weighted_cost_bps(), Step 7 — Portfolio optimization.  Extracted from ``stock_selection_pipeline.py``, Portfolio-weighted total round-trip cost in bps (Cycle 4 §9.1)., Portfolio-weighted total round-trip cost in bps (Cycle 4 §9.1)., _country_total(), Tests for ``compute_weighted_cost_bps`` (Cycle 4 §9.1) — issue #554.  Per-countr, TestCountryCostsConstants, TestDefaultFallback (+5 more)

### Community 380 - "Cluster 380"
Cohesion: 0.12
Nodes (11): Tests for ``research/reporting/`` module boundaries — issue #677.  Covers five a, Verify _plots.py only references optimizer.* / research.* under TYPE_CHECKING., Return module names imported at runtime (excluding TYPE_CHECKING blocks)., The template directory resolved by _report.py must exist on disk., The file ``report.md.j2`` must exist inside the resolved template dir., Every name in research.reporting.__all__ must be importable., ``import research.reporting`` in a subprocess must exit 0., TestNoCircularImports (+3 more)

### Community 381 - "Cluster 381"
Cohesion: 0.12
Nodes (8): for_calmar(), for_cvar_ratio(), for_sharpe(), for_sharpe_with_rf(), for_sortino(), Configuration for performance scoring functions., Tests for scoring configs., TestScorerConfig

### Community 382 - "Cluster 382"
Cohesion: 0.12
Nodes (12): Validate and normalize LLM output into a dict for persistence., _validate_llm_output(), _fake_llm_output(), _make_article(), Unit tests for macro_news_summary service (issue #822).  Covers gaps NOT in test, Regression guard: commit must fire 1 (pre-loop) + n_countries times.          Th, Country with <3 articles must be skipped (no LLM call, result=None)., test_when_valid_sentiment_label_then_passed_through() (+4 more)

### Community 383 - "Cluster 383"
Cohesion: 0.14
Nodes (12): build_universe(), clear_cache(), get_cache_stats(), get_stats(), get_universe_config(), list_instruments(), FastAPI router for Trading212 universe endpoints., Get exchange and instrument counts. (+4 more)

### Community 384 - "Cluster 384"
Cohesion: 0.07
Nodes (28): get_dividends(), get_fetch_status(), get_financials(), get_insider_transactions(), get_institutional_holders(), get_mutualfund_holders(), get_news(), get_price_targets() (+20 more)

### Community 385 - "Cluster 385"
Cohesion: 0.05
Nodes (50): _check_country_coverage(), _check_fred_freshness(), _check_fx_coverage(), _check_price_coverage(), _check_price_staleness(), _check_universe_coverage(), _coerce_date(), _DbManagerLike (+42 more)

### Community 386 - "Cluster 386"
Cohesion: 0.12
Nodes (15): 1. T212 → standard-ticker resolver (backend), 2. EUR normalization layer (backend), 3. Drift endpoint, 4. Drift canvas view, 5. Trade list panel, 6. Edge-case + diagnostics surface, 7. Caching + rate-limit hygiene, Constraints (+7 more)

### Community 387 - "Cluster 387"
Cohesion: 0.18
Nodes (6): BacktestRun, Persisted result of a single call to ``POST /api/v1/backtest``.      ``portfolio, BacktestRun rows can be inserted with required and optional fields., BacktestRun exposes portfolio and job relationship attributes., TestBacktestRunInsertion, TestBacktestRunRelationships

### Community 388 - "Cluster 388"
Cohesion: 0.1
Nodes (13): BenchmarkTrackerConfig, build_benchmark_tracker(), BenchmarkTracker configuration and factory.  Benchmark returns are passed as ``y, Immutable configuration for :class:`BenchmarkTracker`.      Note: the benchmark, Build a skfolio :class:`BenchmarkTracker` from *config*.      The benchmark retu, benchmark(), Tests for BenchmarkTracker factory and configuration., Equal-weight benchmark (mean across the universe). (+5 more)

### Community 389 - "Cluster 389"
Cohesion: 0.08
Nodes (26): anyOf, default, description, title, description, title, type, description (+18 more)

### Community 390 - "Cluster 390"
Cohesion: 0.33
Nodes (6): _build_insert_sql(), downgrade(), Expand reference-index seed to 10 canonical benchmarks (issue #430).  The preced, Return the idempotent, exchange-guarded INSERT statement for one ETF., Remove the nine rows seeded by this migration.      SPY is left untouched — it i, upgrade()

### Community 391 - "Cluster 391"
Cohesion: 0.19
Nodes (13): _create_exchanges_and_instruments_tables(), Tests for migration x4y5z6a7b8c9: seed_reference_indices.  Covers: - Migration m, The WHERE EXISTS guard must prevent insertion when NYSE is missing., Fresh DB without NYSE: INSERT is a no-op due to WHERE EXISTS guard., DB with NYSE: INSERT succeeds and SPY row is present., Inserted SPY row must have correct ticker and instrument_type., Running upgrade twice with NYSE present must not fail or duplicate SPY., downgrade() must delete the SPY row inserted during upgrade. (+5 more)

### Community 392 - "Cluster 392"
Cohesion: 0.1
Nodes (20): _make_df(), When currencies are identical, fewer NaNs should win., USD should win in a three-way contest (USD, EUR, GBX)., Single-listing tickers should pass through unchanged., Row with None currency should lose to any known currency., Temporary columns (_raw_currency, _ccy_rank, _nan_count) must not leak., Result should be identical regardless of row ordering., Result index must have no duplicates. (+12 more)

### Community 393 - "Cluster 393"
Cohesion: 0.47
Nodes (11): _fetch(), Tests for ``step_cost`` (issue #708 — Step 12)., _result(), _seed(), test_when_actual_below_assumed_then_exceeds_assumed_false(), test_when_no_country_map_then_default_costs_used(), test_when_optimize_result_missing_then_value_error_raised(), test_when_override_adds_new_country_then_used_for_that_country() (+3 more)

### Community 394 - "Cluster 394"
Cohesion: 0.29
Nodes (7): ReportDataAggregator.collect_sections, ReportService.generate, graceful section degradation rationale, PdfBuilder, ReportDataAggregator, ReportService, reports services __init__

### Community 395 - "Cluster 395"
Cohesion: 0.13
Nodes (16): _build_result_mock(), _db_ctx_mock(), _make_request(), Branch-coverage tests for app.api.v1.universe.trading212 (missed lines 68-128, 1, Line 76: when skip_filters=True, no filters are added to the pipeline., Lines 126-133: build() raises → update_job(status="failed", error=...)., Line 151: api key truthy → returns Trading212Client instance., Line 256: job dict with truthy result → BuildResultResponse constructed. (+8 more)

### Community 396 - "Cluster 396"
Cohesion: 0.11
Nodes (17): _assert_universe_size(), Step 2 — Investability screening.  Extracted from ``stock_selection_pipeline.py`, Enforce universe-size floor and warn on out-of-band counts (issue #520)., Enforce universe-size floor and warn on out-of-band counts (issue #520)., Apply investability screens and return the passing ticker index., Apply investability screens and return the passing ticker index., screen_investable(), _make_passing() (+9 more)

### Community 397 - "Cluster 397"
Cohesion: 0.1
Nodes (15): Sector-average NaN imputation transformer., Return feature names (pass-through)., Fill NaN values using sector cross-sectional averages.      For each timestep (r, Build the internal sector → columns index., Fill NaN with leave-one-out sector averages., SectorImputer, _validate_input(), Regression-based NaN imputation from correlated neighbor assets. (+7 more)

### Community 398 - "Cluster 398"
Cohesion: 0.08
Nodes (18): compute_gross_alpha(), factor_scores_to_expected_returns(), Bridge factor scores to expected returns via CAPM + factor tilt model., Convert factor Z-scores to expected returns via linear model.      Implements th, Compute gross alpha by adding back estimated transaction costs.      Formula::, betas(), Tests for factor_scores_to_expected_returns (factor alpha bridge)., Assets absent from betas should default to β=1.0. (+10 more)

### Community 399 - "Cluster 399"
Cohesion: 0.27
Nodes (12): _now(), Unit tests for the news sentiment pipeline (issue #13)., Build a mock SentimentRepository with configured return values., test_baml_failure_returns_empty_series(), test_macro_news_fallback_used(), test_mismatched_score_count_padded(), test_mismatched_score_count_truncated(), test_none_publish_time_handled() (+4 more)

### Community 400 - "Cluster 400"
Cohesion: 0.05
Nodes (29): PriceRow, Lightweight container for a single price observation., _make_profile(), MarketDataSeed, DB seed builder for the market_data domain.  Seeds ``Exchange`` + ``Instrument``, seed_market_data(), get_or_create_exchange(), get_or_create_instrument() (+21 more)

### Community 401 - "Cluster 401"
Cohesion: 0.5
Nodes (11): _fetch(), _is_report(), _oos_result(), Tests for ``step_coverage_gate`` (issue #704 — Step 8 of the wizard)., _seed(), test_when_gate_fails_then_session_not_updated(), test_when_is_result_missing_then_value_error_raised(), test_when_min_factors_param_override_then_lower_threshold_passes() (+3 more)

### Community 402 - "Cluster 402"
Cohesion: 0.1
Nodes (21): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md, prompt-mav-security.md (+13 more)

### Community 403 - "Cluster 403"
Cohesion: 0.24
Nodes (7): _fake_assembly(), Tests for ``step_load`` (issue #697 — Step 1 of the wizard).  Covers:  * happy p, test_when_base_currency_missing_then_defaults_to_eur(), test_when_load_data_runs_then_progress_phases_emitted_in_order(), test_when_load_data_succeeds_then_assembly_persisted_in_session(), test_when_load_data_succeeds_then_returns_json_safe_summary(), test_when_n_selected_default_missing_then_falls_back_to_20()

### Community 404 - "Cluster 404"
Cohesion: 0.39
Nodes (11): _fetch(), _ICResult, Tests for ``step_validate_is`` (issue #702 — Step 6 of the wizard)., Mirror of ``optimizer.factors._validation.ICResult`` fields., _report(), _seed(), test_when_factor_scores_dict_missing_then_value_error_raised(), test_when_no_factor_above_vif_5_then_high_vif_factors_empty() (+3 more)

### Community 405 - "Cluster 405"
Cohesion: 0.14
Nodes (10): _is_fresh(), Return True if the data is still within the freshness window., Return True if the data is still within the freshness window., Return True if the data is still within the freshness window., Line 104-105: updated_at None → immediately return False., Line 107-108: naive updated_at is normalized to UTC for comparison., Lines 109-110: naive `now` is normalized to UTC., Normal stale path: updated_at older than threshold → False. (+2 more)

### Community 406 - "Cluster 406"
Cohesion: 0.1
Nodes (25): _mark_step_completed(), _mark_step_running(), _now_iso(), _parse_body(), post_step(), Foundational primitives for ``pipeline_builder`` step handlers (issue #696).  Th, Thin adapter for ``start_background`` — args[0] must be the job_id string., Thin adapter for ``start_background`` — args[0] must be the job_id string. (+17 more)

### Community 407 - "Cluster 407"
Cohesion: 0.06
Nodes (34): Absolute vs Relative Thresholds, Calendar Rebalancing, Code Examples, code:python (from optimizer.rebalancing import CalendarRebalancingConfig,), code:python (from optimizer.rebalancing import compute_turnover), code:python (from optimizer.rebalancing import compute_rebalancing_cost), code:python (from optimizer.optimization import MeanRiskConfig, build_mea), code:python (from optimizer.rebalancing import HybridRebalancingConfig) (+26 more)

### Community 409 - "Cluster 409"
Cohesion: 0.08
Nodes (16): TestClassifyThemes, TestMacroSearchQueriesMapping, TestMacroTickersMapping, TestMakeNewsId, _classify_themes(), MacroNewsFetcher, MacroTheme, _make_news_id() (+8 more)

### Community 410 - "Cluster 410"
Cohesion: 0.12
Nodes (8): build_covariance_uncertainty_set(), Build a skfolio covariance uncertainty-set estimator from *config*., Tests for uncertainty-set factory functions., returns(), TestBuildCovarianceUncertaintySet, TestEnums, TestIntegration, TestPresets

### Community 411 - "Cluster 411"
Cohesion: 0.11
Nodes (6): _pending_job(), Unit tests for POST /api/v1/tune and GET /api/v1/tune/{job_id}.  Covers:   - POS, GET /api/v1/tune/{job_id} polls progress for a background job., POST /api/v1/tune always launches a background job., TestGetTuneJob, TestPostTune

### Community 412 - "Cluster 412"
Cohesion: 0.06
Nodes (16): _build_smoke_body_via_sh(), _extract_function_body(), Structural + syntax tests for the walk-forward smoke stage in scheduler/fetch.sh, AC: inline comments document the new flag, env vars, and defaults., Verify the jq-built request body is structurally correct.      Runs the body-con, Execute the body-construction snippet to verify JSON shape end-to-end., Extract the body of a POSIX sh function by brace matching., The script must remain valid POSIX sh after modification. (+8 more)

### Community 413 - "Cluster 413"
Cohesion: 0.14
Nodes (14): prompt_hashes, prompt-cycle-specializer.md, prompt-optimize-requirements.md, prompt-phase-0-complexity.md, prompt-phase-1-planning.md, prompt-phase-2-batch-review.md, prompt-phase-3-implementation.md, prompt-phase-5-final-review.md (+6 more)

### Community 414 - "Cluster 414"
Cohesion: 0.11
Nodes (15): _build_history_panel(), _import_slicer(), Tests for point-in-time fundamental history slicing (issue #245)., Data older than lag_days should be available., Quarterly lag (45 days) should pick up more recent data than annual., Should return empty when all data is too recent., Verify the PIT cross-section slicer., Values at early date should differ from late date. (+7 more)

### Community 415 - "Cluster 415"
Cohesion: 0.06
Nodes (32): 1. Table Catalog, 2. Relationship Map, 3. Base Model Pattern, 4. Design Patterns, 5. Connection & Configuration, 6. Migration Conventions, 7. Common Query Patterns, 8. How to Add a New Table (+24 more)

### Community 417 - "Cluster 417"
Cohesion: 0.47
Nodes (6): attribution schemas package init, Brinson & Factor attribution schemas, CamelCaseModel / StrFromUUID base schema, AsyncJobCreateResponse / AsyncJobProgress base schemas, schemas package aggregator, shared schemas package init

### Community 418 - "Cluster 418"
Cohesion: 0.33
Nodes (6): bootstrap_benchmarks startup seeding, fetch_close_prices from price_history, Unify Attribution/Dashboard sector lookup (issue #427), resolve_sector_map (snapshot-first, TickerProfile fallback), has_sufficient_history validation gate, Exchange trading calendar session estimation

### Community 419 - "Cluster 419"
Cohesion: 0.33
Nodes (5): app.services...news.macro_news.MACRO_SEARCH_QUERIES, scripts package doc, evaluate_query, MACRO_SEARCH_QUERIES (validation target), main (validate_macro_queries)

### Community 420 - "Cluster 420"
Cohesion: 0.6
Nodes (6): _load_fundamentals, run_factor_compute, align_to_pit, compute_all_factors, PublicationLagConfig, test_factor_compute_service

### Community 421 - "Cluster 421"
Cohesion: 0.33
Nodes (6): Rich CLI display layer, Backtest matplotlib chart generation, research.reporting package init, research.strategies package init, Portfolio inspection: data_summary and strategies, Strategy runner glue layer

### Community 423 - "Cluster 423"
Cohesion: 0.16
Nodes (33): a(), Ae(), as(), Bo(), bs(), ce(), e(), Ee() (+25 more)

### Community 424 - "Cluster 424"
Cohesion: 0.13
Nodes (16): BrokerSyncResult, BrokerSyncResult, sync_portfolio, portfolio-analytics dashboard route, get_market_snapshot, skip missing-ticker weights rationale (#423), portfolio services __init__, PortfolioRepository (+8 more)

### Community 425 - "Cluster 425"
Cohesion: 0.11
Nodes (18): body, FactorComputeJobResponse, FactorComputeRequest, FactorComputeStatusResponse, FactorScoreRequest, FactorScoreResponse, FactorSelectRequest, FactorSelectResponse (+10 more)

### Community 426 - "Cluster 426"
Cohesion: 0.44
Nodes (10): _fetch(), Tests for ``step_validate_oos`` (issue #703 — Step 7 of the wizard)., _result(), _seed(), test_when_factor_missing_from_icir_then_payload_icir_is_none(), test_when_factor_scores_dict_missing_then_value_error_raised(), test_when_returns_history_missing_then_value_error_raised(), test_when_validate_oos_raises_n_folds_zero_then_message_propagates_verbatim() (+2 more)

### Community 427 - "Cluster 427"
Cohesion: 0.06
Nodes (25): Gate tests for research/optimization/__init__.py API contract.  Convention: The, __all__ must be in ascending lexicographic order., Every symbol from _config.py must appear in __all__., Every symbol from _retighten.py must appear in __all__., Every symbol from _rebalance.py must appear in __all__., __all__ must contain every required symbol (bulk check)., __all__ must not contain duplicate entries., research.optimization must have a non-empty module docstring. (+17 more)

### Community 428 - "Cluster 428"
Cohesion: 0.14
Nodes (16): _make_repo(), _make_yf_client_silent(), Branch coverage for YFinanceDataService residual paths.  Targets: app/services/m, Return a minimal price history DataFrame with enough rows., Short fetch + prior price data → protect existing series, skip upsert., Short fetch + no prior price data → young listing, accept and store., When staleness is already populated (not None), price_max_date read from it,, _run() (+8 more)

### Community 429 - "Cluster 429"
Cohesion: 0.4
Nodes (4): Run migrations in 'offline' mode., Run migrations in 'online' mode., run_migrations_offline(), run_migrations_online()

### Community 430 - "Cluster 430"
Cohesion: 0.11
Nodes (23): _build_run_data(), _execute_and_persist(), _fail_run(), get_optimize_run(), _handle_async(), _handle_sync(), post_optimize(), FastAPI router for portfolio optimization endpoints.  Supports synchronous execu (+15 more)

### Community 431 - "Cluster 431"
Cohesion: 0.5
Nodes (4): CircuitBreaker, RateLimiter, retry_with_backoff / is_transient_network_error (shared infrastructure), retry_with_backoff()

### Community 432 - "Cluster 432"
Cohesion: 0.11
Nodes (18): assemble_regime_data(), Merge macro indicators into a single DataFrame for regime classification.      C, _dated(), when trailing NaN exceeds fill_limit, UserWarning emitted., when gap fits within fill_limit, last value is not NaN., when data provided, result index is DatetimeIndex., when a part has non-DatetimeIndex, UserWarning about coercion emitted., when all inputs are empty, empty DataFrame returned. (+10 more)

### Community 433 - "Cluster 433"
Cohesion: 0.4
Nodes (5): BacktestProgressResponse, AsyncJobProgress, ValidateProgress, YFinanceFetchProgress, YFinanceFetchRequest

### Community 434 - "Cluster 434"
Cohesion: 0.4
Nodes (5): RiskAnalyticsService.compute_factor_exposure, RiskAnalyticsService.compute_var, _historical_var_cvar, _parametric_var_cvar, RiskAnalyticsService

### Community 435 - "Cluster 435"
Cohesion: 0.5
Nodes (5): test_universe_screen_routes, test_universe_screening_service, universe_screen route run_universe_screen, UniverseScreenRequest, universe_screening_service

### Community 436 - "Cluster 436"
Cohesion: 0.5
Nodes (5): test_llm_moments, test_sentiment, llm_moments service, sentiment service, view_generation service

### Community 437 - "Cluster 437"
Cohesion: 0.4
Nodes (5): attribution route, MissingDataError, run_brinson_attribution, run_factor_attribution, test_attribution_routes

### Community 438 - "Cluster 438"
Cohesion: 0.6
Nodes (5): Instrument model, TickerProfile model, Resolve sector via Instrument.yfinance_ticker not Instrument.ticker (trading212 422 fix), resolve_sector_map, test_sector_resolver

### Community 439 - "Cluster 439"
Cohesion: 0.4
Nodes (5): CovarianceUncertaintySetConfig, MuUncertaintySetConfig, _validate_bootstrap_only_fields, build_covariance_uncertainty_set, build_mu_uncertainty_set

### Community 440 - "Cluster 440"
Cohesion: 0.4
Nodes (5): CovarianceForecastConfig, OnlineCovarianceForecastConfig, run_covariance_forecast_evaluation, run_online_covariance_forecast_evaluation, _validate_partial_fit

### Community 441 - "Cluster 441"
Cohesion: 0.6
Nodes (5): Rolling 252-Day Sharpe Ratio Chart, Rolling 252-Day Sharpe Ratio (risk-adjusted return), Backtest Window Mar 2025 - Feb 2026, Sharpe = 1.0 Reference Threshold, Upward Trend: -0.5 trough (Apr 2025) rising to ~2.5 (Feb 2026)

### Community 444 - "Cluster 444"
Cohesion: 0.1
Nodes (6): _pending_job(), Unit tests for POST /api/v1/factors/compute and GET /api/v1/factors/compute/{job, GET /api/v1/factors/compute/{job_id} polls progress., POST /api/v1/factors/compute launches a background job, returns 202., TestGetFactorComputeJob, TestPostFactorCompute

### Community 445 - "Cluster 445"
Cohesion: 0.16
Nodes (8): compute_icir_weighted_composite(), ICIR-weighted composite score.      Weights each group by ``max(ICIR, 0) = max(m, ICIR-weighted composite score.      Weights each group by ``max(ICIR, 0) = max(m, n_negative in warning reflects genuinely-negative ICs, not post-clamp zeros., n_negative in ICIR warning reflects genuinely-negative ICIR, not zeros., Tests for ICFallbackStrategy on IC/ICIR-weighted fallback (issue #277)., Per-group IC series where every group has negative mean IC., TestICFallbackStrategy

### Community 446 - "Cluster 446"
Cohesion: 0.14
Nodes (13): _build_fx_rates(), _build_synthetic_prices(), Tests for research/_preprocessing.py — FX + sklearn return pipeline (issue #521), TestApplyFxToPrices, TestBuildReturnPreprocessingPipeline, TestEndToEnd, apply_fx_to_prices(), _assert_fx_shape_unchanged() (+5 more)

### Community 447 - "Cluster 447"
Cohesion: 0.05
Nodes (51): _build_estimator(), main(), Online learning example: rolling Sharpe via incremental ``partial_fit``.  Compar, Mean-risk with EW prior — partial-fit-capable., _default_grid_search(), _default_randomized_search(), OnlineGridSearchConfig, Lazy default factories avoid tuning->scoring->optimization->pipeline->tuning import cycle (+43 more)

### Community 448 - "Cluster 448"
Cohesion: 0.06
Nodes (20): BackgroundJobError, PostgreSQL-backed background job service.  Provides thread-safe job lifecycle ma, Individual error message for a background job., _apply_filters(), _partition_kwargs(), Repository for persistent background job operations., Return paginated job rows, most recent first., Count jobs matching the given filters. (+12 more)

### Community 449 - "Cluster 449"
Cohesion: 0.09
Nodes (20): VarianceEstimatorType, build_variance_estimator(), Build a skfolio variance estimator from *config*.      Parameters     ----------, Build a skfolio variance estimator from *config*.      Parameters     ----------, Variance estimators expose 1-D variance_ not 2-D covariance_; not interchangeable in priors needing full matrix, Tests for variance estimator dispatch and presets., Variance estimators expose 1-D ``variance_``, never 2-D ``covariance_``., REGIME_ADJUSTED_EW forwards the regime-specific kwargs. (+12 more)

### Community 450 - "Cluster 450"
Cohesion: 0.16
Nodes (12): _failing_rule(), _good_metrics(), _passing_rule(), _passing_rules(), Issue #546: write_checklist_json structure + content., Issue #546: write_checklist_json structure + content., Issue #546: write_checklist_json structure + content., Issue #546: terminal-gate exit-code contract. (+4 more)

### Community 451 - "Cluster 451"
Cohesion: 0.14
Nodes (11): app.main lifespan, per-process reconcile sentinel rationale, test_main_lifespan_reconcile, _cache_stats(), _fake_exchange(), _fake_instrument(), _now(), override_build_deps() (+3 more)

### Community 452 - "Cluster 452"
Cohesion: 0.12
Nodes (6): Tests for the RobustMeanRisk factory., Both uncertainty configs None must reproduce plain build_mean_risk., returns(), TestFallbackContract, TestForModerateUncertaintyLevel, TestPresets

### Community 453 - "Cluster 453"
Cohesion: 0.4
Nodes (17): _mock_client(), _norm_result(), _patch_normalize(), _pos(), Scenario-level unit tests for `compute_drift` (issue #782).  Covers reconciliati, test_when_base_toggled_then_deployable_matches_cash_field(), test_when_base_toggled_then_trade_delta_eur_scales(), test_when_cycle1_flag_on_position_then_surfaces_on_drift_row() (+9 more)

### Community 454 - "Cluster 454"
Cohesion: 0.06
Nodes (30): Covariance Matrix Estimation, Deep Markov Models, Detoning, Dimensionality Reduction, Empirical Mean, Equilibrium (CAPM) Returns, Estimator Selection Guidance, Estimator Selection Guidance (+22 more)

### Community 455 - "Cluster 455"
Cohesion: 0.12
Nodes (14): _pivot_input(), _pivot_rows_with_drop_ratio(), Tests for deterministic cross-listed ticker deduplication in data_assembly.py., Build a pivot input with `n_unique` unique tickers + `n_duplicates`     extra ro, TestPivotWithDedup, TestPivotWithDedupGuard, _pivot_with_dedup(), Pivot *df* after deterministically deduplicating (index, columns) pairs.      Wh (+6 more)

### Community 456 - "Cluster 456"
Cohesion: 0.1
Nodes (19): 10. Accessibility + interaction baseline (real-user reachability), 11. Green-gate the whole tree, 1. API endpoint contract coverage (routes layer), 2. API service logic coverage (services layer), 3. Background jobs, scheduler, and pipeline-builder session lifecycle, 4. Frontend service coverage (28 services), 5. Frontend component coverage — pages and features (129 components), 6. Frontend shared component coverage (`shared/`) (+11 more)

### Community 457 - "Cluster 457"
Cohesion: 0.05
Nodes (32): for_black_litterman(), build_factor_bl_views(), build_factor_exposure_constraints(), compute_net_alpha(), estimate_factor_premia(), Bridge factor scores to portfolio optimization inputs., Build enforceable linear factor exposure constraints.      For each factor ``g``, Estimate annualized factor premia from long-short returns.      Parameters     - (+24 more)

### Community 458 - "Cluster 458"
Cohesion: 0.28
Nodes (30): _(), a(), b(), c(), d(), E(), er(), f() (+22 more)

### Community 461 - "Cluster 461"
Cohesion: 0.1
Nodes (20): 10. Portfolio-builder page, 11. Settings page, 12. API contract validation (cross-cutting), 1. Global portfolio context propagation, 2. Ticker universe seeding (optimization-studio, backtesting, factor-research), 3. Dashboard page, 4. Risk-center page, 5. Attribution page (+12 more)

### Community 464 - "Cluster 464"
Cohesion: 0.24
Nodes (7): _make_order(), _make_t212_client(), Orders with no id field pass external_id=None (non-broker fallback)., Two orders: first inserts (returns event), second is duplicate (returns None)., When add_event_idempotent returns None (conflict), orders_inserted stays 0., _run_sync(), TestSyncPortfolioDeduplication

### Community 473 - "Cluster 473"
Cohesion: 0.14
Nodes (6): _make_fred_obs(), GET /fred/series?series_id=NONEXISTENT must return 400, not 200 []., Error detail must identify the rejected series_id., A valid catalog ID must pass validation and reach the repo., Omitting series_id must not trigger catalog validation., TestGetFredObservations

### Community 483 - "Cluster 483"
Cohesion: 0.3
Nodes (10): _clear_t212(), _drift_response(), _make_portfolio(), _make_snapshot(), _override_t212(), Route-level unit tests for GET /portfolio/{name}/drift (issue #784)., test_when_base_param_then_compute_drift_called_with_enum(), test_when_response_returned_then_t212_api_key_not_in_body() (+2 more)

### Community 485 - "Cluster 485"
Cohesion: 0.13
Nodes (7): Unit tests for the /database router.  Mocks ``DatabaseAdminRepository`` at the r, Issue #436: freezes the {healthy, latency_ms, database_url} shape         that t, The masked URL must never expose a password (issue #436 guard)., Issue #435 contract: every row must carry the four columns the         Settings, Regression: the legacy ``table_name`` key was renamed to ``name``         to mat, TestGetDatabaseHealth, TestGetDatabaseTables

### Community 486 - "Cluster 486"
Cohesion: 0.2
Nodes (10): _import_worker(), _make_db_mock(), _make_request(), Branch coverage for _run_factor_compute_bg in app.api.v1.factors.factors.  Tests, Omitting cancel_event triggers the ``if cancel_event is None`` branch., Passing a threading.Event covers the ``cancel_event is not None`` branch., Return a database_manager mock whose get_session context manager works., Invoke the worker with controlled patches; return (update_calls, exc). (+2 more)

### Community 490 - "Cluster 490"
Cohesion: 0.1
Nodes (20): title, type, title, type, properties, anyOf, default, title (+12 more)

### Community 491 - "Cluster 491"
Cohesion: 0.13
Nodes (15): description, title, type, default, description, title, type, job_id (+7 more)

### Community 493 - "Cluster 493"
Cohesion: 0.22
Nodes (9): PortfolioResponse, PortfolioListResponse, $defs, required, title, type, required, title (+1 more)

### Community 495 - "Cluster 495"
Cohesion: 0.07
Nodes (29): ann_return, ann_vol, downside_vol, info_ratio, max_drawdown, sharpe, sortino, breakdown (+21 more)

### Community 496 - "Cluster 496"
Cohesion: 0.05
Nodes (19): clean_df(), df_with_nan(), _make_correlated_df(), Tests for RegressionImputer transformer., For a single NaN cell, regression prediction should be plausible.          We co, Regression imputation should preserve covariance structure better         than s, When coefs_ is None, fallback SectorImputer is used., When all K neighbors are NaN at the same row, use fallback. (+11 more)

### Community 497 - "Cluster 497"
Cohesion: 0.5
Nodes (4): build_bl_config_from_calibration, classify_macro_regime service, get_macro_calibration endpoint, Macro Calibration Router

### Community 498 - "Cluster 498"
Cohesion: 0.5
Nodes (4): Stress Scenarios Router, stress_scenarios service, Synthetic Scenario Router, synthetic_service (generate/store/load)

### Community 499 - "Cluster 499"
Cohesion: 0.5
Nodes (4): EntropyPoolingRequest / Response schemas, GenerateViews BL view schemas (P, Q, Idzorek alphas), LLM moment calibration schemas (delta, factor weights, cov regime), OpinionPool request/response with ExpertPersona

### Community 500 - "Cluster 500"
Cohesion: 0.5
Nodes (4): build_optimizer config mapper, extract_backtest_metrics, run_and_persist backtest lifecycle, optimizer.pipeline.run_full_pipeline

### Community 501 - "Cluster 501"
Cohesion: 0.67
Nodes (4): rebalancing services __init__, build_config, build_trade_list, decide

### Community 502 - "Cluster 502"
Cohesion: 0.5
Nodes (4): Trading212Client._get_paginated, MAX_PAGES runaway cursor guard rationale, Trading212Client, Trading212ApiClient (Protocol)

### Community 503 - "Cluster 503"
Cohesion: 0.67
Nodes (4): flat-file-to-domain-folder refactor (issues #611-613), test_routes_flat_to_domain, test_services_domain_imports, test_services_flat_to_domain

### Community 504 - "Cluster 504"
Cohesion: 0.5
Nodes (4): StreamingClientProtocol, AsyncStreamingClient, StreamingClient, test_yfinance_cycle4_streaming_lock

### Community 505 - "Cluster 505"
Cohesion: 0.67
Nodes (4): _apply_delisting_returns, assemble_prices, Survivorship-bias correction via synthetic delisting returns, test_data_assembly_delisting

### Community 506 - "Cluster 506"
Cohesion: 0.83
Nodes (4): FactorDataError, factors API routes, test_factor_utility_routes, test_factor_validation

### Community 507 - "Cluster 507"
Cohesion: 0.67
Nodes (4): Structure parse failure trips circuit breaker; fetch failure does not, ParseStructureError, test_tradingeconomics_scraper, TradingEconomicsIndicatorsScraper

### Community 508 - "Cluster 508"
Cohesion: 0.67
Nodes (4): Factor Information Coefficient Chart (IS vs OOS Mean IC), Factor universe: amihud_illiquidity, accruals, momentum_12_1, gross_profitability, roe, beta, dividend_yield, cash_flow_yield, volatility, earnings_yield, book_to_price, Mean Information Coefficient (IS and OOS predictive power), In-sample vs out-of-sample factor validation comparison

### Community 509 - "Cluster 509"
Cohesion: 0.67
Nodes (4): Sector Allocation Over Time (stacked area chart), Portfolio sector weights time series (May 2024 - Nov 2025, stable allocations summing to 100%), Research backtest report output artifact, Eight equity sectors: Industrials, Technology, Financial Services, Healthcare, Communication Services, Energy, Basic Materials, Consumer Cyclical

### Community 510 - "Cluster 510"
Cohesion: 0.83
Nodes (4): April 2025 sharp drawdown affecting both portfolio and benchmark; portfolio trough deeper (~0.90), Benchmark equity curve (dashed orange): peaks ~1.40 by late 2025, ends ~1.39, outperformed by portfolio at end, Cumulative Returns: Portfolio vs Benchmark line chart (Growth of $1, Apr 2024 to Jan 2026), Portfolio equity curve (solid blue): drawdown to ~0.90 in Apr 2025 then strong recovery to ~1.59 by Feb 2026

### Community 511 - "Cluster 511"
Cohesion: 0.67
Nodes (4): Country Allocation Over Time (stacked area chart), Geographic diversification across US, Europe, emerging markets (Brazil, South Africa, Taiwan, Indonesia, Turkey, Colombia), Portfolio weight distribution across 14 countries (stable over 2024-05 to 2025-11), United States largest country allocation (~20% of portfolio weight)

### Community 512 - "Cluster 512"
Cohesion: 0.67
Nodes (4): Backtest Period 2024-03 to 2026-02, Max Drawdown ~-15.7% in April 2025, Drawdown Recovery to Near-Zero by Late 2025, Underwater Chart: Portfolio Drawdown Time Series

### Community 516 - "Cluster 516"
Cohesion: 0.1
Nodes (10): CountryNewsSummary, SentimentLabel, _is_morning_pipeline_complete(), Return True if at least one MacroNewsSummary row exists for today., Return True if at least one MacroNewsSummary row exists for today., Return True if at least one MacroNewsSummary row exists for today., Unit tests for macro news summary service., TestMorningPipelineGuard (+2 more)

### Community 517 - "Cluster 517"
Cohesion: 0.16
Nodes (12): classify_regime_composite(), Classify macro regime using the multi-indicator composite score.      Uses ISM P, _composite(), Single-row macro frame for composite-score branch tests., Cover the sentiment-augmented and 3-indicator composite-score arms., When spread_2s10s is absent, its component score stays neutral., A strongly negative augmented score classifies as RECESSION., A positive (but < 3) augmented score classifies as EXPANSION. (+4 more)

### Community 527 - "Cluster 527"
Cohesion: 0.67
Nodes (3): FactorOOSConfig, FactorOOSResult, run_factor_oos_validation

### Community 528 - "Cluster 528"
Cohesion: 0.67
Nodes (3): MacroNews model, MacroNewsSummary model, MacroNewsTheme model

### Community 529 - "Cluster 529"
Cohesion: 0.16
Nodes (8): data_summary(), Return a human-readable plain-text summary of assembled data., Return a mapping of strategy value → human-readable description., strategies(), _make_assembly(), Tests for research/strategies/_inspect.py — issue #669.  Covers data_summary(Dat, TestDataSummary, TestStrategies

### Community 530 - "Cluster 530"
Cohesion: 0.67
Nodes (3): BondYieldResponse, CountryMacroSummary, EconomicIndicatorResponse

### Community 531 - "Cluster 531"
Cohesion: 0.67
Nodes (3): Preview empty-state semantics (issue #425), RebalancePreviewResponse, TradeItem

### Community 532 - "Cluster 532"
Cohesion: 1.0
Nodes (3): ApiKey, ApiKeyAuthMiddleware, test_auth_middleware

### Community 533 - "Cluster 533"
Cohesion: 1.0
Nodes (3): test_yfinance_analysis_eps, AnalysisClientProtocol, AnalysisClient

### Community 534 - "Cluster 534"
Cohesion: 0.67
Nodes (3): FactorScore, FactorValidationReport, test_factor_models

### Community 535 - "Cluster 535"
Cohesion: 0.67
Nodes (3): Worker liveness columns + composite index for orphan reaping, BackgroundJob model, test_background_job_liveness_columns

### Community 536 - "Cluster 536"
Cohesion: 1.0
Nodes (3): test_yfinance_metadata_valuation, MetadataClient, MetadataClientProtocol

### Community 537 - "Cluster 537"
Cohesion: 1.0
Nodes (3): test_yfinance_cycle5_sector_growth, SectorIndustryClient, SectorIndustryClientProtocol

### Community 538 - "Cluster 538"
Cohesion: 0.67
Nodes (3): RebalancingPolicy model, RiskLimit model, test_risk_rebalancing_models

### Community 539 - "Cluster 539"
Cohesion: 0.67
Nodes (3): _read_last_review_date, _write_last_review_date, last_review_date.txt (2026-05-13)

### Community 540 - "Cluster 540"
Cohesion: 0.67
Nodes (3): compute_after_tax_returns, _tax_drag realised PnL tax, _txn_cost turnover cost

### Community 573 - "Cluster 573"
Cohesion: 0.07
Nodes (28): Architecture, Code Examples, code:block1 (prices → returns → [preprocess → pre-select → optimize] → ba), code:python (from optimizer.factors import SelectionConfig, CompositeScor), code:python (from optimizer.pipeline import tune_and_optimize, build_port), code:block2 (┌───────────────────────────────────────────────────────────), code:python (from optimizer.pipeline import build_portfolio_pipeline), code:python (from optimizer.optimization import MeanRiskConfig, build_mea) (+20 more)

### Community 574 - "Cluster 574"
Cohesion: 0.07
Nodes (27): Basic universe screening, Code Examples, code:block1 (Entry threshold:  $200M ─────────────────), code:python (from optimizer.universe import HysteresisConfig), code:python (from optimizer.universe import InvestabilityScreenConfig), code:python (# Strict institutional universe), code:python (from optimizer.universe import screen_universe, Investabilit), code:python (from optimizer.universe import screen_universe, Investabilit) (+19 more)

### Community 575 - "Cluster 575"
Cohesion: 0.02
Nodes (67): anyOf, default, title, country, activeFilters, AssetScreenerPanelComponent, pts, REPORTS (+59 more)

### Community 576 - "Cluster 576"
Cohesion: 0.07
Nodes (10): ConfigPanelComponent, OptimizerPanelComponent, Named optimizer strategies., Strategy, Tests for research/strategies/_runner.py — issue #668.  Covers Strategy enum, _b, _runner.py must not import cross-layer research modules at module level., test_when_value_looked_up_then_correct_member_name_returned(), TestBuildOptimizer (+2 more)

### Community 577 - "Cluster 577"
Cohesion: 0.1
Nodes (20): format, title, type, description, required, title, type, AssetClassReturnsResponse (+12 more)

### Community 578 - "Cluster 578"
Cohesion: 0.07
Nodes (8): job_steps(), Structural tests for the GitHub Actions smoke workflow.  Covers three artifacts:, TestFixtureSqlContent, TestFixtureSqlExists, TestSmokeScriptContent, TestSmokeScriptExists, TestSmokeWorkflowFileExists, TestSmokeWorkflowTriggers

### Community 579 - "Cluster 579"
Cohesion: 0.08
Nodes (20): next(), _good_inputs(), Build a passing scenario for every rule (boundary-relaxed)., Build a passing scenario for every rule (boundary-relaxed)., Build a passing scenario for every rule (boundary-relaxed)., Issue #545: _validate_checklist must return list[dict] of length 17., Issue #545: _validate_checklist must return list[dict] of length 17., Issue #545: _validate_checklist must return list[dict] of length 17. (+12 more)

### Community 580 - "Cluster 580"
Cohesion: 0.18
Nodes (9): create_scheduler(), Create a fully configured APScheduler instance (not yet started).      Must be c, Create a fully configured APScheduler instance (not yet started).      Must be c, Create a fully configured APScheduler instance (not yet started).      Must be c, Create a fully configured APScheduler instance (not yet started).      Must be c, _build_scheduler(), Scheduler registration tests (issue #824).  Asserts ``create_scheduler()`` regis, Create a scheduler with a mocked engine + in-memory jobstore. (+1 more)

### Community 581 - "Cluster 581"
Cohesion: 0.12
Nodes (20): _MockDbManager, _patch_sub_assemblers(), _prices_df(), Integration tests for research/data/_orchestrator.py — assemble_all., when prices have 2 tickers, result.n_tickers == 2., when include_delisted=False, volumes assembler receives False., when macro_country='GBR', assemble_macro_data receives 'GBR'., when loaders provide data, DataAssembly fields have expected types. (+12 more)

### Community 582 - "Cluster 582"
Cohesion: 0.14
Nodes (9): for_gbt_weighted(), for_ridge_weighted(), compute_ml_composite(), ML composite score using ridge regression or gradient-boosted trees.      Trains, ML composite score using ridge regression or gradient-boosted trees.      Trains, RIDGE_WEIGHTED and GBT_WEIGHTED are valid CompositeMethod values., Training and prediction tickers are disjoint — no data leakage., TestComputeCompositeScoreDispatch (+1 more)

### Community 585 - "Cluster 585"
Cohesion: 0.28
Nodes (5): _make_view(), adjust_view_confidences must not mutate the input list., TestAdjustViewConfidences, adjust_view_confidences(), Return a new list of views with Idzorek confidence adjusted by sentiment.      F

### Community 591 - "Cluster 591"
Cohesion: 0.33
Nodes (9): _clear_t212(), _drift_response(), _make_portfolio(), _make_snapshot(), _override_t212(), Error-path + contract tests for GET /portfolio/{name}/drift (issue #812).  Porte, test_when_base_param_then_compute_drift_called_with_enum(), TestDriftErrors (+1 more)

### Community 596 - "Cluster 596"
Cohesion: 0.33
Nodes (4): check_regime_disagreement(), Check whether two regime classifications disagree.      When two regime systems, Tests for regime disagreement detection (issue #240)., TestCheckRegimeDisagreement

### Community 968 - "Community 968"
Cohesion: 0.08
Nodes (25): Built-In Ratio Measures, Calendar-Based Rebalancing, Combinatorial Purged Cross-Validation, Construction, Custom Scoring Functions, Factor Returns as Metadata, Grid Search, Hyperparameter Tuning (+17 more)

### Community 969 - "Community 969"
Cohesion: 0.08
Nodes (25): Business Cycle and Sector Rotation, Connection to Factor Tilts, Connection to Moment Estimation, Connection to Regime Classification, Connection to View Integration, Credit Spread Dynamics, Currency Hedging Decisions, Detection Lag and Practical Limitations (+17 more)

### Community 970 - "Community 970"
Cohesion: 0.08
Nodes (25): Code Examples, code:python (from optimizer.tuning import GridSearchConfig), code:python (from optimizer.tuning import RandomizedSearchConfig), code:block3 (validate__max_abs_return), code:python (from optimizer.pipeline import build_portfolio_pipeline), code:python (from optimizer.pipeline import build_portfolio_pipeline, tun), code:python (param_grid = {), code:python (from scipy.stats import uniform, loguniform) (+17 more)

### Community 971 - "Community 971"
Cohesion: 0.09
Nodes (14): build_preselection_pipeline(), Factory function for assembling the pre-selection sklearn Pipeline., Build an sklearn Pipeline for data cleaning and asset pre-selection.      The pi, Tests for build_preselection_pipeline factory and PreSelectionConfig., Pipeline should drop one of two perfectly correlated assets., Synthetic return DataFrame with 50 assets and 200 observations., Tests for outlier_method wiring in build_preselection_pipeline (issue #63)., Tests for pipeline step ordering invariants (issue #83). (+6 more)

### Community 972 - "Community 972"
Cohesion: 0.16
Nodes (9): _builder_from_sequence(), _config(), _FakeMeanRisk, Cycle-3 §7.3 Top-4 retighten loop contract tests (issue #553).  Exhausts the con, Stand-in for ``skfolio.MeanRisk`` driven by a fixed weight vector., Builder that pops a fresh weight vector per call; tracks max_weights., TestRetightenConvergence, TestRetightenDivergence (+1 more)

### Community 973 - "Community 973"
Cohesion: 0.08
Nodes (23): Agent & Skill Requirements, API Layer (`api/app/`), Architecture, Build & Run Commands, CI Pipeline, code:bash (# Infrastructure), code:block2 (pip install -e ".[dev]"    →    ruff check optimizer/ tests/), code:block3 (prices → preprocessing → pre_selection → moments → views →) (+15 more)

### Community 974 - "Community 974"
Cohesion: 0.05
Nodes (26): CircuitBreaker, _make_scraper_with_patches(), _mock_response(), Unit tests for IlSoleScraper (issue #822).  Covers: row parsing, empty/unknown c, IlSoleScraper must not advertise brotli encoding., TradingEconomicsIndicatorsScraper must use gzip/deflate only.          Regressio, circuit_breaker.trigger() must be called when a transient error fires., After max_attempts triggers, check() must raise RuntimeError immediately. (+18 more)

### Community 975 - "Community 975"
Cohesion: 0.14
Nodes (14): description, properties, required, title, type, ConcentrationAsset, ticker, weight (+6 more)

### Community 976 - "Community 976"
Cohesion: 0.08
Nodes (25): 10. Portfolio-builder page, 11. Settings page, 12. API contract validation (cross-cutting), 1. Global portfolio context propagation, 2. Ticker universe seeding (optimization-studio, backtesting, factor-research), 3. Dashboard page, 4. Risk-center page, 5. Attribution page (+17 more)

### Community 977 - "Community 977"
Cohesion: 0.1
Nodes (20): anyOf, default, description, title, type, properties, description, title (+12 more)

### Community 978 - "Community 978"
Cohesion: 0.08
Nodes (11): normal_returns(), Tests for OutlierTreater transformer., A value at exactly |z| == winsorize_threshold should be clipped (Group 2)., Values in the normal range (|z| < winsorize_threshold) stay unchanged., Fitted statistics must not change when transforming unseen data., DataFrame with known mean/std for predictable z-scores., Values with |z| > 10 should become NaN., Values with 3 <= |z| <= 10 should be clipped. (+3 more)

### Community 979 - "Community 979"
Cohesion: 0.1
Nodes (11): _collect_imports(), Cycle-3 §672 — verify and harden _rebalance.py boundary (issue #672).  Covers ga, _retighten must not back-import from _rebalance., Every symbol declared in __all__ must resolve at runtime., Return every top-level module referenced in ``import`` / ``from … import``., Threshold constants are hard-coded tunable knobs; values must be exact., Only permitted modules may be imported by _rebalance.py., TestImportBoundary (+3 more)

### Community 980 - "Community 980"
Cohesion: 0.08
Nodes (23): Active View Specification, Bayesian Posterior Returns, Black-Litterman Factor Model, Conflicting View Resolution, Consensus Distribution with Credibility Weights, Entropy Pooling: Non-Linear View Integration, Expert Weight Calibration, Limitations of Classical Black-Litterman (+15 more)

### Community 981 - "Community 981"
Cohesion: 0.11
Nodes (9): Tests for composite scoring., Standardized factor scores for 20 tickers., Tests for coverage-weighted mean in group scoring (issue #62)., Ticker missing 1 of 2 factors has group score equal to the present factor., With full coverage, coverage-weighted mean equals simple mean., standardized_factors(), TestCoverageWeightedMean, TestICDecayHalflife (+1 more)

### Community 982 - "Community 982"
Cohesion: 0.08
Nodes (14): Tests for research/data/_helpers.py., Tests for module-level constants in _helpers., _TRADING_DAYS equals 252 (equity convention)., Tests for the REGION_MAP constant., REGION_MAP can be imported from research.data._helpers., REGION_MAP has exactly 40 country entries., REGION_MAP maps to exactly 4 canonical region strings., Known Americas countries resolve to 'Americas'. (+6 more)

### Community 983 - "Community 983"
Cohesion: 0.02
Nodes (72): cumSum(), cumSum(), compute_factor_pca(), Compute PCA on a cross-sectional factor score matrix.      Rows with any NaN are, orthogonalize_factors(), Project factor scores onto orthogonal principal components.      Eliminates mult, A single latent factor → 1 PC explains most variance., TestComputeFactorPCA (+64 more)

### Community 984 - "Community 984"
Cohesion: 0.14
Nodes (7): Query FRED observations with optional filters.          When *limit* is supplied, Delete macro news older than the given date. Returns count deleted., Return a deduplicated sorted list of all countries with stored data., Tests for MacroRegimeRepository.upsert_regime_classification (issue #530)., Persist rule-based MacroRegime classifier output to macro_calibrations., _row(), TestUpsertRegimeClassification

### Community 985 - "Community 985"
Cohesion: 0.08
Nodes (23): Basic scenario generation, Building and Using Synthetic Data, Building just the vine copula, Code Examples, code:python (from optimizer.synthetic import VineCopulaConfig), code:python (from optimizer.synthetic import SyntheticDataConfig), code:python (from optimizer.synthetic import SyntheticDataConfig, build_s), code:python (config = SyntheticDataConfig.for_stress_test(n_samples=10_00) (+15 more)

### Community 986 - "Community 986"
Cohesion: 0.06
Nodes (19): build_factor_mimicking_portfolios(), compute_cross_factor_correlation(), _compute_leg_beta(), _long_short_return_at(), QuintileSpreadResult, Long-short factor-mimicking portfolio construction and quintile analysis., Compute OLS beta of leg returns against market returns.      Parameters     ----, Build long-short factor-mimicking portfolio return time series.      For each da (+11 more)

### Community 987 - "Community 987"
Cohesion: 0.13
Nodes (10): MetadataClient, Wraps ``yf.Ticker`` metadata-related attributes., _build_client(), Unit tests for ``MetadataClient.fetch_valuation_measures``.  Covers the yfinance, Construct a ``MetadataClient`` whose cached ticker exposes *valuation*., Return a 9-metric valuation panel including the asserted superset., test_when_metadata_client_constructed_then_protocol_is_satisfied(), test_when_valuation_panel_empty_then_none_is_returned() (+2 more)

### Community 988 - "Community 988"
Cohesion: 0.14
Nodes (14): description, title, type, description, title, type, lookback, nObservations (+6 more)

### Community 989 - "Community 989"
Cohesion: 0.04
Nodes (45): 1. `blend_moments_by_regime()` vs. `HMMBlendedCovariance`, 2. Filtered vs. Smoothed Probabilities for Backtests, 3. Log-Return vs. Simple-Return Inputs for Scaling, 4. DMM Produces Diagonal Covariance, 5. The Fitted Prior Attribute, 6. Factor Model Views, `apply_lognormal_correction`, Architecture (+37 more)

### Community 990 - "Community 990"
Cohesion: 0.08
Nodes (9): Tests for SectorImputer transformer., Fitted sector_groups_ must not change when transforming unseen data., Imputed value should be the other asset's value, not the average         includi, When an entire sector is NaN for a row, use global mean., DataFrame with known NaN positions for sector imputation tests., AAPL is NaN at row 1; MSFT=0.04, GOOG=0.02 → sector avg = 0.03., JPM is NaN at row 0; GS=0.02 → sector avg = 0.02., sector_df() (+1 more)

### Community 991 - "Community 991"
Cohesion: 0.16
Nodes (11): _make_assembly(), _patch_load_data(), Integration smoke tests for load_data() Cycle 1 wiring (issue #522)., Verify Cycle 1 §3 hand-off: prices_to_returns + preprocessing pipeline., Build a synthetic DataAssembly large enough to pass §0/§1/§2 gates., _StubMgr, TestAssertAssemblySize, TestLoadDataIntegration (+3 more)

### Community 992 - "Community 992"
Cohesion: 0.13
Nodes (14): 1. Frontend render-coverage: the two mega-components (`backtesting`, `macro-intelligence`), 2. Frontend render-coverage: remaining page components, 3. Frontend: shared components, 0%/partial services, and the HTTP interceptor, 4. `api/` (FastAPI) coverage to ≥80% on all four metrics, 5. `optimizer/` library coverage to ≥80% on all four metrics, 6. Raise every gate to 80/80/80/80 and hard-fail CI below, Constraints, Coverage Hardening — All Stacks to ≥80% on Every Metric (Statements / Branches / Functions / Lines) (+6 more)

### Community 993 - "Community 993"
Cohesion: 0.07
Nodes (16): test_init_file_line_count_le_30(), test_when_steps_module_loaded_then_repo_root_added_to_sys_path(), Importing research.reporting._display must not write to stdout., Importing research.reporting._display must not write to stderr., The module-level ``console`` name must NOT exist on _display after lazy-init fix, After the fix, ``_get_console`` must be callable on _display., _get_console() must return a rich.console.Console instance., Calling _get_console() twice must return the same singleton instance. (+8 more)

### Community 994 - "Community 994"
Cohesion: 0.14
Nodes (8): Regression tests for _upsert() updated_at stamping (issue #311).  Verifies that, created_at is excluded from the update_dict and must remain frozen., On a clean INSERT (no conflict), both created_at and updated_at are set., Callers that omit 'updated_at' from update_columns (e.g. upsert_te_observations), _upsert() must advance updated_at on conflict and preserve created_at., upsert_macro_news_summary uses an explicit update_columns list.         On confl, upsert_economic_indicator uses update_columns=None (fallback dict-scan)., TestUpsertUpdatedAtStamping

### Community 995 - "Community 995"
Cohesion: 0.08
Nodes (24): title, type, format, title, type, anyOf, title, title (+16 more)

### Community 996 - "Community 996"
Cohesion: 0.18
Nodes (8): default_freshness_config(), FreshnessConfig — time-based stale-price threshold (issue #794).  Frozen domain, Build a `FreshnessConfig` from the current `Settings` snapshot., Tests for FreshnessConfig + default_freshness_config (issue #794)., Factory must be the only construction site at module scope., _reload_with_env(), TestDefaultFreshnessConfig, TestImportTimeNoInstantiation

### Community 997 - "Community 997"
Cohesion: 0.08
Nodes (28): description, properties, required, title, type, description, properties, required (+20 more)

### Community 998 - "Community 998"
Cohesion: 0.16
Nodes (7): _make_synthetic_assembly(), Tests for REGION_MAP, FRED_SERIES_IDS additions, and assembly_hash (issue #518)., TestAssemblyHashField, TestComputeAssemblyHash, TestFredSeriesIds, _compute_assembly_hash(), Return a deterministic 16-char SHA-256 prefix identifying the assembly.      Par

### Community 999 - "Community 999"
Cohesion: 0.09
Nodes (20): _make_mock_portfolio(), _make_mock_portfolio_with_nans(), _make_mock_result(), _make_mock_result_with_nans(), Unit tests for app/services/backtest_service.py.  Covers:   - validate_prices ra, run_and_persist must coerce plain-Index prices before calling the pipeline., run_and_persist must coerce plain-Index prices before calling the pipeline., run_and_persist normalises the index before handing off to the pipeline. (+12 more)

### Community 1000 - "Community 1000"
Cohesion: 0.14
Nodes (14): align_to_pit(), Filter time-series data to records published before ``as_of_date``.      A recor, _make_annual_data(), Build a minimal time-series fundamentals DataFrame., Acceptance criteria: correct lag applied per source type., Annual Dec 31 data is NOT available before March 31 (90 days)., Annual Dec 31 data IS available on March 31 (exactly 90 days)., Analyst revision on Monday is NOT available before Friday (5 days). (+6 more)

### Community 1001 - "Community 1001"
Cohesion: 0.27
Nodes (9): _make_portfolio(), _make_prices(), _make_snapshot(), Coverage gap-fill for dashboard.py service-layer ValueError → 422 branches.  Iss, TestAllocationServiceError, TestAssetClassReturnsServiceError, TestEquityCurveServiceError, TestPerformanceMetricsServiceError (+1 more)

### Community 1002 - "Community 1002"
Cohesion: 0.16
Nodes (16): app.api.v1.dashboard.dashboard, dashboard / portfolio-analytics routes, DashboardRepository, _actual_weights_from_positions, _actual_weights_from_prices, compute_allocation, compute_asset_class_returns, compute_drift (+8 more)

### Community 1003 - "Community 1003"
Cohesion: 0.16
Nodes (6): alertEl, body, fx, poll, req, WalkForwardPanelComponent

### Community 1004 - "Community 1004"
Cohesion: 0.27
Nodes (6): _find_countries_with_new_articles(), Return country names that have at least one new article since *since*., Return country names that have at least one new article since *since*., Return country names that have at least one new article since *since*., _make_simple_article(), TestFindCountriesWithNewArticles

### Community 1005 - "Community 1005"
Cohesion: 0.02
Nodes (97): FreshnessIndicatorComponent, map, cases, JobProgressTrackerComponent, completedJob, failedJob, fixture, text (+89 more)

### Community 1006 - "Community 1006"
Cohesion: 0.18
Nodes (13): items, items, type, description, items, title, type, p (+5 more)

### Community 1007 - "Community 1007"
Cohesion: 0.23
Nodes (4): _mapper_with_info(), Unit tests for YFinanceTickerMapper (suffix rules, cache, verification).  Split, TestYFinanceTickerMapperFetchBasicData, TestYFinanceTickerMapperVerifyTicker

### Community 1008 - "Community 1008"
Cohesion: 0.13
Nodes (14): ApiKeyConfig, ApiKeyStatus, ChartColorScheme, ColorSchemeOption, DataSource, DataSourceStatus, ExportSettings, LogEntry (+6 more)

### Community 1009 - "Community 1009"
Cohesion: 0.14
Nodes (14): prompt_hashes, prompt-cycle-specializer.md, prompt-optimize-requirements.md, prompt-phase-0-complexity.md, prompt-phase-1-planning.md, prompt-phase-2-batch-review.md, prompt-phase-3-implementation.md, prompt-phase-5-final-review.md (+6 more)

### Community 1010 - "Community 1010"
Cohesion: 0.15
Nodes (10): errorSpy, failingCall, getLatestSnapshotSpy, PortfolioSnapshot, resolvedTickers, result, seedVariants, snap (+2 more)

### Community 1011 - "Community 1011"
Cohesion: 0.09
Nodes (10): _build_environment(), _build_factor_ic_rows(), Jinja-based ``report.md`` renderer for the research pipeline (Cycle 5 §12).  Con, Merge IS results with OOS column means into one row dict per factor., Render the research-run report.md to ``output_dir / 'report.md'``., render_report(), checklist_rows(), Tests for ``research/_report.py`` — issue #549 (Jinja report renderer). (+2 more)

### Community 1012 - "Community 1012"
Cohesion: 0.16
Nodes (8): MacroNewsSummary, Daily country-level news summary aggregated from MacroNews articles.      One ro, _make_summary_row(), Unit tests for macro news summary API endpoints (issue #214)., Build a MacroNewsSummary ORM instance for testing., TestGetAllNewsSummaries, TestGetCountryNewsSummary, TestGetNewsSummarizeStatus

### Community 1013 - "Community 1013"
Cohesion: 0.17
Nodes (12): assemble_sentiment(), Build a dates x country DataFrame of news sentiment scores.      Queries ``macro, _mock_session(), Tests for research/data/_sentiment.py., when no rows, empty dataframe returned., when all sentiment_score values are None, empty dataframe returned., when rows present, result indexed by date with country columns., when single row, correct sentiment score stored in result. (+4 more)

### Community 1014 - "Community 1014"
Cohesion: 0.33
Nodes (12): _build_repo(), _build_yf_client(), _eps_dated_fixture(), Service-level tests for cycle 2 wiring: valuation / eps_trend / eps_revisions., Extract ``(statement_type, period_type, currency_code)`` for every upsert., Mixed-label fixture: real timestamp survives ``pd.to_datetime`` coercion., _run(), _statement_type_calls() (+4 more)

### Community 1015 - "Community 1015"
Cohesion: 0.1
Nodes (20): 6. Validation, code:python (from optimizer.factors import FactorValidationConfig), code:python (from optimizer.factors import compute_monthly_ic, compute_ic), code:python (from optimizer.factors import compute_newey_west_tstat), code:block30 (Var_NW = gamma_0 + 2 * sum_{j=1}^{L} (1 - j/(L+1)) * gamma_j), code:python (from optimizer.factors import correct_pvalues, benjamini_hoc), code:python (from optimizer.factors import compute_vif), code:python (from optimizer.factors import compute_quantile_spread) (+12 more)

### Community 1016 - "Community 1016"
Cohesion: 0.1
Nodes (7): Issue #683: research.pipeline must not re-export cross-boundary symbols.  RED te, Symbols owned by research.data / research.optimization must not appear     in re, Explicit import of each removed symbol from research.pipeline must fail., Canonical modules still export these symbols after removal from pipeline., TestCanonicalPathsStillWork, TestCrossBoundarySymbolsAbsentFromPipelineAll, TestCrossBoundarySymbolsNotImportableFromPipeline

### Community 1017 - "Community 1017"
Cohesion: 0.12
Nodes (11): _compute_beta(), Market beta (natural units).      Lower beta is favorable for LOW_RISK factor sc, Regression for issue #294: beta uses mixed-currency market proxy.      When ``pr, compute_factor passes market_returns through to _compute_beta., A non-equal-weight proxy produces different betas., Passing the equal-weight mean explicitly matches the default., Adding uncorrelated 'GBX noise' stocks shifts beta estimates.          Construct, Raw beta from _compute_beta must not be negated by compute_factor. (+3 more)

### Community 1018 - "Community 1018"
Cohesion: 0.19
Nodes (3): _capture_optimizer(), §7.1 spec wiring of optimize_portfolio., TestHardConstrainedMeanRiskSpec

### Community 1019 - "Community 1019"
Cohesion: 0.14
Nodes (9): Tests for app.services._shared._ticker_lookup.lookup_yf_ticker (issue #773)., The lookup must query Instrument.yfinance_ticker WHERE Instrument.ticker = t212_, The local _map_t212_ticker_to_yfinance must be fully removed., TestBrokerSyncUsesSharedLookup, TestLookupYfTicker, lookup_yf_ticker(), Shared T212 → yfinance ticker DB lookup (issue #773).  Extracted from broker_syn, Look up the yfinance_ticker for a T212 ticker via the instruments table.      Th (+1 more)

### Community 1020 - "Community 1020"
Cohesion: 0.32
Nodes (9): _make_policy(), _make_portfolio(), _make_position(), _make_snapshot(), Branch coverage for GET /api/v1/rebalance/preview with broker positions.  Exerci, The ``if price:`` loop and ``if positions: build_trade_list`` branches., current_price=None → average_price used as fallback (``price`` is truthy)., yfinance_ticker=None → pos.ticker used as price key. (+1 more)

### Community 1021 - "Community 1021"
Cohesion: 0.11
Nodes (18): Architecture Pattern, Code Quality, code:bash (# Clone the repository), code:bash (# Run all tests), code:bash (# Lint), code:bash (make lint        # ruff check + format check), code:python (from dataclasses import dataclass), Coding Standards (+10 more)

### Community 1022 - "Community 1022"
Cohesion: 0.11
Nodes (5): Tests for research/data/__init__.py public API contract.  Issue #663: The packag, Private symbols removed from data/__init__ must not be re-exported., Importing research.data must not raise ImportError or circular-import., test_import_research_data_no_circular_import(), test_private_helpers_not_in_data_namespace()

### Community 1023 - "Community 1023"
Cohesion: 0.14
Nodes (14): prompt_hashes, prompt-cycle-specializer.md, prompt-optimize-requirements.md, prompt-phase-0-complexity.md, prompt-phase-1-planning.md, prompt-phase-2-batch-review.md, prompt-phase-3-implementation.md, prompt-phase-5-final-review.md (+6 more)

### Community 1024 - "Community 1024"
Cohesion: 0.1
Nodes (19): Gate tests for research/reporting/__init__.py public API contract.  Issue #678:, Importing research.reporting in a subprocess must exit 0., __all__ must contain no more than 25 entries., Every name imported by research/__init__.py from research.reporting     must be, Every name in __all__ must be importable, and every contract name must     appea, __all__ must not contain any underscore-prefixed names., Every name listed in __all__ must be importable from research.reporting., __all__ must not contain duplicate entries. (+11 more)

### Community 1025 - "Community 1025"
Cohesion: 0.04
Nodes (37): build_equal_weighted(), build_inverse_volatility(), build_random(), EqualWeightedConfig, InverseVolatilityConfig, RandomConfig, Naive benchmark optimizer configurations and factories.  EqualWeighted, InverseV, Build a skfolio :class:`EqualWeighted` from *config*. (+29 more)

### Community 1026 - "Community 1026"
Cohesion: 0.13
Nodes (25): a, ACCEPTED, acceptResponse(), ARTIFACTS, b, cfg, clicks, d (+17 more)

### Community 1027 - "Community 1027"
Cohesion: 0.19
Nodes (7): FX price conversion transformer., Validate FX rate coverage and align rates to the price index.          Parameter, _validate_input(), align_fx_rates(), Align FX rate DataFrame to a price calendar.      Reindexes FX rates to the ``pr, Tests for align_fx_rates()., TestAlignFxRates

### Community 1028 - "Community 1028"
Cohesion: 0.1
Nodes (13): _cvar_95(), _max_drawdown(), _portfolio_returns(), Compute weighted portfolio return series from price DataFrame., daily_returns(), prices_df(), Unit tests for dashboard_service — pure computation, no DB., 252 days of synthetic daily returns (mean ~0.05%, std ~1%). (+5 more)

### Community 1029 - "Community 1029"
Cohesion: 0.1
Nodes (20): anyOf, default, description, title, anyOf, default, description, title (+12 more)

### Community 1030 - "Community 1030"
Cohesion: 0.21
Nodes (10): _build_job_status(), _get_repo(), get_scheduler_status(), Unified APScheduler service replacing supercronic + MacroNewsSummaryScheduler., Status of a single APScheduler job enriched with last-run data., Top-level response for GET /scheduler/status., Map a single APScheduler Job + DB row into a SchedulerJobStatus., Return the running state and per-job statuses of the APScheduler instance. (+2 more)

### Community 1031 - "Community 1031"
Cohesion: 0.13
Nodes (7): Immutable configuration for :class:`skfolio.distribution.VineCopula`.      Vine, VineCopulaConfig, build_vine_copula(), Build a skfolio :class:`VineCopula` from *config*.      Parameters     ---------, Build a skfolio :class:`VineCopula` from *config*.      Parameters     ---------, TestVineCopulaConfig, TestBuildVineCopula

### Community 1032 - "Community 1032"
Cohesion: 0.2
Nodes (11): _build_endpoint_histogram(), _classify_http_exception(), observe_endpoint_latency(), Prometheus metric definitions for background job and request instrumentation.  A, Record a single request-handler latency observation.      Raises ``KeyError`` fo, Map an HTTPException's status code to its endpoint-histogram label., Time a request-handler body and record the observation on exit.      The status, Construct a request-handler latency histogram for one endpoint. (+3 more)

### Community 1033 - "Community 1033"
Cohesion: 0.11
Nodes (17): 3. Composite Scoring, code:python (from optimizer.factors import CompositeScoringConfig), code:python (from optimizer.factors import compute_group_scores), code:python (from optimizer.factors import compute_composite_score, Compo), code:block15 (ICIR = max(mean(IC) / std(IC), 0)), code:python (from optimizer.factors import fit_ridge_composite, fit_gbt_c), CompositeMethod, CompositeScoringConfig (+9 more)

### Community 1034 - "Community 1034"
Cohesion: 0.12
Nodes (16): title, type, EquityCurveResponse, description, properties, required, title, type (+8 more)

### Community 1035 - "Community 1035"
Cohesion: 0.31
Nodes (6): _make_portfolio(), _make_position(), _make_prices(), _make_snapshot(), Route-level tests for the dashboard drift endpoint (issue #812).  Migrated from, TestGetDrift

### Community 1036 - "Community 1036"
Cohesion: 0.11
Nodes (17): after_tax, ann_return, ann_vol, downside_vol, info_ratio, max_drawdown, sharpe, sortino (+9 more)

### Community 1037 - "Community 1037"
Cohesion: 0.11
Nodes (11): build_max_diversification(), MaxDiversificationConfig, MaximumDiversification configuration and factory.  Maximises the diversification, Immutable configuration for :class:`MaximumDiversification`.      Default is lon, Build a skfolio :class:`MaximumDiversification` from *config*.      Parameters, Tests for MaximumDiversification factory and configuration., returns(), TestBuildMaxDiversification (+3 more)

### Community 1038 - "Community 1038"
Cohesion: 0.11
Nodes (12): Gate tests for research/factors/__init__.py public API contract.  Issue #676: Au, research/factors/__init__.py must not import from research.data., Importing research.factors must not raise ImportError or circular-import., _slice_fundamentals_at is intentionally re-exported for test consumers., _slice_fundamentals_at is intentionally re-exported in __all__., __all__ must contain exactly the three named re-exports — no phantom entries., test_all_contains_slice_fundamentals_at(), test_all_has_no_duplicates() (+4 more)

### Community 1039 - "Community 1039"
Cohesion: 0.11
Nodes (21): brinson_attribution(), BrinsonRequest, BrinsonResponse, BrinsonSectorRow, _check_non_empty(), _check_weights_sum_to_one(), factor_attribution(), FactorAttributionRequest (+13 more)

### Community 1040 - "Community 1040"
Cohesion: 0.12
Nodes (16): Bond Yields (16 configurations), Common Across All Countries, Countries Tracked (4), Data Sources & Refresh Cadence, Exchanges (5), France-Specific (4 extra), FRED Series (14), Germany-Specific (6 extra) (+8 more)

### Community 1041 - "Community 1041"
Cohesion: 0.16
Nodes (11): _empty_fred(), _empty_te(), _macro_with_nan_gdp(), _macro_with_old_gdp(), TDD coverage for required-column raise + GDP fallback in _FRED_REGIME_MAP (#570), Macro DataFrame with gdp_growth all-NaN but yield_spread populated., gdp_growth populated up to mid, NaN after; yield_spread populated throughout., TestFredRegimeMapGdpEntry (+3 more)

### Community 1042 - "Community 1042"
Cohesion: 0.12
Nodes (16): format, title, type, RollingMetricPoint, date, description, properties, required (+8 more)

### Community 1044 - "Community 1044"
Cohesion: 0.12
Nodes (17): 9. Integration with Optimization, Black-Litterman Views from Factors, code:python (from optimizer.factors import FactorIntegrationConfig), code:block47 (E[r_i] = r_f + lambda_mkt * beta_i + sum_g lambda_g * z_{i,g), code:python (from optimizer.factors import factor_scores_to_expected_retu), code:python (from optimizer.factors import build_factor_exposure_constrai), code:python (from optimizer.factors import build_factor_bl_views), code:python (from optimizer.factors import estimate_factor_premia) (+9 more)

### Community 1045 - "Community 1045"
Cohesion: 0.21
Nodes (13): a(), b(), c(), d(), e(), h(), i(), l() (+5 more)

### Community 1046 - "Community 1046"
Cohesion: 0.21
Nodes (13): _(), a(), c(), e(), f(), i(), k(), l() (+5 more)

### Community 1047 - "Community 1047"
Cohesion: 0.21
Nodes (14): _(), a(), d(), e(), f(), i(), l(), m() (+6 more)

### Community 1048 - "Community 1048"
Cohesion: 0.23
Nodes (14): _(), a(), c(), d(), f(), i(), l(), m() (+6 more)

### Community 1049 - "Community 1049"
Cohesion: 0.19
Nodes (14): a(), c(), d(), e(), f(), l(), m(), n() (+6 more)

### Community 1050 - "Community 1050"
Cohesion: 0.09
Nodes (13): build_region_linear_constraints(), Region-level linear-constraint helper for skfolio :class:`MeanRisk`.  Region is, Build skfolio ``groups`` and ``linear_constraints`` for region caps.      Parame, Return a skfolio DSL-safe group token by replacing hyphens with spaces.      skf, Build skfolio ``groups`` and ``linear_constraints`` for region caps.      Region, sanitize_group_token(), Tests for region linear-constraint helper (issue #533)., Tests for the skfolio DSL token sanitizer. (+5 more)

### Community 1051 - "Community 1051"
Cohesion: 0.07
Nodes (28): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-ldb-debug.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md (+20 more)

### Community 1052 - "Community 1052"
Cohesion: 0.36
Nodes (7): _patched_startup(), Tests for FastAPI lifespan eviction daemon wiring (issue #693)., test_when_daemon_starts_then_info_log_emitted(), test_when_ensure_daemon_raises_then_error_logged_with_exc_info(), test_when_ensure_daemon_raises_then_startup_continues_and_scheduler_starts(), test_when_lifespan_starts_then_ensure_daemon_called_before_scheduler_start(), test_when_lifespan_starts_then_ensure_daemon_running_invoked()

### Community 1053 - "Community 1053"
Cohesion: 0.12
Nodes (9): At a calendar review date with no drift breach, no rebalancing., One business day before the review interval → always False., Overdue review (more than trading_days elapsed) with breach → True., Hybrid with relative threshold behaves consistently., current_date == last_review_date (0 elapsed) → False., Saturday before the 21-bday mark → False.          BDay(19) from 2024-01-02 = 20, BDay(21) from last_review is a business day → True with breach., Exactly 63 bdays elapsed for quarterly config → True with breach. (+1 more)

### Community 1054 - "Community 1054"
Cohesion: 0.15
Nodes (16): build_portfolio_pipeline, PortfolioResult, backtest, compute_net_backtest_returns, _compute_net_sharpe, _extract_summary, _extract_weight_changes, _extract_weights (+8 more)

### Community 1055 - "Community 1055"
Cohesion: 0.21
Nodes (14): ae(), ce(), constructor(), fe(), ie(), ke(), le(), ne() (+6 more)

### Community 1056 - "Community 1056"
Cohesion: 0.18
Nodes (7): _make_assembly(), Tests for DataAssembly risk-free rate properties., Build a minimal DataAssembly with defaults for required fields., DGS3MO=5.0% annual -> (1.05)^(1/252) - 1., TestRiskFreeRateScalar, TestRiskFreeRateSeries, TestSummaryRiskFreeRate

### Community 1057 - "Community 1057"
Cohesion: 0.12
Nodes (15): Basic Install, code:bash (pip install -e .), code:bash (pip install -e ".[dev]"), code:python (import optimizer), code:bash (pip install -e ".[dmm]"), code:bash (# All tests), code:bash (# Lint), Deep Markov Model (Optional) (+7 more)

### Community 1058 - "Community 1058"
Cohesion: 0.12
Nodes (15): Available Ratio Measures, Building Scorers, Code Examples, code:python (from optimizer.scoring import ScorerConfig), code:python (from optimizer.scoring import ScorerConfig, build_scorer), code:python (from optimizer.scoring import ScorerConfig), code:python (from optimizer.scoring import ScorerConfig, build_scorer), Gotchas and Tips (+7 more)

### Community 1059 - "Community 1059"
Cohesion: 0.09
Nodes (23): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md, prompt-mav-security.md (+15 more)

### Community 1060 - "Community 1060"
Cohesion: 0.1
Nodes (17): FactorOOSConfig, FactorOOSResult, _make_folds(), Rolling block out-of-sample validation for factor predictive power., Configuration for rolling block OOS validation.      Parameters     ----------, Results from rolling block OOS factor validation.      Attributes     ----------, Generate (train, val) date-index pairs for rolling block CV.      Fold count = `, floor((60 - 24) / 12) = 3. (+9 more)

### Community 1061 - "Community 1061"
Cohesion: 0.13
Nodes (4): DatabaseService, payload, req, DataManagementPanelComponent

### Community 1062 - "Community 1062"
Cohesion: 0.13
Nodes (16): DAY 18 MARZO, DAY 19 FEBBRAIO, DAY 26 FEBBRAIO, DAY 28 MARZO, DAY 5 MARZO, DAY 6 GIUGNO, 🎯 Hook, Hook (+8 more)

### Community 1063 - "Community 1063"
Cohesion: 0.12
Nodes (4): Tests for DataValidator transformer., Small return DataFrame with edge cases., returns_df(), TestDataValidator

### Community 1064 - "Community 1064"
Cohesion: 0.02
Nodes (86): anyIdentifierCall, BRINSON_RESPONSE, calledWithName, calledWithNew, calls, el, emptyApi, emptyCtx (+78 more)

### Community 1065 - "Community 1065"
Cohesion: 0.12
Nodes (6): Structural tests for ``research/RUNBOOK.md`` (issue #576).  Verifies the runbook, TestApprovedAlternativesNamed, TestProhibitedPatternsNamed, TestRunbookExists, TestRunbookSections, TestSchedulerPollReference

### Community 1066 - "Community 1066"
Cohesion: 0.09
Nodes (10): Issue #542: per-country transaction-cost dict + weighted helper., Issue #542: per-country transaction-cost dict + weighted helper., Issue #542: per-country transaction-cost dict + weighted helper., Ticker absent from country_map falls through to default (e.g. None)., Ticker absent from country_map falls through to default (e.g. None)., Ticker absent from country_map falls through to default (e.g. None)., Pure function: no DB, no FS, no logger calls., Pure function: no DB, no FS, no logger calls. (+2 more)

### Community 1067 - "Community 1067"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 1 — Session State & Background Job Foundation, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1068 - "Community 1068"
Cohesion: 0.14
Nodes (13): 1. Problem with the current page, 2. Target architecture: 3-pane construction surface, 3. Workflow: stages, not a one-way wizard, 4. Functionality gaps to close (priority order), 5. Aesthetic principles, 6. Suggested component decomposition, 7. Phased rollout, 8. The differentiator (one-line pitch) (+5 more)

### Community 1069 - "Community 1069"
Cohesion: 0.1
Nodes (15): Rolling block or CPCV out-of-sample validation of factor IC and spreads.      Pa, run_factor_oos_validation(), _make_panel(), panel_48(), panel_60(), Tests for rolling block out-of-sample factor validation., mean_oos_ic is the mean of per-fold IC values., Corrupting training-window scores must not change OOS IC. (+7 more)

### Community 1070 - "Community 1070"
Cohesion: 0.21
Nodes (11): _has_failed_call(), _no_failed_call(), Pure-unit tests for the four background-job wrapper functions in macro_regime., Success branch: running status recorded; service called with on_progress; no fai, CancelledError branch: wrapper returns silently; no failure status recorded., Generic exception branch: failure status recorded with correct error message., cancel_event-provided branch: an explicit Event is accepted (not defaulted)., test_when_cancel_event_provided_then_used_not_defaulted() (+3 more)

### Community 1071 - "Community 1071"
Cohesion: 0.11
Nodes (19): title, type, properties, title, type, title, type, benchmarkWeight (+11 more)

### Community 1072 - "Community 1072"
Cohesion: 0.17
Nodes (4): Tests for factor configuration enums and dataclasses., TestFactorValidationConfig, TestRegimeTiltConfig, TestWinsorizeMethodEnum

### Community 1073 - "Community 1073"
Cohesion: 0.21
Nodes (4): TestCurrencyDedupRank, currency_dedup_rank(), Return the deduplication priority rank for a currency code.      Lower rank is p, TestCurrencyDedupRank

### Community 1074 - "Community 1074"
Cohesion: 0.13
Nodes (14): #415b — Centralized a11y fixes (shared layer), #415c — Create Portfolio modal polish, #415d — Per-page remediation: dashboard, portfolio-builder, portfolio-detail, #415e — Per-page remediation: optimization-studio, risk-center, factor-research, backtesting, #415f — Per-page remediation: ai-control-room, attribution, rebalancing, settings, macro-intelligence, instrument-detail, #415g — Regression verification, Baseline already satisfied, code:sh (# One-time install) (+6 more)

### Community 1075 - "Community 1075"
Cohesion: 0.17
Nodes (9): PREPROCESSING_PIPELINE, badges, btn, card, el, emitted, errEl, fix (+1 more)

### Community 1078 - "Community 1078"
Cohesion: 0.15
Nodes (10): badges, btn, card, el, emitted, errEl, fix, keys (+2 more)

### Community 1079 - "Community 1079"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 1 — Result Service & State Management, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1080 - "Community 1080"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 2 — Allocation & Analytics Components, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1081 - "Community 1081"
Cohesion: 0.17
Nodes (9): badge, badges, el, emitted, errEl, fix, RESULT_WITH_WARNINGS, SAMPLE_RESULT (+1 more)

### Community 1082 - "Community 1082"
Cohesion: 0.28
Nodes (13): a(), b(), c(), f(), i(), k(), l(), m() (+5 more)

### Community 1083 - "Community 1083"
Cohesion: 0.23
Nodes (13): a(), c(), e(), f(), i(), l(), m(), o() (+5 more)

### Community 1084 - "Community 1084"
Cohesion: 0.06
Nodes (23): Stamp ``last_heartbeat_at = NOW()`` iff row is still running.          Returns `, Stamp ``last_heartbeat_at = NOW()`` iff row is still running.          Returns `, Stamp ``last_heartbeat_at = NOW()`` iff row is still running.          Returns `, Stamp ``last_heartbeat_at = NOW()`` iff row is still running.          Returns `, Check if any job of *job_type* is pending or running., Check if any job of *job_type* is pending or running., Check if any job of *job_type* is pending or running., Mark genuinely dead pending/running rows as failed.          Spec 12.3.3 — a row (+15 more)

### Community 1085 - "Community 1085"
Cohesion: 0.13
Nodes (14): 1. Regime & Tilts, 2. Factor IS / OOS IC, 3. Optimizer Config Diff vs Default, 4. Binding Constraints, 5. Top-4 Retighten Trace, 6. Hybrid Rebalance Decision, 7. 17-Rule Checklist, 8. Metrics (+6 more)

### Community 1086 - "Community 1086"
Cohesion: 0.14
Nodes (12): Immutable configuration for :class:`skfolio.prior.SyntheticData`.      Generates, SyntheticDataConfig, build_synthetic_data(), Build a skfolio :class:`SyntheticData` prior from *config*.      Parameters, Build a skfolio :class:`SyntheticData` prior from *config*.      Parameters, optimizer.synthetic __init__, Tests for synthetic data factory functions., Integration tests using real skfolio fit/predict. (+4 more)

### Community 1087 - "Community 1087"
Cohesion: 0.17
Nodes (9): badge, el, emitted, errEl, fix, paths, RESULT_FAILED, SAMPLE_RESULT (+1 more)

### Community 1088 - "Community 1088"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 3 — Chart Components (Frontier & Backtest), Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1089 - "Community 1089"
Cohesion: 0.17
Nodes (9): btn, el, emitted, errEl, fix, isOnly, oosOnly, passing (+1 more)

### Community 1090 - "Community 1090"
Cohesion: 0.17
Nodes (9): Atomically create a job only if none is already active.          Stamps ``worker, Atomically create a job only if none is already active.          Stamps ``worker, Atomically create a job only if none is already active.          Stamps ``worker, Atomically create a job only if none is already active.          Stamps ``worker, Database operations for the ``background_jobs`` table., Ensure background_jobs table exists (for test isolation)., Insert a new job row and return the ORM instance., Insert a new job row and return the ORM instance. (+1 more)

### Community 1091 - "Community 1091"
Cohesion: 0.14
Nodes (13): 17-Rule Checklist (from `portfolio_checklist.md`), Additional Notes, code:block1 (research/), code:block2 (cli/ ──→ pipeline/ ──→ optimization/ ──→ optimizer/ (library), Dependency Direction, Description, Features, Import Rules (+5 more)

### Community 1092 - "Community 1092"
Cohesion: 0.13
Nodes (15): Final — Report + terminal gate (`pipeline/_report.py`, `_checklist.py`), Pipeline Steps (must be reproduced in this exact order), Run-level config (collected before Step 1, mirrors the 9 CLI flags), Step 1 — Load (`pipeline/_load.py::load_data`), Step 1b — Date slicing (`_main.py` step 1b), Step 2.5 — Clean returns (`_load.py::_materialise_clean_returns`), Step 2 — Screen (`pipeline/_screen.py::screen_investable` / `optimizer.universe`), Step 3 — Factor history (`pipeline/_factors.py::build_history`) (+7 more)

### Community 1093 - "Community 1093"
Cohesion: 0.17
Nodes (12): _artifact_paths(), _make_session_tempdir(), Create an isolated tempdir for one session's report artefacts., Absolute paths to the four canonical report artefacts., Create an isolated tempdir for one session's report artefacts., Create an isolated tempdir for one session's report artefacts., Absolute paths to the four canonical report artefacts., Absolute paths to the four canonical report artefacts. (+4 more)

### Community 1094 - "Community 1094"
Cohesion: 0.07
Nodes (27): MarketSnapshotResponse, description, properties, required, title, type, sp500Return, tenYearYield (+19 more)

### Community 1095 - "Community 1095"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 2 — Research Pipeline Step Implementations (13 steps), Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1096 - "Community 1096"
Cohesion: 0.14
Nodes (13): Additional Resources, Building, Code scaffolding, code:bash (ng serve), code:bash (ng generate component component-name), code:bash (ng generate --help), code:bash (ng build), code:bash (ng test) (+5 more)

### Community 1097 - "Community 1097"
Cohesion: 0.39
Nodes (11): _Assembly, _clean_df(), _fetch(), Tests for ``step_clean_returns`` (issue #700 — Step 4 of the wizard)., Stub for ``DataAssembly`` — only fields the handler touches., _seed(), test_when_assembly_missing_then_value_error_raised(), test_when_clean_returns_succeeds_then_session_updated_and_payload_returned() (+3 more)

### Community 1098 - "Community 1098"
Cohesion: 0.22
Nodes (5): Integration tests for GET /api/v1/jobs and GET /api/v1/jobs/{job_id}.  Uses the, Create a job row and optionally advance its status., _seed(), TestGetJob, TestListJobs

### Community 1099 - "Community 1099"
Cohesion: 0.14
Nodes (14): 4. Stock Selection, Buffer-Zone Hysteresis, code:python (from optimizer.factors import SelectionConfig), code:python (from optimizer.factors import select_fixed_count), code:python (from optimizer.factors import select_quantile), code:python (from optimizer.factors import apply_sector_balance), code:python (from optimizer.factors import select_stocks, SelectionConfig), code:python (from optimizer.factors import compute_selection_turnover) (+6 more)

### Community 1100 - "Community 1100"
Cohesion: 0.18
Nodes (10): ComputeJob, ComputeStatus, consoleErrorSpy, r, req, ScoreResponse, SelectResponse, statuses (+2 more)

### Community 1101 - "Community 1101"
Cohesion: 0.21
Nodes (5): Import-graph boundary tests for research.pipeline and research.cli.  Cycle 3 acc, _run_isolation(), TestCliNoAppAtImportTime, TestNoCircularImports, TestPipelineNoAppAtImportTime

### Community 1102 - "Community 1102"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 3 — FastAPI Router, Job Dispatch, Artifact Download, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1103 - "Community 1103"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 4 — Canvas Integration & Live-State UX, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1104 - "Community 1104"
Cohesion: 0.14
Nodes (13): cSpell.enabled, editor.formatOnSave, [html], editor.defaultFormatter, python.analysis.typeCheckingMode, python.defaultInterpreterPath, python.envFile, python.terminal.executeInFileDir (+5 more)

### Community 1105 - "Community 1105"
Cohesion: 0.12
Nodes (9): _load_migration(), Migration module must declare correct revision identifiers., upgrade() must emit SQL with the NYSE existence guard., Call upgrade() with a mock op and return the SQL string passed to execute()., downgrade() must emit SQL that targets the SPY row precisely., Load the migration module from its file path., TestDowngradeSQLContent, TestMigrationMetadata (+1 more)

### Community 1106 - "Community 1106"
Cohesion: 0.24
Nodes (22): Ambiguous Edges - Review These, Community Hubs (Navigation), Corpus Check, God Nodes (most connected - your core abstractions), Graph Freshness, Graph Report - optimizer  (2026-05-11), Graph Report - optimizer  (2026-05-12), Graph Report - optimizer  (2026-05-17) (+14 more)

### Community 1107 - "Community 1107"
Cohesion: 0.15
Nodes (12): 1. Basic Optimization, 2. Custom Pre-selection and Moments, 3. Black-Litterman Views, 4. HMM Regime Blending, 5. Full Pipeline with Rebalancing, code:python (import pandas as pd), code:python (from optimizer.pre_selection import PreSelectionConfig), code:python (from optimizer.views import BlackLittermanConfig) (+4 more)

### Community 1109 - "Community 1109"
Cohesion: 0.21
Nodes (7): _(), i(), l(), n(), s(), t(), u()

### Community 1110 - "Community 1110"
Cohesion: 0.25
Nodes (5): Cycle-3 §7.3 Top-4 retighten loop and sub-period Sharpe helpers., Sum of the top-4 weights (or all if fewer assets)., _retighten_error_message(), _top4_weight(), TestTop4Weight

### Community 1111 - "Community 1111"
Cohesion: 0.19
Nodes (7): ApiKeyAuthMiddleware, API-key authentication middleware., Reject requests missing a valid X-API-Key header.      Public paths and OPTIONS, _unauthorized(), delete_pipeline_session(), Delete a session. Idempotent — returns 204 even when missing., response()

### Community 1112 - "Community 1112"
Cohesion: 0.15
Nodes (12): Approved alternatives, code:sh (export MAX_POLL_SECONDS=43200   # 12 h ceiling), Cross-process restart behavior, Harness limitation, Liveness reaper, Orphan signals, Pre-#585–#588 rule (obsolete), Prohibited pattern (+4 more)

### Community 1113 - "Community 1113"
Cohesion: 0.27
Nodes (7): Explicit boundary contract for _slice_fundamentals_at.      The only observable, Build a one-row history panel with a known earnings value., period_date = as_of_date - lag_days MUST be included.          Publication date, period_date = as_of_date - lag_days + 1 MUST be excluded.          Publication d, When two rows exist, only the on-boundary row must be returned.          - perio, _slicer(), TestSliceFundamentalsAtPITBoundary

### Community 1114 - "Community 1114"
Cohesion: 0.15
Nodes (8): Acceptance criteria, Cycle 1 — Structural Setup & Core Layer, Following cycles, In scope, Objective, Out of scope (belongs to later cycles, do not touch), Preceding cycles, Project vision

### Community 1115 - "Community 1115"
Cohesion: 0.15
Nodes (8): Acceptance criteria, Cycle 2 — Small Features (Single Service, Clear Boundaries), Following cycles, In scope, Objective, Out of scope (belongs to later cycles, do not touch), Preceding cycles, Project vision

### Community 1116 - "Community 1116"
Cohesion: 0.17
Nodes (11): Complete History Selection, Correlation Filtering, Data Preparation and Universe Construction, Expiring Asset Filtering, Extreme Performance Selection, Outlier Treatment and Data Cleaning, Pareto-Optimal Selection, Pre-Selection Pipeline (+3 more)

### Community 1117 - "Community 1117"
Cohesion: 0.16
Nodes (15): items, description, minimum, title, type, items, description, items (+7 more)

### Community 1118 - "Community 1118"
Cohesion: 0.1
Nodes (21): title, type, DriftTotals, title, type, description, properties, required (+13 more)

### Community 1119 - "Community 1119"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 4 — Angular Stepper Navigation & Run-Level Configuration, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1120 - "Community 1120"
Cohesion: 0.29
Nodes (7): Anchoring to a Base Prior, code:python (from skfolio.prior import EntropyPooling), code:python (cfg = OpinionPoolingConfig(is_linear_pooling=False)), code:python (cfg = OpinionPoolingConfig(opinion_probabilities=(0.01, 0.01), Combining Expert Forecasts, Examples, Logarithmic Pooling

### Community 1121 - "Community 1121"
Cohesion: 0.33
Nodes (10): a(), c(), d(), e(), l(), m(), n(), o() (+2 more)

### Community 1122 - "Community 1122"
Cohesion: 0.33
Nodes (10): a(), c(), f(), l(), m(), n(), o(), r() (+2 more)

### Community 1123 - "Community 1123"
Cohesion: 0.17
Nodes (5): panel(), panel_with_nan(), Tests for cross-sectional preprocessing transformers (re-exports)., 50 periods × 12 assets — wider than ``min_group_size=8`` default., Same panel with one NaN per few rows (still ≥ 8 non-NaN per row).

### Community 1124 - "Community 1124"
Cohesion: 0.15
Nodes (7): _build_service(), Unit tests for MacroRegimeService.fetch_country and run_bulk_macro_fetch (issue, Return (service, mock_repo) with pre-wired scraper behaviours., TestFetchCountryIlsoleRaises, TestFetchCountrySuccess, TestFetchCountryTeNonSuccess, TestFetchCountryTeRaises

### Community 1125 - "Community 1125"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1126 - "Community 1126"
Cohesion: 0.17
Nodes (11): code:bash (python -m research.cli [OPTIONS]), code:bash (# Default run — full history, EUR base, no DB write), Examples, Exit codes, Notes, Options, Outputs, Pipeline steps (+3 more)

### Community 1127 - "Community 1127"
Cohesion: 0.1
Nodes (21): DriftDiagnostics, NormalizedPosition, PositionFlag, TradeAction, description, required, title, type (+13 more)

### Community 1128 - "Community 1128"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 5 — Per-Step UI Panels, Data Tables, Charts, Downloads, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1129 - "Community 1129"
Cohesion: 0.09
Nodes (21): 1. Move features out of `pages/`, 2. Co-locate each feature's service + model into its feature folder, 3. Build `core/` and keep `shared/`, 4. Orchestrator trio + sub-component subfolders (within every feature), 5. Remove dead / legacy code (as folders are touched), 6. Dependency direction (must hold after restructure), Appendix A — business logic to extract from components (current code), Appendix B — baseline (verified) (+13 more)

### Community 1130 - "Community 1130"
Cohesion: 0.09
Nodes (22): prompt_hashes, prompt-analyze-coverage.md, prompt-clarify-requirements.md, prompt-cycle-specializer.md, prompt-judge.md, prompt-mav-acceptance-criteria.md, prompt-mav-runtime.md, prompt-mav-security.md (+14 more)

### Community 1131 - "Community 1131"
Cohesion: 0.18
Nodes (9): 8. Equal Weighted (EqualWeightedConfig), Architecture, code:python (from optimizer.optimization import MeanRiskConfig, build_mea), code:python (from optimizer.optimization import EqualWeightedConfig, buil), Gotchas and Tips, Model Overview, Optimization, Solver Notes (+1 more)

### Community 1132 - "Community 1132"
Cohesion: 0.01
Nodes (156): AssetScreenerPanelComponent, filters, groups, IC_BADGE_MAP, reports, alert, btn, pts (+148 more)

### Community 1133 - "Community 1133"
Cohesion: 0.07
Nodes (26): _ensure_daemon_running(), _evict_stale(), _eviction_loop(), get_session(), _PipelineSession, In-process session store for the ``/portfolio-builder`` wizard.  Holds frozen ``, Return the session snapshot, or ``None`` if not present., Return the session snapshot, or ``None`` if not present. (+18 more)

### Community 1134 - "Community 1134"
Cohesion: 0.15
Nodes (8): Acceptance criteria, Cycle 3 — Medium-Complexity Features (Multiple Panels, Clear Services), Following cycles, In scope, Objective, Out of scope (belongs to later cycles, do not touch), Preceding cycles, Project vision

### Community 1135 - "Community 1135"
Cohesion: 0.07
Nodes (18): _dummy(), fundamentals(), price_history(), Tests for factor construction., Synthetic fundamentals for 10 tickers., 300 days of synthetic prices for 10 tickers., Minimal price history for factors that ignore prices., One-row market_cap frame shared by analyst/insider factor tests. (+10 more)

### Community 1136 - "Community 1136"
Cohesion: 0.17
Nodes (8): Empty-data and exception-path tests for optimization_service (issue #825).  Exis, # NOTE: already covered in test_optimization_service.py with the same match., Edge cases for _build_optimizer not covered by the existing test file., Config with only valid MeanRiskConfig fields must not raise., extract_results with a portfolio that has an empty weights_dict., Empty weights_dict → risk_contributions empty → result JSON-safe., TestBuildOptimizerEdgeCases, TestExtractResultsEmptyWeights

### Community 1137 - "Community 1137"
Cohesion: 0.18
Nodes (7): _make_asset_prices(), Empty-data and exception-path tests for dashboard_service (issue #825) — Part 2., Tickers present in weights but absent from prices columns should not crash, compute_asset_class_returns raises ValueError on insufficient price data., compute_asset_class_returns returns safe structure for minimal valid inputs., TestComputeAssetClassReturnsEmptyData, TestComputeAssetClassReturnsExceptionPaths

### Community 1138 - "Community 1138"
Cohesion: 0.08
Nodes (23): _empty_oos_result(), Tests for research/stock_selection_pipeline.py wiring., Issue #527: validate_oos must raise when n_folds == 0., Issue #530: classify_and_tilt persists rule-based regime to DB., Issue #531: warn when fewer than 11 GICS sectors represented., Issue #526: validate_is must wire spec-compliant FactorValidationConfig., `optimize_portfolio` must enable metadata routing once at entry., `optimize_portfolio` must enable metadata routing once at entry. (+15 more)

### Community 1139 - "Community 1139"
Cohesion: 0.18
Nodes (11): 2. Standardization, code:python (from optimizer.factors import standardize_all_factors, Stand), code:python (from optimizer.factors import orthogonalize_factors), code:python (from optimizer.factors import StandardizationConfig), Full Standardization, HEAVY_TAILED_FACTORS, PCA Orthogonalization, Presets (+3 more)

### Community 1140 - "Community 1140"
Cohesion: 0.18
Nodes (10): 1. Black-Litterman, code:python ("AAPL == 0.05"    # AAPL expected return is 5%), code:python ("AAPL - MSFT == 0.02"   # AAPL outperforms MSFT by 2%), code:python (# Standard BL with EquilibriumMu + LedoitWolf prior), Configuration, Factory Function, Posterior Formula, Presets (+2 more)

### Community 1141 - "Community 1141"
Cohesion: 0.18
Nodes (10): Absolute and Relative Views, code:python (from skfolio.optimization import MeanRisk), code:python (from skfolio.preprocessing import prices_to_returns), code:python (import pandas as pd), code:python (from skfolio.preprocessing import prices_to_returns), Composing with MeanRisk, Empirical Track Record, Examples (+2 more)

### Community 1142 - "Community 1142"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1143 - "Community 1143"
Cohesion: 0.21
Nodes (12): FxPriceConverter (sklearn TransformerMixin), ConfigurationError, ConvergenceError, DataError, FactorCoverageError, OptimizationError, OptimizerError (base exception), ValidationError (+4 more)

### Community 1144 - "Community 1144"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1145 - "Community 1145"
Cohesion: 0.27
Nodes (5): _factor(), _pool_result(), Route tests for the opinion-pool endpoint (issue #817).  Covers ``app.api.v1.vie, Issue #827: opinion_pooling.py lines 95-97 — DB error → 500., TestOpinionPool

### Community 1146 - "Community 1146"
Cohesion: 0.15
Nodes (8): Acceptance criteria, Cycle 4 — Complex Features (Heavy Panels, Partial Wiring), Following cycles, In scope, Objective, Out of scope (belongs to later cycles, do not touch), Preceding cycles, Project vision

### Community 1147 - "Community 1147"
Cohesion: 0.1
Nodes (5): Tests for synthetic data configs and enums., TestDependenceMethodType, TestSelectionCriterionType, TestSyntheticDataConfig, TestVineCopulaPresets

### Community 1148 - "Community 1148"
Cohesion: 0.18
Nodes (8): badge, el, emitted, errEl, fix, RESULT_FAILED, RESULT_PERSISTED, RESULT_SKIPPED

### Community 1149 - "Community 1149"
Cohesion: 0.2
Nodes (7): ctx, name, nullCtx, Portfolio, portfolioApi, PortfolioSnapshot, req

### Community 1150 - "Community 1150"
Cohesion: 0.2
Nodes (8): API surface, Choosing a linkage method, code:python (from skfolio.datasets import load_sp500_dataset), Composition pattern, Direct estimator access, Hierarchical Clustering, See also, When to use

### Community 1151 - "Community 1151"
Cohesion: 0.2
Nodes (9): Available estimators, code:python (from skfolio.datasets import load_sp500_dataset), code:python (DistanceConfig.for_pearson()), Composition pattern, Distance Estimators, Presets, See also, Validation (+1 more)

### Community 1152 - "Community 1152"
Cohesion: 0.2
Nodes (9): API surface, code:python (import pandas as pd), Composition pattern, Cross-rates via USD, Modes, Multi-Currency FX, See also, Strict vs lenient coverage (+1 more)

### Community 1153 - "Community 1153"
Cohesion: 0.2
Nodes (9): API surface, code:python (CSLinearRegressionConfig.for_default()), code:python (import numpy as np), Composition pattern, Cross-Sectional Linear Regression, Factor IC integration, See also, Shape contract (+1 more)

### Community 1154 - "Community 1154"
Cohesion: 0.2
Nodes (9): code:block1 (fundamentals --> construction --> standardization --> scorin), code:python (import pandas as pd), End-to-End Example, Factor Research, Factor Taxonomy, FactorGroupType (9 groups), FactorType (17 factors), Gotchas and Tips (+1 more)

### Community 1155 - "Community 1155"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1156 - "Community 1156"
Cohesion: 0.18
Nodes (11): TradeItem, RebalancePreviewResponse, $defs, description, required, title, type, description (+3 more)

### Community 1157 - "Community 1157"
Cohesion: 0.15
Nodes (13): description, title, type, description, title, type, exchange_count, instrument_count (+5 more)

### Community 1159 - "Community 1159"
Cohesion: 0.01
Nodes (186): bw, body, req, ctx, STUB_BRINSON, STUB_SNAPSHOT, BrinsonApiRequest, BrinsonApiResponse (+178 more)

### Community 1160 - "Community 1160"
Cohesion: 0.2
Nodes (10): 1. Construction, code:python (from optimizer.factors import FactorConstructionConfig), code:python (from optimizer.factors import PublicationLagConfig), code:python (from optimizer.factors import align_to_pit), code:python (from optimizer.factors import compute_all_factors, compute_f), Computing Factors, FactorConstructionConfig, Point-in-Time Alignment (+2 more)

### Community 1161 - "Community 1161"
Cohesion: 0.2
Nodes (9): 8. Mimicking Portfolios, Beta-Neutral Mimicking Portfolios, Building Mimicking Portfolios, code:python (from optimizer.factors import build_factor_mimicking_portfol), code:python (import pandas as pd), code:python (from optimizer.factors import compute_quintile_spread), code:python (from optimizer.factors import compute_cross_factor_correlati), Cross-Factor Correlation (+1 more)

### Community 1162 - "Community 1162"
Cohesion: 0.2
Nodes (10): 13. Regime-Blended Optimization (RegimeRiskConfig), Blended Optimizer, Blended Risk Computation, Blended Risk Measure, code:python (from optimizer.moments import HMMConfig, fit_hmm), code:python (from optimizer.optimization import compute_blended_risk_meas), code:python (import numpy as np), Configuration Fields (+2 more)

### Community 1163 - "Community 1163"
Cohesion: 0.2
Nodes (8): 1. Mean-Risk Optimization (MeanRiskConfig), Cardinality-Constrained Example, code:python (from optimizer.optimization import MeanRiskConfig), code:python (from optimizer.optimization import MeanRiskConfig, build_mea), Configuration Fields, Factory: build_mean_risk(), Presets, Short-Selling Example

### Community 1164 - "Community 1164"
Cohesion: 0.2
Nodes (10): code:python (# CORRECT: views reference factor names), Config Tuples vs. skfolio Lists, Empirical Track Record Requires History or Pre-Computed Omega, Estimators Are Not Stored in OpinionPoolingConfig, Factor Model Views Must Reference Factor Names, Gotchas and Common Pitfalls, Mean Equality and Inequality Views Are Merged, Opinion Probabilities Must Sum to At Most 1.0 (+2 more)

### Community 1165 - "Community 1165"
Cohesion: 0.08
Nodes (22): _annualized_return(), _build_country_map(), _daily_rf(), _downside_vol(), _fetch_benchmark_returns(), Pure metric computation functions extracted from stock_selection_pipeline.py.  Z, Download daily benchmark returns from yfinance., Build ticker → country mapping from ticker_profiles. (+14 more)

### Community 1166 - "Community 1166"
Cohesion: 0.25
Nodes (4): Issue #546: write_weights_csv contract., Issue #546: write_weights_csv contract., Issue #546: write_weights_csv contract., TestWriteWeightsCsv

### Community 1167 - "Community 1167"
Cohesion: 0.15
Nodes (13): title, type, title, type, title, type, properties, 1D (+5 more)

### Community 1168 - "Community 1168"
Cohesion: 0.15
Nodes (12): compilerOptions, baseUrl, esModuleInterop, module, moduleResolution, paths, skipLibCheck, strict (+4 more)

### Community 1169 - "Community 1169"
Cohesion: 0.2
Nodes (6): Cover the GDP-too-short fallthrough and yield-spread fallback arms., A single GDP observation (len < 2) defers to the yield-spread fallback., A positive but flat yield spread classifies as SLOWDOWN., A mildly inverted yield spread classifies as RECOVERY., An all-NaN yield spread leaves no usable signal → UNKNOWN., TestClassifyRegimeYieldSpreadFallback

### Community 1171 - "Community 1171"
Cohesion: 0.13
Nodes (15): default, title, type, items, title, type, title, type (+7 more)

### Community 1172 - "Community 1172"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 1 — Foundation: Data + Leaf Folders, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1173 - "Community 1173"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 2 — Business Logic: Optimization + Factors + Reporting, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1174 - "Community 1174"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 3 — Orchestration: Pipeline + CLI + Import Hardening, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1175 - "Community 1175"
Cohesion: 0.15
Nodes (8): Acceptance criteria, Cycle 5 — Portfolio Builder & Pipeline Stepper (In-Progress Hot Spots), Following cycles, In scope, Objective, Out of scope (belongs to Cycle 6, do not do here), Preceding cycles, Project vision

### Community 1176 - "Community 1176"
Cohesion: 0.11
Nodes (19): title, type, title, type, enum, title, type, type (+11 more)

### Community 1177 - "Community 1177"
Cohesion: 0.22
Nodes (8): code:python (from skfolio.datasets import load_sp500_dataset), Composition pattern, Hyperparameter search, Online Learning, Pipeline is not supported, See also, Thread safety, When to use

### Community 1178 - "Community 1178"
Cohesion: 0.22
Nodes (8): code:python (from skfolio.datasets import load_sp500_dataset), Composition pattern, Confidence level vs chi-squared kappa, DR-CVaR, Estimator surface, See also, Uncertainty Sets for Robust Mean-Risk, When to use

### Community 1179 - "Community 1179"
Cohesion: 0.22
Nodes (5): Tests for research/data/_regime.py., FRED map covers gdp, spread, and HY OAS series., TE map maps manufacturing_pmi to pmi., gdp_growth is in the required columns set., TestRegimeConstants

### Community 1180 - "Community 1180"
Cohesion: 0.22
Nodes (8): code:bash (pip install -e ".[dev]"), code:python (from optimizer.optimization import MeanRiskConfig, build_mea), code:block3 (prices → returns → [preprocess → pre-select → optimize] → ba), Design Principles, Features, Pipeline Data Flow, Portfolio Optimizer, Quick Start

### Community 1181 - "Community 1181"
Cohesion: 0.12
Nodes (18): items, title, type, items, $ref, beta, sharpe, volatility (+10 more)

### Community 1182 - "Community 1182"
Cohesion: 0.12
Nodes (20): FactorScoreResponse, FactorScoreResponse, description, properties, required, title, type, rawScore (+12 more)

### Community 1183 - "Community 1183"
Cohesion: 0.03
Nodes (69): var, description, title, type, Negative factor scores should drag expected returns below the CAPM baseline., TestNegativeScoresBelowMarket, TestComputeVIF, 2 valid assets with quantile=0.30 → k=1, needs 2 → should succeed. (+61 more)

### Community 1184 - "Community 1184"
Cohesion: 0.07
Nodes (21): BackgroundJob, Persistent background job record.      Replaces the in-memory dict in ``Backgrou, PydanticBase, BaseRepository, Generic repository with synchronous CRUD operations.      Type Parameters:, JobCreate, JobUpdate, _make_repo() (+13 more)

### Community 1185 - "Community 1185"
Cohesion: 0.19
Nodes (10): _build_non_trading_masks(), _build_ticker_exchange_map(), _pivot(), PriceLoader, _query_raw(), Price data loader — single responsibility: DB access and price loading., Forward-fill only on non-trading-day gaps per exchange.          Parameters, Load adjusted close prices from a PostgreSQL database.      Responsibilities (+2 more)

### Community 1186 - "Community 1186"
Cohesion: 0.15
Nodes (8): Acceptance criteria, Cycle 6 — Cleanup, Dead Code Removal & Final Verification, Following cycles, In scope, Objective, Out of scope (do not introduce here), Preceding cycles, Project vision

### Community 1187 - "Community 1187"
Cohesion: 0.29
Nodes (7): ApiErrorBody, ApiErrorLike, AttributionService, extractApiMessage(), formatValidationErrors(), mapHttpError(), readBodyMessage()

### Community 1188 - "Community 1188"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1189 - "Community 1189"
Cohesion: 0.11
Nodes (19): shares, side, ticker, weightDelta, anyOf, default, description, title (+11 more)

### Community 1190 - "Community 1190"
Cohesion: 0.22
Nodes (9): 5. Regime Tilts, Applying Tilts, code:python (from optimizer.factors import RegimeTiltConfig), code:python (from optimizer.factors import classify_regime), code:python (from optimizer.factors import apply_regime_tilts, get_regime), MacroRegime, Presets, Regime Classification (+1 more)

### Community 1191 - "Community 1191"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1192 - "Community 1192"
Cohesion: 0.22
Nodes (9): 11. Robust Mean-Risk (RobustConfig), code:python (from optimizer.optimization import RobustConfig, build_robus), code:python (from optimizer.optimization import bootstrap_covariance_unce), Configuration Fields, Kappa-Confidence Level Mapping, Presets, Standalone Bootstrap Covariance Utility, Uncertainty Set for Expected Returns (+1 more)

### Community 1193 - "Community 1193"
Cohesion: 0.22
Nodes (7): 4. Hierarchical Risk Parity -- HRP (HRPConfig), Algorithm Steps, code:python (from optimizer.optimization import HRPConfig), Configuration Fields, Presets, Usage with Custom Distance and Clustering, Using Non-Convex Risk Measures

### Community 1194 - "Community 1194"
Cohesion: 0.22
Nodes (7): code:python (from optimizer.views import EntropyPoolingConfig, build_entr), code:python (import numpy as np), Examples, Higher-Moment Views, Mean Equality and Inequality Views, Relative Views, Stress Testing

### Community 1195 - "Community 1195"
Cohesion: 0.33
Nodes (7): a(), c(), e(), i(), s(), t(), u()

### Community 1196 - "Community 1196"
Cohesion: 0.13
Nodes (14): 1. 3-pane shell component, 2. Signal store, 3. Left inputs pane with collapsible sections, 4. Stage strip + summary chips, 5. Canvas + analytics placeholder panes, 6. Action bar + route flag, Constraints, Description (+6 more)

### Community 1197 - "Community 1197"
Cohesion: 0.03
Nodes (58): 10. Accessibility + interaction baseline (real-user reachability), 10. Portfolio-builder page, 11. Green-gate the whole tree, 11. Settings page, 12. API contract validation (cross-cutting), 1. 3-pane shell component, 1. API endpoint contract coverage (routes layer), 1. <Feature title> (+50 more)

### Community 1198 - "Community 1198"
Cohesion: 0.11
Nodes (18): Blending Moments by Regime, code:python (from optimizer.moments import HMMBlendedMu, HMMConfig), code:python (from optimizer.moments import HMMBlendedCovariance, HMMConfi), code:python (from optimizer.moments import MomentEstimationConfig, build_), code:python (from optimizer.moments import HMMConfig, fit_hmm), code:python (from optimizer.moments import select_hmm_n_states), code:python (from optimizer.moments import fit_hmm, blend_moments_by_regi), Filtered vs. Smoothed Probabilities (+10 more)

### Community 1199 - "Community 1199"
Cohesion: 0.22
Nodes (8): Cost Awareness, Diversification, Factor Model, Portfolio Construction Checklist, Rebalancing, Risk-Adjusted Performance, Risk Management, Validation

### Community 1200 - "Community 1200"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 1 — T212 Normalization Service Foundation, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1201 - "Community 1201"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1202 - "Community 1202"
Cohesion: 0.44
Nodes (8): _empty(), _macro(), Lock raise-vs-warn contract for required regime columns (#571).  No DB. No netwo, Build a macro DataFrame with optional gdp_growth/yield_spread columns., test_no_warn_when_required_column_fresh(), test_non_required_column_still_warns_only(), test_raises_when_required_column_never_observed(), test_warns_when_required_column_has_stale_tail()

### Community 1203 - "Community 1203"
Cohesion: 0.28
Nodes (4): Structural tests for scheduler shell payloads (issue #574).  Verifies that ``sch, TestShellHarness, TestYfinancePayload, _yfinance_payload()

### Community 1204 - "Community 1204"
Cohesion: 0.13
Nodes (7): BacktestResultsPanelComponent, err, fixture, keys, names, panel, points

### Community 1205 - "Community 1205"
Cohesion: 0.05
Nodes (33): apply_sector_balance(), _cap_per_sector(), compute_selection_turnover(), Stock selection from composite scores., Evict lowest-scoring excess members from any over-quota sector., Adjust selection for sector-proportional representation.      Iterates the balan, Select top N stocks by composite score with buffer.      Parameters     --------, Compute selection turnover as fraction of universe changed.      Parameters (+25 more)

### Community 1206 - "Community 1206"
Cohesion: 0.13
Nodes (15): description, title, type, EntropyPoolingResponse, description, properties, required, title (+7 more)

### Community 1207 - "Community 1207"
Cohesion: 0.22
Nodes (9): **4.1 Return Metrics**, **4.2 Risk Metrics**, **4.3 Risk-Adjusted Metrics**, **4.4 Temporal Analysis — The Hockey Stick Pattern**, **4. OOS Performance Analysis**, **Maximum Drawdown**, **Sharpe Ratio Calculation**, **Sortino Ratio and Downside Volatility** (+1 more)

### Community 1208 - "Community 1208"
Cohesion: 0.22
Nodes (8): Cost Awareness, Diversification, Factor Model, Portfolio Construction Checklist, Rebalancing, Risk-Adjusted Performance, Risk Management, Validation

### Community 1209 - "Community 1209"
Cohesion: 0.03
Nodes (74): _enable_webhook(), Integration tests: webhook fires on background-job failure across routers.  Cove, No webhook is dispatched when a job completes successfully., When ``NOTIFICATION_WEBHOOK_URL`` is unset, failure does not post., Route webhook dispatch to the test URL and silence Prometheus calls., Swap each service's ``_session_factory`` for a DB-less stub., Each of the four router services posts to the webhook on ``failed``., stub_session_factories() (+66 more)

### Community 1210 - "Community 1210"
Cohesion: 0.29
Nodes (4): build_mu_uncertainty_set(), Factories for skfolio uncertainty-set estimators., Build a skfolio mu uncertainty-set estimator from *config*., TestBuildMuUncertaintySet

### Community 1211 - "Community 1211"
Cohesion: 0.11
Nodes (19): properties, title, type, title, type, description, title, type (+11 more)

### Community 1212 - "Community 1212"
Cohesion: 0.04
Nodes (51): _render_checklist_table, _validate_checklist (17 rules), write_checklist_json, write_metrics_json, _check_country_coverage, _check_fred_freshness, _check_price_coverage, _check_price_staleness (+43 more)

### Community 1213 - "Community 1213"
Cohesion: 0.25
Nodes (7): Attribution, Contributor Covenant Code of Conduct, Enforcement, Enforcement Responsibilities, Our Pledge, Our Standards, Scope

### Community 1214 - "Community 1214"
Cohesion: 0.09
Nodes (11): for_daily_annual(), PreSelectionConfig, Configuration for the pre-selection pipeline., Immutable configuration for the pre-selection pipeline.      All parameters map, Tests for PreSelectionConfig.__post_init__ validation (issue #64)., Behavioral tests exercising specific pipeline steps with crafted data., An all-NaN column gets imputed by cross-sectional mean and         passes Select, NaN column gets imputed, constant column dropped by         DropZeroVariance, th (+3 more)

### Community 1215 - "Community 1215"
Cohesion: 0.05
Nodes (43): _cv_fold_metrics(), _drawdowns(), _equity_curve(), extract_backtest_metrics(), Backtest service: wraps run_full_pipeline / run_full_pipeline_with_selection.  S, Extract all BacktestRun columns from a PortfolioResult.      Uses ``result.backt, Extract all BacktestRun columns from a PortfolioResult.      Uses ``result.backt, Return a 1-D returns Series from portfolio.returns_df. (+35 more)

### Community 1216 - "Community 1216"
Cohesion: 0.18
Nodes (10): OutlierTreater, DataValidator, Data validation transformer for return DataFrames., Replace infinities and extreme values with NaN.      Operates on a return DataFr, Store metadata.  This transformer is stateless., Replace ``inf`` / ``-inf`` and extreme returns with ``NaN``., Return feature names (pass-through)., _validate_input() (+2 more)

### Community 1217 - "Community 1217"
Cohesion: 0.17
Nodes (12): z_47c76bca69ccc1a4__config_py, nums, n_branches, n_excluded, n_files, n_missing, n_missing_branches, n_partial_branches (+4 more)

### Community 1218 - "Community 1218"
Cohesion: 0.14
Nodes (14): prompt_hashes, prompt-cycle-specializer.md, prompt-optimize-requirements.md, prompt-phase-0-complexity.md, prompt-phase-1-planning.md, prompt-phase-2-batch-review.md, prompt-phase-3-implementation.md, prompt-phase-5-final-review.md (+6 more)

### Community 1219 - "Community 1219"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1220 - "Community 1220"
Cohesion: 0.11
Nodes (19): properties, description, title, type, nAssets, rationale, tickersMissingData, viewConfidences (+11 more)

### Community 1221 - "Community 1221"
Cohesion: 0.18
Nodes (8): Acceptance criteria, Cycle 1 — Test Infrastructure & Fixtures, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1222 - "Community 1222"
Cohesion: 0.18
Nodes (8): Acceptance criteria, Cycle 2 — API Layer Coverage, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1223 - "Community 1223"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 2 — Drift API Endpoint + Reconciliation, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1224 - "Community 1224"
Cohesion: 0.2
Nodes (5): Optimizer creation via _build_optimizer., mean_risk is listed in FRONTIER_TYPES so the /optimize route applies frontier si, _build_optimizer returns a plain optimizer; frontier sizing is the route's job., Regression for #419: config dict holding risk_measure must not collide., TestResolveOptimizer

### Community 1225 - "Community 1225"
Cohesion: 0.19
Nodes (13): download_artifact(), _file_response(), post_session(), Sessions router for ``/api/v1/pipeline-builder/sessions`` (issue #713).  Three e, Look up the absolute artefact path; 404 if missing on disk., Build the ``FileResponse`` with media-type + ``Content-Disposition``., Create a new pipeline-builder session., Stream a final artefact file. Requires ``step_persist`` completed. (+5 more)

### Community 1226 - "Community 1226"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1227 - "Community 1227"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1228 - "Community 1228"
Cohesion: 0.25
Nodes (8): code:python (from optimizer.moments import MomentEstimationConfig, build_), code:python (from optimizer.factors import build_factor_exposure_constrai), code:python (from sklearn.pipeline import Pipeline), code:python (# Access nested parameters for tuning), Common Patterns, Factor Exposure Constraints, Passing Prior Estimators, Pipeline Integration

### Community 1229 - "Community 1229"
Cohesion: 0.25
Nodes (7): 2. Entropy Pooling, code:python (# Mean-only views), Configuration, Factory Function, Mathematical Formulation, Presets, Supported View Types

### Community 1230 - "Community 1230"
Cohesion: 0.18
Nodes (8): Acceptance criteria, Cycle 3 — Frontend Unit Coverage, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1231 - "Community 1231"
Cohesion: 0.21
Nodes (8): Integration tests for GET /api/v1/rebalance/preview/{name} (issue #425).  Exerci, Regression for #425: this previously returned 404 for ``trading212``., Seed three portfolios covering every empty-state path defined by #425., _seed_policy(), _seed_portfolio(), _seed_snapshot(), seeded_preview_portfolios(), test_preview_portfolio_without_active_policy_returns_200_empty()

### Community 1233 - "Community 1233"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 3 — Frontend Canvas Drift View + Trade List UI, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1234 - "Community 1234"
Cohesion: 0.18
Nodes (8): Acceptance criteria, Cycle 4 — Integration & Error Audit, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1235 - "Community 1235"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 4 — Edge Cases & Diagnostics Surface, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1236 - "Community 1236"
Cohesion: 0.25
Nodes (8): **7.2.1 [CRITICAL] 100% European Geographic Concentration**, **7.2.2 [CRITICAL] Communication Services at 24.64% — Extreme Overweight**, **7.2.3 [SIGNIFICANT] Hockey Stick 2025-2026 — Sustainability Question**, **7.2.4 [SIGNIFICANT] Sharpe > 2 — Methodological Question**, **7.2.5 [MODERATE] Massively Underweight Technology**, **7.2.6 [MODERATE] Absent Healthcare — Defensive Blind Spot**, **7.2.7 [MODERATE] Unhedged GBP/EUR Currency Risk**, **7.2 Concerns and Risks**

### Community 1237 - "Community 1237"
Cohesion: 0.18
Nodes (8): Acceptance criteria, Cycle 5 — Real-User E2E & Accessibility, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1238 - "Community 1238"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 1 — BuilderStore & 3-Pane Grid, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1239 - "Community 1239"
Cohesion: 0.12
Nodes (10): _make_prices(), Empty-data and exception-path tests for dashboard_service (issue #825) — Part 1., compute_drift raises ValueError when no broker positions AND no prices., compute_drift with valid broker positions returns a JSON-safe result., _actual_weights_from_prices raises ValueError when target tickers are     absent, compute_equity_curve with valid data returns a JSON-safe result., TestActualWeightsFromPricesExceptionPath, TestComputeDriftEmptyData (+2 more)

### Community 1240 - "Community 1240"
Cohesion: 0.29
Nodes (6): Angular Best Practices, Components, Services, State Management, Templates, TypeScript Best Practices

### Community 1241 - "Community 1241"
Cohesion: 0.23
Nodes (8): Cycle-3 §7.4 selector: dispatch to plain or robust ``MeanRisk``.      When ``rob, Cycle-3 §7.4 selector: dispatch to plain or robust ``MeanRisk``.      When ``rob, _select_optimizer(), _hard_config(), Cycle-3 §7.4 robust-path `_select_optimizer` tests (issue #540)., returns(), TestSelectOptimizerNonRobust, TestSelectOptimizerRobust

### Community 1242 - "Community 1242"
Cohesion: 0.08
Nodes (26): Return risk analytics (VaR, CVaR, volatility)., Query portfolio summary via PortfolioRepository., Query portfolio summary via PortfolioRepository., Return placeholder — risk_analytics_runs has no ORM model yet., Return placeholder — risk_analytics_runs has no ORM model yet., Collects per-section data from repositories.      Each method returns a plain di, Return portfolio-level summary data., Return risk analytics (VaR, CVaR, volatility). (+18 more)

### Community 1243 - "Community 1243"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 2 — InputsPane & StageStrip, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1244 - "Community 1244"
Cohesion: 0.39
Nodes (7): REPO_ROOT, runPsql(), seedDatabase(), delay(), globalSetup(), isHealthy(), waitForHealth()

### Community 1245 - "Community 1245"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 3 — CanvasPane, AnalyticsPane, ActionBar & Parity, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1246 - "Community 1246"
Cohesion: 0.08
Nodes (4): Tests for cli/portfolio.py — Strategy enum and _build_optimizer., test_value_to_member_lookup(), TestBuildOptimizer, TestStrategy

### Community 1247 - "Community 1247"
Cohesion: 0.2
Nodes (10): Return whether persistence is requested (param override OR run_config)., Step 14 (terminal) — persist research snapshot, gated on 17/17 PASS.      Calls, Return whether persistence is requested (param override OR run_config)., Step 14 (terminal) — persist research snapshot, gated on 17/17 PASS.      Calls, Return whether persistence is requested (param override OR run_config)., Return whether persistence is requested (param override OR run_config)., Step 14 (terminal) — persist research snapshot, gated on 17/17 PASS.      Calls, Step 14 (terminal) — persist research snapshot, gated on 17/17 PASS.      Calls (+2 more)

### Community 1248 - "Community 1248"
Cohesion: 0.11
Nodes (19): properties, default, description, title, type, anyOf, default, description (+11 more)

### Community 1249 - "Community 1249"
Cohesion: 0.17
Nodes (3): Issue #303: zero-target position with non-zero current must trigger exit., Zero-target AND zero-current weight should not trigger spuriously., TestShouldRebalance

### Community 1250 - "Community 1250"
Cohesion: 0.11
Nodes (18): description, $ref, description, minimum, title, type, properties, buffer_zone (+10 more)

### Community 1251 - "Community 1251"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1252 - "Community 1252"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1253 - "Community 1253"
Cohesion: 0.16
Nodes (11): Convert a date-indexed pandas Series to ``{date_str: float | None}``.      NaN/I, Convert a date-indexed pandas Series to ``{date_str: float | None}``.      NaN/I, Convert a date-indexed pandas Series to ``{date_str: float | None}``.      NaN/I, _series_to_dict(), _series_to_dict replaces NaN/Inf/-Inf with None (issue #462).      PostgreSQL re, _series_to_dict replaces NaN/Inf/-Inf with None (issue #462).      PostgreSQL re, numpy.nan propagated through arithmetic must also be sanitised., numpy.nan propagated through arithmetic must also be sanitised. (+3 more)

### Community 1254 - "Community 1254"
Cohesion: 0.27
Nodes (3): formatNumber(), formatPercent(), ResultsPanelComponent

### Community 1255 - "Community 1255"
Cohesion: 0.11
Nodes (18): $ref, TradeRow, default, title, type, title, type, title (+10 more)

### Community 1257 - "Community 1257"
Cohesion: 0.18
Nodes (6): Empty-data and exception-path tests for attribution_service (issue #825).  Cover, run_brinson_attribution raises MissingDataError when the DB has no price     his, run_factor_attribution raises MissingDataError when _fetch_factor_exposures, run_factor_attribution delegates to compute_factor_attribution and         retur, TestRunBrinsonAttributionMissingBenchmark, TestRunFactorAttributionMissingScores

### Community 1258 - "Community 1258"
Cohesion: 0.09
Nodes (22): title, type, DriftRow, title, type, description, properties, required (+14 more)

### Community 1260 - "Community 1260"
Cohesion: 0.06
Nodes (14): Upsert an IlSole forecast observation row for a country on a given date., Bulk upsert bond yield rows for a country.          Args:             country: C, Upsert a single economic indicator (forecast) row for a country.          Args:, today(), Branch-coverage tests for app/utils/date_parsing.py.  Covers every format and ed, TestIsoFormat, TestMmYyFormat, TestMonDdSlashFormat (+6 more)

### Community 1262 - "Community 1262"
Cohesion: 0.29
Nodes (6): buildCommand, framework, headers, installCommand, outputDirectory, rewrites

### Community 1263 - "Community 1263"
Cohesion: 0.29
Nodes (7): 7. Diagnostics, code:python (from optimizer.factors import compute_factor_pca), code:python (from optimizer.factors import flag_redundant_factors), code:python (from optimizer.factors import check_survivorship_bias), PCA Analysis, Redundant Factor Detection, Survivorship Bias Check

### Community 1264 - "Community 1264"
Cohesion: 0.29
Nodes (7): code:python (from optimizer.factors import winsorize_cross_section), code:python (from optimizer.factors import z_score_standardize, rank_norm), code:python (from optimizer.factors import neutralize_sector), Standardization Pipeline Steps, Step 1: Winsorize, Step 2: Z-Score or Rank-Normal, Step 3: Sector Neutralize

### Community 1265 - "Community 1265"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1267 - "Community 1267"
Cohesion: 0.29
Nodes (7): 12. Distributionally Robust CVaR (DRCVaRConfig), code:python (from optimizer.optimization import DRCVaRConfig, build_dr_cv), Configuration Fields, Dispatch Behavior, Presets, Robust Variants, Usage

### Community 1268 - "Community 1268"
Cohesion: 0.29
Nodes (7): DistanceType, Enums, ExtraRiskMeasureType, LinkageMethodType, ObjectiveFunctionType, RatioMeasureType, RiskMeasureType

### Community 1269 - "Community 1269"
Cohesion: 0.29
Nodes (5): 4. Omega Calibration from Track Record, code:python (import pandas as pd), Example, Formula, Function Signature

### Community 1270 - "Community 1270"
Cohesion: 0.29
Nodes (6): Reporting a Vulnerability, Response timeline, Scope, Security Policy, Supported Versions, What to include

### Community 1272 - "Community 1272"
Cohesion: 0.14
Nodes (14): title, type, properties, items, title, type, breachedCount, entries (+6 more)

### Community 1273 - "Community 1273"
Cohesion: 0.18
Nodes (7): Issue #544: _information_ratio helper., Constant active return → std = 0 → IR = 0.0 per AC., Issue #544: _information_ratio helper., Issue #544: _information_ratio helper., Constant active return → std = 0 → IR = 0.0 per AC., Constant active return → std = 0 → IR = 0.0 per AC., TestInformationRatioHelper

### Community 1275 - "Community 1275"
Cohesion: 0.4
Nodes (3): Split *returns* into ``n_subperiods`` equal contiguous slices., _split_into_subperiods(), TestSplitIntoSubperiods

### Community 1276 - "Community 1276"
Cohesion: 0.06
Nodes (19): BuildProgress, BuildResult, FilterPipeline, InstrumentFilter, Universe Building Protocols - Interface definitions for universe construction., TickerCache, TickerMapper, Trading212ApiClient (+11 more)

### Community 1277 - "Community 1277"
Cohesion: 0.17
Nodes (11): _apply_coverage_gating(), _handle_zero_weight_fallback(), Composite scoring from standardized factor scores., Reduce IC history to a per-group point estimate.      ``decay_halflife == 0`` re, Reduce IC history to a per-group point estimate.      ``decay_halflife == 0`` re, Weighted average over available (non-NaN) groups per ticker.      For each ticke, Apply minimum-coverage threshold and optional coverage_ratio output., Apply minimum-coverage threshold and optional coverage_ratio output. (+3 more)

### Community 1278 - "Community 1278"
Cohesion: 0.22
Nodes (4): CountryNewsSummary(), CountryNewsSummaryAst, CountryNewsSummaryProperties, CountryNewsSummaryViewer

### Community 1279 - "Community 1279"
Cohesion: 0.33
Nodes (5): [0.1.0] - 2026-02-21, Added, Added, Changelog, [Unreleased]

### Community 1280 - "Community 1280"
Cohesion: 0.16
Nodes (11): _cache_regime_classification(), classify_and_tilt(), Step 6 — Macro regime classification.  Extracted from ``stock_selection_pipeline, Classify macro regime and compute regime-conditional group tilts.      Fix issue, Persist the rule-based regime via the injected persistence protocol., _patch_regime_steps(), Tests for research.pipeline._regime — Step 6 regime classification., _stub_assembly() (+3 more)

### Community 1281 - "Community 1281"
Cohesion: 0.33
Nodes (5): code:bash (MPLBACKEND=Agg PYTHONHASHSEED=0 python tests/research/baseli), Cycle 0 Baseline, Exit code, Generating the baseline, Regenerating after intentional changes

### Community 1282 - "Community 1282"
Cohesion: 0.2
Nodes (6): Verify raw construction values are in natural units (no sign flip).      The dir, Annualized volatility must be non-negative in natural units., Annualized vol should be in [0.01, 2.0] for typical equity data., Stocks generated with a common drift should have positive mean beta., ASSET_GROWTH must equal fundamentals['asset_growth'] exactly., TestFactorDirectionConventions

### Community 1283 - "Community 1283"
Cohesion: 0.08
Nodes (9): createPanel(), createComponent(), createFixture(), setup(), render(), create(), createPanel(), createCardWith() (+1 more)

### Community 1284 - "Community 1284"
Cohesion: 0.03
Nodes (78): decompose_fx_returns(), FxReturnDecomposition, FX return decomposition utilities., Decomposition of portfolio returns into stock and FX components.      The total, Decompose total returns into local, FX, and cross components.      Parameters, Tests for FX return decomposition., Tests for decompose_fx_returns()., Build local prices, base prices, FX rates, and currency map. (+70 more)

### Community 1286 - "Community 1286"
Cohesion: 0.12
Nodes (19): main(), Emit deterministic JSON-schema snapshots for API response models.  Each domain m, Return the by-alias JSON schema for one model (casing from its base)., Return the by-alias JSON schema for one model (casing from its base)., Map each model's class name to its JSON schema., Map each model's class name to its JSON schema., Serialise a snapshot deterministically (sorted keys, trailing newline)., Serialise a snapshot deterministically (sorted keys, trailing newline). (+11 more)

### Community 1287 - "Community 1287"
Cohesion: 0.29
Nodes (3): Tests for research.pipeline._optimize — Step 7 portfolio optimization., TestCostConstants, TestOptimizePortfolio

### Community 1288 - "Community 1288"
Cohesion: 0.22
Nodes (4): AssetFactorData(), AssetFactorDataAst, AssetFactorDataProperties, AssetFactorDataViewer

### Community 1289 - "Community 1289"
Cohesion: 0.22
Nodes (4): FactorWeightAdaptation(), FactorWeightAdaptationAst, FactorWeightAdaptationProperties, FactorWeightAdaptationViewer

### Community 1290 - "Community 1290"
Cohesion: 0.17
Nodes (11): 1. <Feature title>, 2. <Feature title>, 3. <Feature title>, Constraints, Description, Global acceptance criteria, Goals, Non-goals (+3 more)

### Community 1291 - "Community 1291"
Cohesion: 0.2
Nodes (10): _make_instrument(), Integration tests for POST /api/v1/universe/screen (issue #426).  Reproduces the, Regression for #426: empty body used to surface 422 from the pivot crash., Preset request must succeed over a universe with duplicate (ticker, date)., Empty DB + empty body → valid empty response., Seed two instruments sharing the same yfinance_ticker ('DUP').      This mirrors, seeded_universe_with_duplicates(), test_empty_body_returns_200_with_duplicate_instruments() (+2 more)

### Community 1292 - "Community 1292"
Cohesion: 0.17
Nodes (9): btn, card, chip, el, emitted, errEl, fix, RESULT_CLEAN (+1 more)

### Community 1293 - "Community 1293"
Cohesion: 0.01
Nodes (271): aggregateStatus(), isTerminal(), mapPollStatus(), nextStepId(), TERMINAL_POLL, BaseCurrency, BuildHistoryStepResult, ChecklistRule (+263 more)

### Community 1294 - "Community 1294"
Cohesion: 0.33
Nodes (6): 2. Risk Budgeting (RiskBudgetingConfig), code:python (from optimizer.optimization import RiskBudgetingConfig), code:python (import numpy as np), Configuration Fields, Factory: build_risk_budgeting(), Presets

### Community 1295 - "Community 1295"
Cohesion: 0.33
Nodes (6): 5. Hierarchical Equal Risk Contribution -- HERC (HERCConfig), code:python (from optimizer.optimization import HERCConfig), code:python (from optimizer.optimization import HERCConfig, build_herc), Configuration Fields, Presets, Usage

### Community 1297 - "Community 1297"
Cohesion: 0.18
Nodes (10): files, z_47c76bca69ccc1a4__alpha_py, z_c7f45a9d5e5efe7e__config_py, format, globals, note, version, hash (+2 more)

### Community 1298 - "Community 1298"
Cohesion: 0.17
Nodes (10): config, fields, lang, pipeline, separator, docs, tags, title (+2 more)

### Community 1299 - "Community 1299"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1300 - "Community 1300"
Cohesion: 0.2
Nodes (7): Issue #544: _sortino helper (Cycle 4 §9.3)., Issue #544: _sortino helper (Cycle 4 §9.3)., Sortino = ann_excess / downside_vol; downside is std on r < 0., Issue #544: _sortino helper (Cycle 4 §9.3)., Sortino = ann_excess / downside_vol; downside is std on r < 0., Sortino = ann_excess / downside_vol; downside is std on r < 0., TestSortinoHelper

### Community 1301 - "Community 1301"
Cohesion: 0.17
Nodes (8): Return a dict mapping section ID → section data for all requested sections., Return a dict mapping section ID → section data for all requested sections., Render section_data into PDF bytes., Render section_data into PDF bytes., Dispatch rendering to section-specific method., Dispatch rendering to section-specific method., Generate a PDF report and save it to disk.          Returns:             report_, Generate a PDF report and save it to disk.          Returns:             report_

### Community 1302 - "Community 1302"
Cohesion: 0.15
Nodes (13): title, type, EquityCurvePoint, description, properties, required, title, type (+5 more)

### Community 1303 - "Community 1303"
Cohesion: 0.33
Nodes (5): **1. Executive Summary**, **3.1 Holdings — Complete List**, **3.2 Sector Allocation**, **3. Portfolio Composition**, **9. Conclusions**

### Community 1304 - "Community 1304"
Cohesion: 0.33
Nodes (6): **7.1.1 Exceptional Sharpe Ratio (2.35)**, **7.1.2 Below-Market Volatility with Superior Returns**, **7.1.3 Protection During Drawdown Phases**, **7.1.4 Academically Grounded Factor Model**, **7.1 Strengths**, **7. Strengths and Concerns**

### Community 1305 - "Community 1305"
Cohesion: 0.33
Nodes (6): **A.1 Sharpe Ratio**, **A.2 Sortino Ratio**, **A.3 Information Ratio**, **A.4 Herfindahl-Hirschman Index (HHI)**, **A.5 Annualized Volatility**, **Appendix — Formulas and Definitions**

### Community 1308 - "Community 1308"
Cohesion: 0.2
Nodes (7): 3. Opinion Pooling, Choosing a Framework, Configuration, Factory Function, Module Overview, Pooling Methods, View Integration

### Community 1312 - "Community 1312"
Cohesion: 0.07
Nodes (13): CovRegimeSelection(), CovRegimeSelectionAst, CovRegimeSelectionProperties, CovRegimeSelectionViewer, StressScenario(), StressScenarioAst, StressScenarioProperties, StressScenarioViewer (+5 more)

### Community 1314 - "Community 1314"
Cohesion: 0.25
Nodes (6): _ensure_datetime_index(), Return a copy of ``prices`` with a tz-naive ``DatetimeIndex``.      ``fetch_clos, Return a copy of ``prices`` with a tz-naive ``DatetimeIndex``.      ``fetch_clos, _ensure_datetime_index coerces ``prices.index`` to a tz-naive DatetimeIndex., _ensure_datetime_index coerces ``prices.index`` to a tz-naive DatetimeIndex., TestEnsureDatetimeIndex

### Community 1315 - "Community 1315"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1316 - "Community 1316"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1317 - "Community 1317"
Cohesion: 0.22
Nodes (4): DeltaCalibration(), DeltaCalibrationAst, DeltaCalibrationProperties, DeltaCalibrationViewer

### Community 1318 - "Community 1318"
Cohesion: 0.4
Nodes (5): code:python (from optimizer.factors import run_factor_oos_validation, Fac), code:python (from optimizer.validation import CPCVConfig), CPCV Mode, FactorOOSConfig, Out-of-Sample Validation

### Community 1319 - "Community 1319"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1320 - "Community 1320"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1321 - "Community 1321"
Cohesion: 0.4
Nodes (5): ClusteringConfig, code:python (from optimizer.optimization import DistanceConfig, DistanceT), code:python (from optimizer.optimization import ClusteringConfig, Linkage), DistanceConfig, Sub-Configs

### Community 1322 - "Community 1322"
Cohesion: 0.7
Nodes (4): e(), n(), r(), t()

### Community 1325 - "Community 1325"
Cohesion: 0.12
Nodes (14): ConfigPanelComponent, cases, VisibilityCase, AssetWeight, BacktestPoint, MonthlyReturn, PerformanceMetrics, PortfolioJobProgress (+6 more)

### Community 1326 - "Community 1326"
Cohesion: 0.12
Nodes (17): FactorScoreListResponse, $defs, description, properties, required, title, type, description (+9 more)

### Community 1327 - "Community 1327"
Cohesion: 0.22
Nodes (8): Additional Notes, Description, Features, Non-functional Requirements, Project Name, Project Structure, Tech Stack, Testing & Coverage

### Community 1329 - "Community 1329"
Cohesion: 0.22
Nodes (6): NewsSentimentOutput, End-to-end flow: series → signal → adjusted alpha., Bearish news from today + bullish view → alpha drops., News from 60 days ago (half_life=5) contributes almost nothing., Equal bullish and bearish news cancel → alpha stays the same., TestSentimentPipelineIntegration

### Community 1330 - "Community 1330"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1331 - "Community 1331"
Cohesion: 0.4
Nodes (5): **5.1 Stress Test Methodology**, **5.2 Stress Scenario Results**, **5.3 Concentration — Herfindahl-Hirschman Index (HHI)**, **5.4 Single-Stock Risk**, **5. Stress Tests and Adverse Scenario Analysis**

### Community 1332 - "Community 1332"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1333 - "Community 1333"
Cohesion: 0.05
Nodes (42): anyOf, default, title, anyOf, default, description, title, description (+34 more)

### Community 1334 - "Community 1334"
Cohesion: 0.22
Nodes (4): NewsArticle(), NewsArticleAst, NewsArticleProperties, NewsArticleViewer

### Community 1335 - "Community 1335"
Cohesion: 0.1
Nodes (22): $ref, DiagnosticEntry, FlagInstance, description, properties, required, title, type (+14 more)

### Community 1337 - "Community 1337"
Cohesion: 0.21
Nodes (6): Return a date exactly ``bdays`` business days after ``base``., At a calendar review date with breach, rebalancing is triggered., Exactly trading_days elapsed is treated as a review date., Each branch surfaces a structured reason literal., _review_date(), TestShouldRebalanceHybridReason

### Community 1340 - "Community 1340"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1341 - "Community 1341"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1342 - "Community 1342"
Cohesion: 0.22
Nodes (4): MacroRegimeCalibration(), MacroRegimeCalibrationAst, MacroRegimeCalibrationProperties, MacroRegimeCalibrationViewer

### Community 1343 - "Community 1343"
Cohesion: 0.5
Nodes (3): Chapter runner — iterates generators and reports progress., Execute every generator in order and print a summary.      Parameters     ------, run_chapter()

### Community 1344 - "Community 1344"
Cohesion: 0.12
Nodes (17): SnapshotResponse, title, type, properties, items, total, SnapshotListResponse, $defs (+9 more)

### Community 1345 - "Community 1345"
Cohesion: 0.12
Nodes (17): title, type, properties, description, title, type, nExperts, poolingType (+9 more)

### Community 1346 - "Community 1346"
Cohesion: 0.18
Nodes (11): LiquidityAsset, description, required, title, type, LiquidityResponse, $defs, description (+3 more)

### Community 1347 - "Community 1347"
Cohesion: 0.38
Nodes (5): getLegend(), getSeriesAt(), legendType(), SeriesEntry, seriesLabelShow()

### Community 1348 - "Community 1348"
Cohesion: 0.22
Nodes (4): NewsSentimentOutput(), NewsSentimentOutputAst, NewsSentimentOutputProperties, NewsSentimentOutputViewer

### Community 1350 - "Community 1350"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1351 - "Community 1351"
Cohesion: 0.5
Nodes (3): Checklist, Related Issues, Summary

### Community 1352 - "Community 1352"
Cohesion: 0.22
Nodes (9): ExpertViewSummary, required, title, type, OpinionPoolResponse, $defs, required, title (+1 more)

### Community 1353 - "Community 1353"
Cohesion: 0.5
Nodes (3): 10. Stacking Optimization (StackingConfig), Configuration Fields, Usage

### Community 1354 - "Community 1354"
Cohesion: 0.5
Nodes (4): 3. Maximum Diversification (MaxDiversificationConfig), code:python (from optimizer.optimization import MaxDiversificationConfig,), Configuration Fields, Usage

### Community 1355 - "Community 1355"
Cohesion: 0.5
Nodes (3): 6. Nested Clusters Optimization -- NCO (NCOConfig), Configuration Fields, Usage

### Community 1356 - "Community 1356"
Cohesion: 0.5
Nodes (4): 7. Benchmark Tracker (BenchmarkTrackerConfig), code:python (from optimizer.optimization import BenchmarkTrackerConfig, b), Configuration Fields, Usage

### Community 1357 - "Community 1357"
Cohesion: 0.5
Nodes (4): 9. Inverse Volatility (InverseVolatilityConfig), code:python (from optimizer.optimization import InverseVolatilityConfig, ), Configuration Fields, Usage

### Community 1358 - "Community 1358"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 1 — Infrastructure & Global Portfolio Context, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1359 - "Community 1359"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1360 - "Community 1360"
Cohesion: 0.33
Nodes (5): base_url, entry_cmd, requirements_hash, scenarios, tiers

### Community 1361 - "Community 1361"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 2 — Research Pages: Ticker Seeding & API Wiring, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1362 - "Community 1362"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 3 — Analytics Pages: Global Context Migration, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1363 - "Community 1363"
Cohesion: 0.22
Nodes (5): Tests for ICIR_WEIGHTED clamping negative ICIR to zero (issue #253)., A group with negative ICIR should get zero weight., When all groups have negative ICIR, falls back to equal weight., Negative ICIR and zero ICIR both produce zero contribution., TestICIRWeightedNegativeICIR

### Community 1364 - "Community 1364"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1365 - "Community 1365"
Cohesion: 0.5
Nodes (4): **2.1 Stock Selection Approach**, **2.2 Investment Universe and Optimization**, **2.3 Analysis Period**, **2. Methodology — Quantitative Multi-Factor Model**

### Community 1366 - "Community 1366"
Cohesion: 0.5
Nodes (4): **6.1 Cost Structure**, **6.2 Impact on Net Return**, **6.3 Positions with Questionable Cost/Benefit Ratio**, **6. Management Cost Analysis**

### Community 1367 - "Community 1367"
Cohesion: 0.5
Nodes (4): **8.1 Priority Actions**, **8.2 Methodological Documentation**, **8.3 Extension of Geographic Diversification**, **8. Operational Recommendations**

### Community 1368 - "Community 1368"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1369 - "Community 1369"
Cohesion: 0.12
Nodes (16): title, type, properties, benchmarkReturn, totalActiveReturn, totalAllocation, totalInteraction, totalSelection (+8 more)

### Community 1370 - "Community 1370"
Cohesion: 0.29
Nodes (5): _hockey_stick_warn(), Cycle-3 §8 hockey-stick concentration check.      Splits *oos_returns* into ``n_, Cycle-3 §8 hockey-stick warn helper tests (issue #538)., _series_from_segments(), TestHockeyStickWarn

### Community 1371 - "Community 1371"
Cohesion: 0.21
Nodes (6): Validate price data and drop any tickers with missing data.      Args:         p, validate_prices(), validate_prices raises ValueError when every requested ticker is missing     fro, TestValidatePricesAllTickersAbsent, validate_prices raises ValueError with descriptive message on bad data., TestValidatePrices

### Community 1374 - "Community 1374"
Cohesion: 0.18
Nodes (8): BaseEstimator, OutlierTreater, Three-group outlier treatment transformer., Three-group outlier methodology on per-column z-scores.      During ``fit``, com, Compute per-column mean and std from training data., Apply three-group treatment based on z-scores., Return feature names (pass-through)., _validate_input()

### Community 1379 - "Community 1379"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1383 - "Community 1383"
Cohesion: 0.05
Nodes (29): get_rebalance_preview(), post_rebalance_decide(), FastAPI router for rebalancing decide and preview endpoints.  Routes:   POST /ap, Compute whether to rebalance given weights and a policy.      Fully stateless —, Produce a trade list from the latest snapshot and active policy.      Returns 40, Response body for POST /api/v1/rebalance/decide., A single trade recommendation in the preview response., Response body for GET /api/v1/rebalance/preview/{portfolio_name}.      Empty-sta (+21 more)

### Community 1385 - "Community 1385"
Cohesion: 0.36
Nodes (5): _import_fail_run(), _make_db_mock(), Branch coverage for _fail_run in app.api.v1.backtest.backtest.  Pure-unit: no HT, Return a database_manager mock whose get_session context manager works., TestFailRun

### Community 1387 - "Community 1387"
Cohesion: 0.12
Nodes (16): title, type, title, type, title, type, properties, actual (+8 more)

### Community 1390 - "Community 1390"
Cohesion: 0.03
Nodes (49): AgentConfig, AgentConfigExtended, AgentRole, AgentStatus, AgentStatusType, AIFundHolding, AIFundRiskStatus, AIFundSignal (+41 more)

### Community 1392 - "Community 1392"
Cohesion: 0.11
Nodes (18): description, title, type, estimatedCost, shouldRebalance, turnover, RebalanceDecideResponse, description (+10 more)

### Community 1395 - "Community 1395"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1396 - "Community 1396"
Cohesion: 0.12
Nodes (16): title, type, properties, title, type, title, type, title (+8 more)

### Community 1397 - "Community 1397"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1399 - "Community 1399"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1400 - "Community 1400"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1401 - "Community 1401"
Cohesion: 0.17
Nodes (12): BacktestRunListResponse, $defs, description, properties, required, title, type, description (+4 more)

### Community 1404 - "Community 1404"
Cohesion: 0.13
Nodes (14): 1. Frontend render-coverage: the two mega-components (`backtesting`, `macro-intelligence`), 2. Frontend render-coverage: remaining page components, 3. Frontend: shared components, 0%/partial services, and the HTTP interceptor, 4. `api/` (FastAPI) coverage to ≥80% on all four metrics, 5. `optimizer/` library coverage to ≥80% on all four metrics, 6. Raise every gate to 80/80/80/80 and hard-fail CI below, Constraints, Coverage Hardening — All Stacks to ≥80% on Every Metric (Statements / Branches / Functions / Lines) (+6 more)

### Community 1405 - "Community 1405"
Cohesion: 0.5
Nodes (3): Unit-test conftest: reset ``pipeline_builder`` module state per test.  The sessi, Clear ``_sessions`` / ``_job_services`` and reset the daemon flag., _reset_pipeline_builder_state()

### Community 1427 - "Community 1427"
Cohesion: 0.11
Nodes (12): ArrayCase, arrayCases, base, ObjectCase, objectCases, result, Row, untouched (+4 more)

### Community 1429 - "Community 1429"
Cohesion: 0.2
Nodes (8): Acceptance criteria, Cycle 4 — Final Pages & Cross-Cutting Contract Validation, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1430 - "Community 1430"
Cohesion: 0.18
Nodes (4): cast_ts(), Tests for rebalancing logic., TestComputeDriftedWeights, TestComputeTurnover

### Community 1431 - "Community 1431"
Cohesion: 0.27
Nodes (3): _combined_run(), Concatenate the `run:` field across every step in a job., TestSmokeWorkflowSteps

### Community 1432 - "Community 1432"
Cohesion: 0.12
Nodes (17): type, FactorCompositeScoreResponse, description, properties, required, title, type, additionalProperties (+9 more)

### Community 1447 - "Community 1447"
Cohesion: 0.33
Nodes (4): No warnings and correct shape when all indicators are fresh., Fresh indicators (within fill_limit) produce no UserWarning., All-empty inputs return an empty DataFrame without error., TestNoRegressionForFreshData

### Community 1450 - "Community 1450"
Cohesion: 0.06
Nodes (34): 10. [critical] coverage-gap, 1. [critical] coverage-gap, 1. [info] ambiguity, 1. [info] coverage-gap, 1. [warning] ambiguity, 1. [warning] coverage-gap, 2. [critical] coverage-gap, 2. [info] ambiguity (+26 more)

### Community 1451 - "Community 1451"
Cohesion: 0.18
Nodes (11): properties, items, title, type, nodes, totalPositions, totalSectors, title (+3 more)

### Community 1452 - "Community 1452"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1455 - "Community 1455"
Cohesion: 0.1
Nodes (14): description, title, type, method, daysBeforeIso(), ScorePanelComponent, todayIso(), daysBeforeIso() (+6 more)

### Community 1457 - "Community 1457"
Cohesion: 0.18
Nodes (11): DriftEntry, description, required, title, type, DriftResponse, $defs, description (+3 more)

### Community 1458 - "Community 1458"
Cohesion: 0.18
Nodes (11): KpiItem, description, required, title, type, PerformanceMetricsResponse, $defs, description (+3 more)

### Community 1459 - "Community 1459"
Cohesion: 0.4
Nodes (3): InstrumentDetailComponent, fixture, text

### Community 1462 - "Community 1462"
Cohesion: 0.4
Nodes (3): PortfolioDetailComponent, fixture, text

### Community 1463 - "Community 1463"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1464 - "Community 1464"
Cohesion: 0.01
Nodes (269): ABC, query_fundamentals(), query_sector_labels(), query_volume_history(), Shared database query helpers for Chapter 00 figure generators., Query sector labels from the database.      Parameters     ----------     db_url, Query daily volume history from the database.      Parameters     ----------, Query fundamental data needed for ``compute_all_factors()``.      Returns a Data (+261 more)

### Community 1465 - "Community 1465"
Cohesion: 0.32
Nodes (4): _build_service_with_fake_scraper(), TDD coverage for per-series on_progress in fetch_fred_series.  Asserts the servi, TestFetchFredSeriesAcceptsOnProgress, TestFetchFredSeriesEmitsPerSeriesProgress

### Community 1466 - "Community 1466"
Cohesion: 0.36
Nodes (3): _annualized_sharpe(), Annualized Sharpe of a daily-return slice; 0 when std is effectively 0., TestAnnualizedSharpe

### Community 1467 - "Community 1467"
Cohesion: 0.13
Nodes (9): _stale_iso(), TestIsArticleRecent, TestParsArticleDate, CountryNewsFetcher, _is_article_recent(), _parse_article_date(), Country-level news aggregation with deduplication and recency filtering.  Extrac, Fetches, deduplicates, and enriches financial news per country.      Parameters (+1 more)

### Community 1468 - "Community 1468"
Cohesion: 0.5
Nodes (4): _build_factor_scores(), main(), Cross-sectional factor-score preprocessing pipeline.  Pipes raw factor signals t, Use 21-day rolling Sharpe as a momentum-style raw factor.

### Community 1469 - "Community 1469"
Cohesion: 0.5
Nodes (3): `core/`, Dependency rule, Target structure

### Community 1470 - "Community 1470"
Cohesion: 0.39
Nodes (3): _actual_weights_from_positions(), Compute actual weights from broker positions by market value.      Returns None, TestActualWeightsFromPositions

### Community 1471 - "Community 1471"
Cohesion: 0.32
Nodes (4): get_regime_tilts(), Macro regime classification and factor group tilts.  This module provides the **, Get multiplicative tilts for a given regime.      Parameters     ----------, TestGetRegimeTilts

### Community 1472 - "Community 1472"
Cohesion: 0.2
Nodes (10): CreateSessionResponse, description, properties, required, title, type, sessionId, description (+2 more)

### Community 1473 - "Community 1473"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1474 - "Community 1474"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1475 - "Community 1475"
Cohesion: 0.29
Nodes (6): BaseHTTPMiddleware, get_security_headers(), Security middleware for adding security headers, Middleware to add security headers to all responses, Add security headers to all responses, SecurityHeadersMiddleware

### Community 1476 - "Community 1476"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1478 - "Community 1478"
Cohesion: 0.07
Nodes (24): for_linear_mapping(), build_factor_integration(), Build factor-to-optimizer integration objects.      Depending on ``config.use_bl, TestBuildFactorIntegration, BlackLittermanConfig, Immutable configuration for the Black-Litterman prior.      All parameters map 1, build_black_litterman(), Build a skfolio Black-Litterman prior from *config*.      Parameters     ------- (+16 more)

### Community 1479 - "Community 1479"
Cohesion: 0.39
Nodes (3): _extract_score_results(), Unpack compute_composite_score result into (scores, group_contributions).      A, TestExtractScoreResults

### Community 1482 - "Community 1482"
Cohesion: 0.25
Nodes (5): Tests for multi-indicator regime with unemployment (issue #79)., Rising unemployment + positive GDP → SLOWDOWN., Declining unemployment → original GDP-based classification., No unemployment_rate column → original behavior., TestUnemploymentRegimeOverride

### Community 1483 - "Community 1483"
Cohesion: 0.39
Nodes (3): _clamp_sentiment_score(), Clamp sentiment score to [-1.0, 1.0]., TestClampSentimentScore

### Community 1484 - "Community 1484"
Cohesion: 0.15
Nodes (13): 4. Orchestrator trio + sub-component subfolders (within every feature), 6. Dependency direction (must hold after restructure), Build Sequence (Checklist), code:block2 (factor-research/), code:block3 (<feature>.component  ──▶  <feature>.service     (its own log), Critical Implementation Details, Dependency Direction, Existing Backend Files to Modify (+5 more)

### Community 1488 - "Community 1488"
Cohesion: 0.39
Nodes (18): Appendix A — business logic to extract from components (current code), Appendix B — baseline (verified), Constraints, Coverage Hardening — All Stacks to ≥80% on Every Metric (Statements / Branches / Functions / Lines), Description, Frontend Restructure — Feature-Based Organization (Angular Style Guide), Full-stack frontend integration: portfolio-aware pages, correct API wiring, and chart rendering, Full-Stack Verification — Every Frontend Component and API Logic Path Works (+10 more)

### Community 1520 - "Community 1520"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 1 — Service Layer Foundation, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1523 - "Community 1523"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__construction_py, hash, index

### Community 1526 - "Community 1526"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 2 — Global Context Propagation, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1531 - "Community 1531"
Cohesion: 0.14
Nodes (14): TargetWeight, ticker, weight, description, properties, required, title, type (+6 more)

### Community 1532 - "Community 1532"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1533 - "Community 1533"
Cohesion: 0.25
Nodes (4): Issue #529: orchestrator must receive enabled regime config + macro_data., Issue #531: optimize_portfolio wires Cycle-2 selection + IC decay defaults., TestOptimizePortfolioRegimeWiring, TestSpecCompliantSelectionAndScoring

### Community 1534 - "Community 1534"
Cohesion: 0.25
Nodes (9): description, title, type, properties, properties, assets, summary, description (+1 more)

### Community 1535 - "Community 1535"
Cohesion: 0.25
Nodes (6): _build_regime_persistence(), Adapter satisfying ``RegimePersistenceProtocol`` via the repo.      Body copied, Adapter satisfying ``RegimePersistenceProtocol`` via the repo.      Body copied, Construct the persistence adapter with a lazy repo import.      The lazy import, Construct the persistence adapter with a lazy repo import.      The lazy import, _RegimeRepoPersistence

### Community 1538 - "Community 1538"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 3 — Analytics Pages Full Wiring, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1540 - "Community 1540"
Cohesion: 0.17
Nodes (12): _build_binding_constraints(), _persist_research_snapshot(), _print_diversification(), Step 8 — Performance reporting and research report rendering.  Extracted from ``, Render ``report.md`` from the run artefacts., Render ``report.md`` from the run artefacts., Compute binding region rows for the report.      Each row of ``A`` sums weights, Compute binding region rows for the report.      Each row of ``A`` sums weights (+4 more)

### Community 1541 - "Community 1541"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1542 - "Community 1542"
Cohesion: 0.44
Nodes (9): Tests for the branch-aware coverage gate (scripts/check_branch_coverage.py)., _run(), test_when_both_metrics_above_floor_then_exit_zero(), test_when_branch_rate_below_floor_then_exit_one(), test_when_exactly_at_floor_then_exit_zero(), test_when_line_rate_below_floor_then_exit_one(), test_when_no_args_then_usage_exit_two(), test_when_threshold_omitted_then_defaults_to_080() (+1 more)

### Community 1543 - "Community 1543"
Cohesion: 0.18
Nodes (11): FactorRow, FactorAttributionResponse, $defs, description, required, title, type, description (+3 more)

### Community 1546 - "Community 1546"
Cohesion: 0.15
Nodes (13): title, type, title, type, title, type, title, type (+5 more)

### Community 1547 - "Community 1547"
Cohesion: 0.17
Nodes (13): properties, description, items, title, type, description, items, title (+5 more)

### Community 1548 - "Community 1548"
Cohesion: 0.14
Nodes (14): $ref, properties, items, title, type, description, title, type (+6 more)

### Community 1551 - "Community 1551"
Cohesion: 0.15
Nodes (13): anyOf, default, title, anyOf, default, title, average_volume, free_cashflow (+5 more)

### Community 1556 - "Community 1556"
Cohesion: 0.48
Nodes (7): OptimizationRunResponse, OptimizationRunResponse, description, properties, required, title, type

### Community 1557 - "Community 1557"
Cohesion: 0.15
Nodes (13): properties, description, title, type, description, title, type, effectiveN (+5 more)

### Community 1559 - "Community 1559"
Cohesion: 0.22
Nodes (9): format, title, type, properties, created_at, updated_at, format, title (+1 more)

### Community 1561 - "Community 1561"
Cohesion: 0.33
Nodes (6): _map_t212_ticker_to_yfinance(), Service for syncing broker state from Trading 212 into the portfolio tables., Look up the yfinance_ticker for a T212 ticker via the instruments table., Sync positions and account state from Trading 212 into DB.      Args:         cl, Sync positions and account state from Trading 212 into DB.      Args:         cl, sync_portfolio()

### Community 1568 - "Community 1568"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 4 — Research Pages (Ticker Seeding & Wiring), Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1569 - "Community 1569"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 5 — Cross-cutting (Testing, UX Bugs, Error States), Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1658 - "Community 1658"
Cohesion: 0.13
Nodes (9): Empty-data and exception-path tests for report_service (issue #825).  Existing t, PdfBuilder.build with edge-case inputs., Invalid hex string must not raise — falls back to default., available=True but items=[] triggers 'No weights data.' paragraph., available=True with empty metrics dict → 'No performance data.' rendered., Sections not in _SECTION_TITLES use _render_generic without raising., collect_sections silently drops unknown section IDs., TestCollectSectionsEdgeCases (+1 more)

### Community 1660 - "Community 1660"
Cohesion: 0.17
Nodes (17): 17-Rule Checklist (from `portfolio_checklist.md`), (a) Where the stateful DataAssembly lives between step calls, Additional Notes, (b) Single vs multi concurrent builder sessions, (c) Step 7 granularity, code:block1 (src/app/), Confirmed: API orchestrates, `research/` is the implementation, Features (+9 more)

### Community 1661 - "Community 1661"
Cohesion: 0.22
Nodes (9): properties, items, $ref, title, items, total, description, title (+1 more)

### Community 1665 - "Community 1665"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1670 - "Community 1670"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1671 - "Community 1671"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1674 - "Community 1674"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1676 - "Community 1676"
Cohesion: 0.18
Nodes (11): RebalancingPolicyResponse, RebalancingPolicyListResponse, $defs, description, required, title, type, description (+3 more)

### Community 1678 - "Community 1678"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1688 - "Community 1688"
Cohesion: 0.22
Nodes (9): totalScreened, title, type, UniverseScreenResponse, description, properties, required, title (+1 more)

### Community 1689 - "Community 1689"
Cohesion: 0.18
Nodes (11): BrinsonResponse, $defs, description, required, title, type, description, required (+3 more)

### Community 1691 - "Community 1691"
Cohesion: 0.25
Nodes (5): Tests for macro regime classification and tilts., Verify classify_regime respects injected thresholds (#241)., PMI=53 is expansion at default (52) but neutral at threshold 54., HY OAS=380 is neutral at default (350) but risk-on at 400., TestRegimeThresholdConfigIntegration

### Community 1697 - "Community 1697"
Cohesion: 0.29
Nodes (7): title, type, title, type, description, name, properties

### Community 1712 - "Community 1712"
Cohesion: 0.43
Nodes (3): _build_service(), Lock per-series progress contract for fetch_fred_series (#569).  No DB. No netwo, TestFetchFredSeriesProgressContract

### Community 1714 - "Community 1714"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1715 - "Community 1715"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1717 - "Community 1717"
Cohesion: 0.4
Nodes (5): vg_config, bon_n, judge_enabled, mav_aspects, vg_tuning

### Community 1726 - "Community 1726"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1728 - "Community 1728"
Cohesion: 0.33
Nodes (7): _fetch_price_rows, _find_instrument ticker/yfinance_ticker resolver, _factor_helpers shared factor service helpers, factor_analysis_service selection + tilts, factor_compute_service DB compute persist, factor_scoring_service validation + composite, factor_service backward-compat re-export shim

### Community 1729 - "Community 1729"
Cohesion: 0.17
Nodes (8): Acceptance criteria, Cycle 1 — Template Branch Coverage, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1730 - "Community 1730"
Cohesion: 0.17
Nodes (8): Acceptance criteria, Cycle 2 — Service Error Path Coverage, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1731 - "Community 1731"
Cohesion: 0.17
Nodes (8): Acceptance criteria, Cycle 3 — Functions and Statement Coverage Polish, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1732 - "Community 1732"
Cohesion: 0.22
Nodes (7): `_validate_checklist` consumes the module-level `_REGION_MAP`., `_validate_checklist` consumes the module-level `_REGION_MAP`., `optimize_portfolio` must wire WalkForwardConfig(train=756, test=63)., `_validate_checklist` consumes the module-level `_REGION_MAP`., `optimize_portfolio` must wire WalkForwardConfig(train=756, test=63)., TestValidateChecklistReusesRegionMap, TestWalkForwardConfigSpec

### Community 1735 - "Community 1735"
Cohesion: 0.18
Nodes (4): Tests for optimization configs and enums., TestObjectiveFunctionType, TestRatioMeasureType, TestRiskMeasureType

### Community 1738 - "Community 1738"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 1 — Global portfolio context and ticker universe seeding, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1739 - "Community 1739"
Cohesion: 0.36
Nodes (3): TestComputeIcir, compute_icir(), Compute the IC Information Ratio (mean IC / std IC).      ICIR penalises factors

### Community 1740 - "Community 1740"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 2 — Dashboard, Risk-center, and Attribution page integration, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1741 - "Community 1741"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 3 — Rebalancing, Portfolio-builder, and Settings page integration, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1742 - "Community 1742"
Cohesion: 0.21
Nodes (6): App, LoggingMiddleware, Request logging middleware, Middleware to log all requests and responses for monitoring and debugging, _asgi_app(), TestLoggingMiddleware

### Community 1743 - "Community 1743"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 4 — Optimization-studio, Backtesting, and Factor-research page integration, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1744 - "Community 1744"
Cohesion: 0.33
Nodes (7): BrinsonDecomposition value object, compute_brinson_attribution, compute_brinson_attribution, compute_factor_attribution, run_brinson_attribution DB wrapper, attribution_service, test_attribution_service

### Community 1746 - "Community 1746"
Cohesion: 0.22
Nodes (8): Acceptance criteria, Cycle 5 — API contract validation and Playwright-identified UX bug fixes, Following cycles, In scope, Objective, Out of scope, Preceding cycles, Project vision

### Community 1747 - "Community 1747"
Cohesion: 0.2
Nodes (10): description, title, type, BufferZone, FactorSelectResponse, $defs, description, required (+2 more)

### Community 1748 - "Community 1748"
Cohesion: 0.29
Nodes (4): _EmpiricalOmegaBlackLitterman, Factory functions for building skfolio view integration priors., BlackLitterman variant using a pre-computed empirical omega matrix.      Extends, Fit prior then recompute posterior with empirical omega.

### Community 1749 - "Community 1749"
Cohesion: 0.18
Nodes (11): type, riskContributions, weights, additionalProperties, description, title, type, additionalProperties (+3 more)

### Community 1750 - "Community 1750"
Cohesion: 0.18
Nodes (11): description, items, $ref, title, properties, items, total, description (+3 more)

### Community 1751 - "Community 1751"
Cohesion: 0.18
Nodes (11): ConcentrationResponse, $defs, description, required, title, type, description, required (+3 more)

### Community 1752 - "Community 1752"
Cohesion: 0.33
Nodes (4): pad(), timestamp(), downgrade(), remove users table  Revision ID: bdd615f586f8 Revises: ff232ce0534f Create Date:

### Community 1753 - "Community 1753"
Cohesion: 0.33
Nodes (4): _missing_table_row(), Repository for database administration operations.  Encapsulates health checks,, Placeholder row for a table that is allowlisted but absent from the DB., TestMissingTableRow

### Community 1754 - "Community 1754"
Cohesion: 0.18
Nodes (11): RiskLimitResponse, RiskLimitListResponse, $defs, description, required, title, type, description (+3 more)

### Community 1755 - "Community 1755"
Cohesion: 0.25
Nodes (8): title, type, nScenarios, StressScenarioResponse, properties, required, title, type

### Community 1756 - "Community 1756"
Cohesion: 0.54
Nodes (7): _build_client(), _patch_yf_screen(), Tests for issue #592: branch ScreenerClient.screen on query type.  yfinance 1.3., test_when_query_is_equity_query_instance_then_yf_screen_receives_size_kwarg(), test_when_query_is_etf_query_instance_then_yf_screen_receives_size_kwarg(), test_when_query_is_fund_query_instance_then_yf_screen_receives_size_kwarg(), test_when_query_is_predefined_string_then_yf_screen_receives_count_kwarg()

### Community 1757 - "Community 1757"
Cohesion: 0.33
Nodes (5): pipeline-stepper, Reverse edge (do not widen), Role, Sanctioned consumer, Structure

### Community 1758 - "Community 1758"
Cohesion: 0.18
Nodes (11): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+3 more)

### Community 1759 - "Community 1759"
Cohesion: 0.07
Nodes (12): _build_configs(), Fig01HysteresisTurnover, _query_fundamentals_and_volume(), Fig01HysteresisTurnover — Hysteresis reduces universe turnover line chart., Line chart comparing monthly universe turnover under three hysteresis regimes., Build three screening configs: no hysteresis, moderate, wide (default).      Ret, Generate a synthetic illustration when DB data is unavailable., Query fundamentals snapshot and volume history from the database.      Parameter (+4 more)

### Community 1760 - "Community 1760"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1761 - "Community 1761"
Cohesion: 0.4
Nodes (4): flush(), flushPortfolioList(), flushInitialLoad(), loadWithHealth()

### Community 1762 - "Community 1762"
Cohesion: 0.2
Nodes (10): title, type, properties, title, type, explainedReturn, portfolioReturn, residual (+2 more)

### Community 1763 - "Community 1763"
Cohesion: 0.25
Nodes (11): BacktestRunResponse, description, properties, required, title, type, BacktestRunResponse, description (+3 more)

### Community 1764 - "Community 1764"
Cohesion: 0.14
Nodes (14): description, title, type, CorrelationResponse, description, properties, required, title (+6 more)

### Community 1765 - "Community 1765"
Cohesion: 0.07
Nodes (40): make_progress closure factory, baml_client b LLM functions, baml_client MacroRegimeCalibration, optimizer BlackLittermanConfig, date_parsing.parse_reference_date utility, EconomicIndicator model, YFinanceClient, compute_regime_tilt (+32 more)

### Community 1766 - "Community 1766"
Cohesion: 0.2
Nodes (10): LiquiditySummary, description, properties, required, title, type, weightedAvgDaysToLiquidate, description (+2 more)

### Community 1767 - "Community 1767"
Cohesion: 0.22
Nodes (9): InstrumentResponse, InstrumentListResponse, $defs, required, title, type, required, title (+1 more)

### Community 1768 - "Community 1768"
Cohesion: 0.2
Nodes (10): required, title, type, AssetViewResponse, GenerateViewsResponse, $defs, description, required (+2 more)

### Community 1769 - "Community 1769"
Cohesion: 0.2
Nodes (10): items, title, type, $ref, experts, views, description, items (+2 more)

### Community 1771 - "Community 1771"
Cohesion: 0.22
Nodes (4): AssetView(), AssetViewAst, AssetViewProperties, AssetViewViewer

### Community 1772 - "Community 1772"
Cohesion: 0.25
Nodes (5): Regression for issue #290: asset_growth must be currency-invariant.      asset_g, ASSET_GROWTH factor is raw fundamentals['asset_growth'] (no sign flip)., Direct proof: (k*a1 - k*a0) / abs(k*a0) == (a1-a0) / abs(a0)., asset_growth computed from scaled total_assets is identical., TestAssetGrowthCurrencyInvariance

### Community 1773 - "Community 1773"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1774 - "Community 1774"
Cohesion: 0.4
Nodes (5): vg_config, bon_n, judge_enabled, mav_aspects, vg_tuning

### Community 1775 - "Community 1775"
Cohesion: 0.25
Nodes (4): Query Trading Economics indicators with optional country filter., Query bond yields with optional country filter., Get all three data types for a single country.          Returns:             Dic, Query economic indicators with optional country filter.

### Community 1776 - "Community 1776"
Cohesion: 0.04
Nodes (70): AssetFactorData, AssetView, CountryNewsSummary, CovRegimeSelection, DeltaCalibration, FactorWeightAdaptation, MacroRegimeCalibration, NewsArticle (+62 more)

### Community 1777 - "Community 1777"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1778 - "Community 1778"
Cohesion: 0.22
Nodes (9): items, title, type, $ref, factors, sectors, items, title (+1 more)

### Community 1779 - "Community 1779"
Cohesion: 0.33
Nodes (6): OptimizationRunListResponse, $defs, description, required, title, type

### Community 1780 - "Community 1780"
Cohesion: 0.5
Nodes (4): TickerProfileResponse, required, title, type

### Community 1781 - "Community 1781"
Cohesion: 0.5
Nodes (4): description, title, type, optimizerType

### Community 1784 - "Community 1784"
Cohesion: 0.67
Nodes (3): z_e34f4f2b6a66fabd___init___py, hash, index

### Community 1785 - "Community 1785"
Cohesion: 0.33
Nodes (4): Tests for group_weights parameter (issue #54)., compute_equal_weight_composite uses group_weights when provided., compute_composite_score passes group_weights through., TestGroupWeightsOverride

### Community 1786 - "Community 1786"
Cohesion: 0.33
Nodes (3): for_scenario_generation(), for_stress_test(), Configuration for synthetic data generation and vine copula models.

### Community 1787 - "Community 1787"
Cohesion: 0.33
Nodes (4): Issue #546: report_performance returns (pass_count, rules)., Issue #546: report_performance returns (pass_count, rules)., Issue #546: report_performance returns (pass_count, rules)., TestReportPerformanceReturnContract

### Community 1789 - "Community 1789"
Cohesion: 0.1
Nodes (11): _decide_rebalance(), Cycle-3 §11 hybrid rebalance decision.      Returns ``(False, "cold_start")`` wh, _decide_rebalance propagates a (False, reason) pair from     should_rebalance_hy, Ensure (False, 'not_review_date') is propagated unchanged., TestDecideRebalanceFalseBranch, Cycle-3 §11 hybrid rebalance wiring tests (issue #539)., `_decide_rebalance` returns the hybrid (decision, reason) pair., `main` derives decision and attaches it to the result object. (+3 more)

### Community 1792 - "Community 1792"
Cohesion: 0.4
Nodes (4): _fetch_prices_df(), Return a prices DataFrame indexed by date for the requested tickers., _fetch_prices_df must delegate to fetch_close_prices unchanged., TestFetchPricesDfDelegates

### Community 1794 - "Community 1794"
Cohesion: 0.43
Nodes (3): create_error_response(), Create a standardized error response, TestCreateErrorResponse

### Community 1795 - "Community 1795"
Cohesion: 0.4
Nodes (5): vg_config, bon_n, judge_enabled, mav_aspects, vg_tuning

### Community 1796 - "Community 1796"
Cohesion: 0.25
Nodes (5): Cover invalid-group skip, default-config, and zero-total-weight arms., A tilt referencing an unknown group name is silently skipped., With no config, the default (disabled) leaves weights unchanged., All-zero weights skip the floor and re-normalization steps., TestRegimeTiltBranchCoverage

### Community 1799 - "Community 1799"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1800 - "Community 1800"
Cohesion: 0.4
Nodes (5): vg_config, bon_n, judge_enabled, mav_aspects, vg_tuning

### Community 1802 - "Community 1802"
Cohesion: 0.2
Nodes (9): archived_at, completed_cycles, git_branch, git_commit, mode, provider_model, requirements_hash, slug (+1 more)

### Community 1803 - "Community 1803"
Cohesion: 0.05
Nodes (57): Seed instruments + ticker_profiles + price_history for ENGI.PA / ORA.PA / AAPL., seeded_trading212_like(), _make_factor_score(), Integration tests for risk analytics endpoints (issues #423, #424).  Exercises t, GET /portfolio/{name}/risk/var — regression for #423., Guard clause: when no ticker has data, 400 must still fire., GET /portfolio/{name}/risk/correlation — regression for #423., Seed two portfolios for issue #424 coverage.      - ``...-factors``: snapshot wi (+49 more)

### Community 1804 - "Community 1804"
Cohesion: 0.2
Nodes (10): cache_read, cache_write, cache_write_1h, cache_write_5m, clear_events, compaction_events, input, num_turns (+2 more)

### Community 1805 - "Community 1805"
Cohesion: 0.27
Nodes (6): Tests for assemble_prices using a mocked SQLAlchemy session., Build a mock session whose .execute() returns controlled results.          Call, When include_delisted=False, the delisting rows query is never made., When include_delisted=True, a third query fetches delisting rows., The delisting synthetic row appears in the returned DataFrame., TestAssemblePricesDelisting

### Community 1806 - "Community 1806"
Cohesion: 0.47
Nodes (3): White-box repo tests with a stubbed Session.      SQLite cannot run ``pg_total_r, Return a MagicMock ``Session`` whose ``execute`` yields *scalars*., TestGetTableInfoRepo

### Community 1807 - "Community 1807"
Cohesion: 0.48
Nodes (7): JobSummary, JobSummary, description, properties, required, title, type

### Community 1808 - "Community 1808"
Cohesion: 0.4
Nodes (5): updatedAt, description, format, title, type

### Community 1809 - "Community 1809"
Cohesion: 0.4
Nodes (3): _marchenko_pastur_pdf(), Fig34MarchenkoPastur — empirical eigenvalue histogram with MP PDF overlay., Marchenko-Pastur probability density function.      Parameters     ----------

### Community 1810 - "Community 1810"
Cohesion: 0.4
Nodes (5): BacktestProgressResponse, description, required, title, type

### Community 1811 - "Community 1811"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, icStd

### Community 1812 - "Community 1812"
Cohesion: 0.5
Nodes (4): description, title, type, id

### Community 1813 - "Community 1813"
Cohesion: 0.4
Nodes (5): score_date, description, format, title, type

### Community 1814 - "Community 1814"
Cohesion: 0.4
Nodes (5): total, default, description, title, type

### Community 1815 - "Community 1815"
Cohesion: 0.29
Nodes (4): app_with_handlers(), Unit tests for app-level exception handlers (issue #712)., Minimal FastAPI app with exception handlers wired up., TestFactorCoverageHandler

### Community 1816 - "Community 1816"
Cohesion: 0.06
Nodes (39): create_portfolio(), create_snapshot(), get_account(), get_drift(), get_latest_snapshot(), get_portfolio(), get_portfolio_repository(), get_positions() (+31 more)

### Community 1818 - "Community 1818"
Cohesion: 0.4
Nodes (5): scoreDate, description, format, title, type

### Community 1819 - "Community 1819"
Cohesion: 0.4
Nodes (5): updatedAt, description, format, title, type

### Community 1820 - "Community 1820"
Cohesion: 0.25
Nodes (4): Issue #544: write_metrics_json writer., Issue #544: write_metrics_json writer., Issue #544: write_metrics_json writer., TestWriteMetricsJson

### Community 1821 - "Community 1821"
Cohesion: 0.04
Nodes (49): AsyncJobCreateResponse, AsyncJobProgress, BacktestJobResponse, BacktestProgressResponse, BacktestRequest, BacktestRunListResponse, Returned when a backtest background job is created (POST /backtest)., Progress info polled via GET /backtest/{job_id}. (+41 more)

### Community 1822 - "Community 1822"
Cohesion: 0.29
Nodes (7): 13. Playwright-identified UX and wiring bugs, 13a. Backtest result persistence across navigation, 13b. Backtest KPI pre-run state, 13c. Attribution factor 404 — meaningful empty state, 13d. Backtesting Metrics tab — benchmark comparison empty, 13e. Walk-forward section exposes implementation detail, 13f. Attribution page shows "(none)" for portfolio name in form hint

### Community 1823 - "Community 1823"
Cohesion: 0.33
Nodes (4): Adapter satisfying RegimePersistenceProtocol via MacroRegimeRepository., Adapter satisfying RegimePersistenceProtocol via MacroRegimeRepository., Adapter satisfying RegimePersistenceProtocol via MacroRegimeRepository., _RegimeRepoPersistence

### Community 1824 - "Community 1824"
Cohesion: 0.33
Nodes (6): description, items, title, type, type, errors

### Community 1825 - "Community 1825"
Cohesion: 0.33
Nodes (6): total, default, description, minimum, title, type

### Community 1826 - "Community 1826"
Cohesion: 0.33
Nodes (6): JobListResponse, $defs, description, required, title, type

### Community 1827 - "Community 1827"
Cohesion: 0.4
Nodes (5): additionalProperties, description, title, type, blConfig

### Community 1828 - "Community 1828"
Cohesion: 0.33
Nodes (6): type, shocks, additionalProperties, description, title, type

### Community 1829 - "Community 1829"
Cohesion: 0.47
Nodes (6): StressScenarioItem, StressScenarioItem, required, title, type, $defs

### Community 1830 - "Community 1830"
Cohesion: 0.2
Nodes (10): z_0a5791348b549bcf___init___py, z_ab635e159af180d4__config_py, z_c7f45a9d5e5efe7e__decomposition_py, description, hash, index, hash, index (+2 more)

### Community 1831 - "Community 1831"
Cohesion: 0.4
Nodes (5): status, default, description, title, type

### Community 1832 - "Community 1832"
Cohesion: 0.4
Nodes (5): description, items, title, type, mu

### Community 1833 - "Community 1833"
Cohesion: 0.4
Nodes (6): additionalProperties, type, additionalProperties, title, type, diagnostics

### Community 1834 - "Community 1834"
Cohesion: 0.5
Nodes (3): PieChartComponent, arcs, segs

### Community 1835 - "Community 1835"
Cohesion: 0.5
Nodes (4): status, description, title, type

### Community 1836 - "Community 1836"
Cohesion: 0.5
Nodes (4): description, title, type, factorGroup

### Community 1837 - "Community 1837"
Cohesion: 0.33
Nodes (6): type, universeTickers, description, items, title, type

### Community 1838 - "Community 1838"
Cohesion: 0.33
Nodes (6): type, additionalProperties, description, title, type, idzorekAlphas

### Community 1840 - "Community 1840"
Cohesion: 0.5
Nodes (4): description, title, type, delta

### Community 1843 - "Community 1843"
Cohesion: 0.5
Nodes (4): description, title, type, macroSummary

### Community 1845 - "Community 1845"
Cohesion: 0.4
Nodes (4): No prints inside `_validate_checklist` (caller owns rendering)., No prints inside `_validate_checklist` (caller owns rendering)., No prints inside `_validate_checklist` (caller owns rendering)., TestValidateChecklistNoSideEffects

### Community 1846 - "Community 1846"
Cohesion: 0.13
Nodes (9): compute_equity_curve(), Compute dual-line equity curve (portfolio vs benchmark) rebased to 100.      Arg, compute_equity_curve raises ValueError when overlapping date index is too short., TestComputeEquityCurveExceptionPaths, prices_df(), Unit tests for compute_equity_curve — pure computation, no DB., Price DataFrame with 3 portfolio tickers + benchmark, 756 trading days., Fewer than 2 common dates after alignment. (+1 more)

### Community 1847 - "Community 1847"
Cohesion: 0.5
Nodes (4): description, title, type, phase

### Community 1848 - "Community 1848"
Cohesion: 0.4
Nodes (5): additionalProperties, description, title, type, config

### Community 1849 - "Community 1849"
Cohesion: 0.4
Nodes (5): additionalProperties, description, title, type, config

### Community 1850 - "Community 1850"
Cohesion: 0.4
Nodes (5): description, format, title, type, createdAt

### Community 1851 - "Community 1851"
Cohesion: 0.29
Nodes (4): Issue #544: _downside_vol helper., Issue #544: _downside_vol helper., Issue #544: _downside_vol helper., TestDownsideVolHelper

### Community 1852 - "Community 1852"
Cohesion: 0.4
Nodes (5): description, format, title, type, createdAt

### Community 1853 - "Community 1853"
Cohesion: 0.4
Nodes (5): description, format, title, type, createdAt

### Community 1854 - "Community 1854"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, jobId

### Community 1855 - "Community 1855"
Cohesion: 0.4
Nodes (5): additionalProperties, description, title, type, metrics

### Community 1856 - "Community 1856"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, portfolioId

### Community 1857 - "Community 1857"
Cohesion: 0.4
Nodes (5): FactorValidationReportResponse, description, required, title, type

### Community 1858 - "Community 1858"
Cohesion: 0.06
Nodes (24): dashboardRoute, routes, dashboardRoute, dashboardRoutes, entry, hasWildcard, redirectsToRoot, dashboard (+16 more)

### Community 1859 - "Community 1859"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, cvFoldMetrics

### Community 1860 - "Community 1860"
Cohesion: 0.4
Nodes (5): description, format, title, type, createdAt

### Community 1862 - "Community 1862"
Cohesion: 0.5
Nodes (4): tau, description, title, type

### Community 1863 - "Community 1863"
Cohesion: 0.29
Nodes (8): build_universe endpoint, get_build_status endpoint, universe_build BackgroundJobService, Trading212 universe router, _run_build background worker, universe routes __init__, screen_universe endpoint, universe screen router

### Community 1864 - "Community 1864"
Cohesion: 0.4
Nodes (5): additionalProperties, description, title, type, drawdowns

### Community 1865 - "Community 1865"
Cohesion: 0.18
Nodes (11): vg_config, bon_n, dars_branching, gvr_enabled, judge_enabled, mav_aspects, orps_scoring, rex_scheduler (+3 more)

### Community 1866 - "Community 1866"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, durationSeconds

### Community 1867 - "Community 1867"
Cohesion: 0.4
Nodes (5): additionalProperties, description, title, type, equityCurve

### Community 1868 - "Community 1868"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, errorMessage

### Community 1869 - "Community 1869"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, jobId

### Community 1870 - "Community 1870"
Cohesion: 0.4
Nodes (5): additionalProperties, description, title, type, monthlyReturns

### Community 1871 - "Community 1871"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, portfolioId

### Community 1872 - "Community 1872"
Cohesion: 0.4
Nodes (5): rollingMetrics, additionalProperties, description, title, type

### Community 1873 - "Community 1873"
Cohesion: 0.4
Nodes (5): summaryStats, additionalProperties, description, title, type

### Community 1874 - "Community 1874"
Cohesion: 0.4
Nodes (5): turnoverHistory, additionalProperties, description, title, type

### Community 1878 - "Community 1878"
Cohesion: 0.4
Nodes (5): tStat, anyOf, default, description, title

### Community 1879 - "Community 1879"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, durationSeconds

### Community 1880 - "Community 1880"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, icir

### Community 1881 - "Community 1881"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, efficientFrontier

### Community 1882 - "Community 1882"
Cohesion: 0.5
Nodes (4): status, description, title, type

### Community 1883 - "Community 1883"
Cohesion: 0.4
Nodes (5): updatedAt, description, format, title, type

### Community 1885 - "Community 1885"
Cohesion: 0.5
Nodes (4): anyOf, default, title, book_value

### Community 1886 - "Community 1886"
Cohesion: 0.5
Nodes (4): format, title, type, created_at

### Community 1887 - "Community 1887"
Cohesion: 0.5
Nodes (4): anyOf, default, title, currency

### Community 1888 - "Community 1888"
Cohesion: 0.5
Nodes (4): anyOf, default, title, current_price

### Community 1889 - "Community 1889"
Cohesion: 0.5
Nodes (4): anyOf, default, title, current_ratio

### Community 1890 - "Community 1890"
Cohesion: 0.5
Nodes (4): anyOf, default, title, debt_to_equity

### Community 1891 - "Community 1891"
Cohesion: 0.5
Nodes (4): anyOf, default, title, dividend_rate

### Community 1892 - "Community 1892"
Cohesion: 0.5
Nodes (4): anyOf, default, title, dividend_yield

### Community 1893 - "Community 1893"
Cohesion: 0.33
Nodes (6): anyOf, default, description, title, type, policyType

### Community 1894 - "Community 1894"
Cohesion: 0.5
Nodes (4): anyOf, default, title, ebitda

### Community 1895 - "Community 1895"
Cohesion: 0.5
Nodes (4): anyOf, default, title, enterprise_to_ebitda

### Community 1896 - "Community 1896"
Cohesion: 0.5
Nodes (4): anyOf, default, title, enterprise_to_revenue

### Community 1897 - "Community 1897"
Cohesion: 0.5
Nodes (4): anyOf, default, title, enterprise_value

### Community 1898 - "Community 1898"
Cohesion: 0.5
Nodes (4): anyOf, default, title, exchange

### Community 1899 - "Community 1899"
Cohesion: 0.5
Nodes (4): anyOf, default, title, fifty_day_average

### Community 1900 - "Community 1900"
Cohesion: 0.5
Nodes (4): anyOf, default, title, fifty_two_week_high

### Community 1901 - "Community 1901"
Cohesion: 0.5
Nodes (4): anyOf, default, title, fifty_two_week_low

### Community 1902 - "Community 1902"
Cohesion: 0.5
Nodes (4): anyOf, default, title, float_shares

### Community 1903 - "Community 1903"
Cohesion: 0.5
Nodes (4): anyOf, default, title, forward_eps

### Community 1904 - "Community 1904"
Cohesion: 0.5
Nodes (4): anyOf, default, title, forward_pe

### Community 1905 - "Community 1905"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, compositeScore

### Community 1906 - "Community 1906"
Cohesion: 0.5
Nodes (4): anyOf, default, title, full_time_employees

### Community 1907 - "Community 1907"
Cohesion: 0.5
Nodes (4): anyOf, default, title, gross_margins

### Community 1908 - "Community 1908"
Cohesion: 0.5
Nodes (4): anyOf, default, title, industry

### Community 1909 - "Community 1909"
Cohesion: 0.5
Nodes (4): anyOf, default, title, isin

### Community 1910 - "Community 1910"
Cohesion: 0.5
Nodes (4): anyOf, default, title, long_business_summary

### Community 1911 - "Community 1911"
Cohesion: 0.5
Nodes (4): anyOf, default, title, long_name

### Community 1912 - "Community 1912"
Cohesion: 0.5
Nodes (4): anyOf, default, title, market_cap

### Community 1914 - "Community 1914"
Cohesion: 0.5
Nodes (4): anyOf, default, title, operating_cashflow

### Community 1915 - "Community 1915"
Cohesion: 0.5
Nodes (4): anyOf, default, title, operating_margins

### Community 1916 - "Community 1916"
Cohesion: 0.5
Nodes (4): anyOf, default, title, payout_ratio

### Community 1917 - "Community 1917"
Cohesion: 0.5
Nodes (4): anyOf, default, title, peg_ratio

### Community 1918 - "Community 1918"
Cohesion: 0.5
Nodes (4): anyOf, default, title, previous_close

### Community 1919 - "Community 1919"
Cohesion: 0.5
Nodes (4): anyOf, default, title, price_to_book

### Community 1920 - "Community 1920"
Cohesion: 0.5
Nodes (4): anyOf, default, title, price_to_sales_trailing_12months

### Community 1921 - "Community 1921"
Cohesion: 0.5
Nodes (4): anyOf, default, title, profit_margins

### Community 1922 - "Community 1922"
Cohesion: 0.5
Nodes (4): quote_type, anyOf, default, title

### Community 1923 - "Community 1923"
Cohesion: 0.4
Nodes (5): vif, anyOf, default, description, title

### Community 1924 - "Community 1924"
Cohesion: 0.5
Nodes (4): recommendation_mean, anyOf, default, title

### Community 1925 - "Community 1925"
Cohesion: 0.5
Nodes (4): return_on_assets, anyOf, default, title

### Community 1926 - "Community 1926"
Cohesion: 0.5
Nodes (4): revenue_growth, anyOf, default, title

### Community 1927 - "Community 1927"
Cohesion: 0.5
Nodes (4): sector, anyOf, default, title

### Community 1928 - "Community 1928"
Cohesion: 0.5
Nodes (4): shares_outstanding, anyOf, default, title

### Community 1929 - "Community 1929"
Cohesion: 0.5
Nodes (4): short_name, anyOf, default, title

### Community 1930 - "Community 1930"
Cohesion: 0.5
Nodes (4): symbol, anyOf, default, title

### Community 1931 - "Community 1931"
Cohesion: 0.5
Nodes (4): total_debt, anyOf, default, title

### Community 1932 - "Community 1932"
Cohesion: 0.5
Nodes (4): total_revenue, anyOf, default, title

### Community 1933 - "Community 1933"
Cohesion: 0.4
Nodes (5): yearlyReturns, additionalProperties, description, title, type

### Community 1934 - "Community 1934"
Cohesion: 0.5
Nodes (4): trailing_pe, anyOf, default, title

### Community 1935 - "Community 1935"
Cohesion: 0.5
Nodes (4): two_hundred_day_average, anyOf, default, title

### Community 1936 - "Community 1936"
Cohesion: 0.4
Nodes (5): default, description, title, type, current

### Community 1937 - "Community 1937"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, details

### Community 1939 - "Community 1939"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, duration_seconds

### Community 1944 - "Community 1944"
Cohesion: 0.22
Nodes (9): phase8, attempt, ci_run_id, ci_status, finished_at, repair_attempts, started_at, status (+1 more)

### Community 1945 - "Community 1945"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, errorMessage

### Community 1947 - "Community 1947"
Cohesion: 0.4
Nodes (5): solverLog, anyOf, default, description, title

### Community 1948 - "Community 1948"
Cohesion: 0.4
Nodes (5): updatedAt, description, format, title, type

### Community 1949 - "Community 1949"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, lastCheckedAt

### Community 1950 - "Community 1950"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1951 - "Community 1951"
Cohesion: 0.4
Nodes (5): description, format, title, type, createdAt

### Community 1954 - "Community 1954"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1955 - "Community 1955"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 1956 - "Community 1956"
Cohesion: 0.4
Nodes (5): vg_config, bon_n, judge_enabled, mav_aspects, vg_tuning

### Community 1958 - "Community 1958"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, error

### Community 1959 - "Community 1959"
Cohesion: 0.4
Nodes (5): default, description, title, type, errors_count

### Community 1961 - "Community 1961"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, icMean

### Community 1962 - "Community 1962"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, finished_at

### Community 1963 - "Community 1963"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1964 - "Community 1964"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1972 - "Community 1972"
Cohesion: 0.4
Nodes (5): started_at, anyOf, default, description, title

### Community 1973 - "Community 1973"
Cohesion: 0.4
Nodes (5): pValue, anyOf, default, description, title

### Community 1974 - "Community 1974"
Cohesion: 0.5
Nodes (3): Factory functions for building synthetic data and vine copula estimators., Resolve a tuple of distribution names to fresh estimator instances., _resolve_distributions()

### Community 1979 - "Community 1979"
Cohesion: 0.5
Nodes (4): description, title, type, id

### Community 1980 - "Community 1980"
Cohesion: 0.4
Nodes (5): $ref, scenarios, items, title, type

### Community 1981 - "Community 1981"
Cohesion: 0.4
Nodes (3): When a news row has a naive publish_time, it is made timezone-aware., Naive datetime should be assigned UTC timezone., TestFetchNewsSentimentNaiveDatetime

### Community 1982 - "Community 1982"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1983 - "Community 1983"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1986 - "Community 1986"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__integration_py, hash, index

### Community 1987 - "Community 1987"
Cohesion: 0.4
Nodes (5): type, tickers, items, title, type

### Community 1988 - "Community 1988"
Cohesion: 0.4
Nodes (5): syntheticDataArgs, additionalProperties, description, title, type

### Community 1989 - "Community 1989"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, currency_code

### Community 1990 - "Community 1990"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1991 - "Community 1991"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__diagnostics_py, hash, index

### Community 1992 - "Community 1992"
Cohesion: 0.2
Nodes (10): z_0a55ae25571ad925_exceptions_py, z_0a5791348b549bcf__config_py, z_0a5791348b549bcf__factory_py, url, hash, index, hash, index (+2 more)

### Community 1994 - "Community 1994"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__mimicking_py, hash, index

### Community 1995 - "Community 1995"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__ml_scoring_py, hash, index

### Community 1996 - "Community 1996"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__regime_py, hash, index

### Community 1997 - "Community 1997"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 1998 - "Community 1998"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__sector_bands_py, hash, index

### Community 1999 - "Community 1999"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__selection_py, hash, index

### Community 2000 - "Community 2000"
Cohesion: 0.29
Nodes (6): Acceptance criteria, Agent and skills, Context, Dependencies, Goal, Implementation notes

### Community 2001 - "Community 2001"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, exchange_name

### Community 2002 - "Community 2002"
Cohesion: 0.67
Nodes (3): z_a2fdbdbb707dd321__factory_py, hash, index

### Community 2003 - "Community 2003"
Cohesion: 0.67
Nodes (3): z_a2fdbdbb707dd321___init___py, hash, index

### Community 2004 - "Community 2004"
Cohesion: 0.67
Nodes (3): z_ab635e159af180d4__factory_py, hash, index

### Community 2005 - "Community 2005"
Cohesion: 0.67
Nodes (3): z_ab635e159af180d4___init___py, hash, index

### Community 2006 - "Community 2006"
Cohesion: 0.67
Nodes (3): z_c7f45a9d5e5efe7e__converter_py, hash, index

### Community 2007 - "Community 2007"
Cohesion: 0.67
Nodes (3): z_c7f45a9d5e5efe7e__factory_py, hash, index

### Community 2008 - "Community 2008"
Cohesion: 0.67
Nodes (3): z_c7f45a9d5e5efe7e___init___py, hash, index

### Community 2009 - "Community 2009"
Cohesion: 0.67
Nodes (3): main(), _portfolio_vol(), RegimeAdjustedEWCovariance STVU multiplier impact during a vol shock.  Fits ``EW

### Community 2010 - "Community 2010"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, instrument_type

### Community 2012 - "Community 2012"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, isin

### Community 2013 - "Community 2013"
Cohesion: 0.4
Nodes (5): type, items, title, type, passingTickers

### Community 2014 - "Community 2014"
Cohesion: 0.4
Nodes (5): anyOf, default, description, title, name

### Community 2015 - "Community 2015"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__standardization_py, hash, index

### Community 2016 - "Community 2016"
Cohesion: 0.4
Nodes (5): yfinance_ticker, anyOf, default, description, title

### Community 2018 - "Community 2018"
Cohesion: 0.4
Nodes (5): description, items, title, type, icWeights

### Community 2022 - "Community 2022"
Cohesion: 0.67
Nodes (3): z_c7f45a9d5e5efe7e__rates_py, hash, index

### Community 2025 - "Community 2025"
Cohesion: 0.5
Nodes (4): anyOf, default, title, beta

### Community 2028 - "Community 2028"
Cohesion: 0.5
Nodes (4): anyOf, default, title, earnings_growth

### Community 2029 - "Community 2029"
Cohesion: 0.5
Nodes (4): format, title, type, id

### Community 2030 - "Community 2030"
Cohesion: 0.5
Nodes (4): format, title, type, instrument_id

### Community 2033 - "Community 2033"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 2034 - "Community 2034"
Cohesion: 0.4
Nodes (5): vg_config, bon_n, judge_enabled, mav_aspects, vg_tuning

### Community 2035 - "Community 2035"
Cohesion: 0.4
Nodes (5): updatedAt, description, format, title, type

### Community 2036 - "Community 2036"
Cohesion: 0.67
Nodes (3): z_0a55ae25571ad925___init___py, hash, index

### Community 2039 - "Community 2039"
Cohesion: 0.5
Nodes (4): return_on_equity, anyOf, default, title

### Community 2042 - "Community 2042"
Cohesion: 0.5
Nodes (4): description, title, type, domain

### Community 2045 - "Community 2045"
Cohesion: 0.5
Nodes (4): description, title, type, id

### Community 2046 - "Community 2046"
Cohesion: 0.25
Nodes (8): z_47c76bca69ccc1a4__oos_validation_py, z_a2fdbdbb707dd321__config_py, file, hash, index, hash, index, index

### Community 2047 - "Community 2047"
Cohesion: 0.4
Nodes (5): repo, full, host, name, owner

### Community 2048 - "Community 2048"
Cohesion: 0.4
Nodes (5): vg_config, bon_n, judge_enabled, mav_aspects, vg_tuning

### Community 2049 - "Community 2049"
Cohesion: 0.5
Nodes (4): status, description, title, type

### Community 2050 - "Community 2050"
Cohesion: 0.5
Nodes (4): trailing_eps, anyOf, default, title

### Community 2051 - "Community 2051"
Cohesion: 0.5
Nodes (4): updated_at, format, title, type

### Community 2052 - "Community 2052"
Cohesion: 0.5
Nodes (4): website, anyOf, default, title

### Community 2054 - "Community 2054"
Cohesion: 0.5
Nodes (4): description, title, type, horizonDays

### Community 2055 - "Community 2055"
Cohesion: 0.5
Nodes (4): description, title, type, portfolioId

### Community 2056 - "Community 2056"
Cohesion: 0.5
Nodes (4): description, title, type, probability

### Community 2058 - "Community 2058"
Cohesion: 0.5
Nodes (4): short_name, description, title, type

### Community 2059 - "Community 2059"
Cohesion: 0.5
Nodes (4): ticker, description, title, type

### Community 2060 - "Community 2060"
Cohesion: 0.5
Nodes (3): build_fx_converter(), Factory function for building FX converter from config., Build a ready-to-use :class:`FxPriceConverter` from config.      Parameters

### Community 2061 - "Community 2061"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4___init___py, hash, index

### Community 2063 - "Community 2063"
Cohesion: 0.67
Nodes (3): title, type, allocationEffect

### Community 2064 - "Community 2064"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__validation_py, hash, index

### Community 2066 - "Community 2066"
Cohesion: 0.36
Nodes (4): _build_service(), Tests for FRED_API_KEY environment-aware messaging (issue #564)., fred_scraper property + fetch_fred_series surface a docker-aware diagnostic., TestFredKeyEnvironmentAwareMessage

### Community 2083 - "Community 2083"
Cohesion: 0.67
Nodes (3): z_47c76bca69ccc1a4__scoring_py, hash, index

### Community 2089 - "Community 2089"
Cohesion: 0.33
Nodes (5): Integration tests for POST /api/v1/attribution/brinson (issue #427).  Seeds a ``, Regression for #427: .PA tickers must resolve via yfinance_ticker., Guard: 422 must still fire when the coverage is genuinely low.      All three we, test_brinson_preserves_422_when_coverage_truly_low(), test_brinson_returns_200_with_european_yfinance_tickers()

## Ambiguous Edges - Review These
- `test_risk_analytics_routes` → `POST /api/v1/optimize route`  [AMBIGUOUS]
  api/tests/integration/test_risk_analytics_routes.py · relation: references

## Knowledge Gaps
- **12107 isolated node(s):** `Assemble optimizer-ready DataFrames from database ORM rows.  This module is the`, `Research module — factor history, optimization, strategies, and reporting.`, `Pure metric computation functions extracted from stock_selection_pipeline.py.  Z`, `Compound annualized return from daily returns.`, `Forward-filled daily risk-free rate aligned to ``returns`` index.` (+12102 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **582 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `test_risk_analytics_routes` and `POST /api/v1/optimize route`?**
  _Edge tagged AMBIGUOUS (relation: references) - confidence is low._
- **Why does `set` connect `API Views & Scenarios` to `Community 1024`, `Optimizer Validation & Reporting`, `Community 1027`, `Risk Analytics API Tests`, `Factor & Macro Models`, `BAML Type Builder`, `Optimizer Config Surface`, `Community 1038`, `Cluster 529`, `Cluster 19`, `Cluster 20`, `Cluster 21`, `Community 1561`, `Community 1050`, `Cluster 27`, `Cluster 30`, `Cluster 31`, `Community 1060`, `Cluster 41`, `Cluster 42`, `Cluster 46`, `Community 1072`, `Cluster 48`, `Cluster 49`, `Cluster 51`, `Cluster 61`, `Cluster 65`, `Cluster 66`, `Cluster 579`, `Cluster 82`, `Cluster 89`, `Cluster 92`, `Cluster 98`, `Cluster 102`, `Cluster 104`, `Cluster 105`, `Community 1132`, `Community 1133`, `Cluster 114`, `Cluster 116`, `Cluster 117`, `Community 1147`, `Cluster 125`, `Cluster 127`, `Cluster 128`, `Cluster 149`, `Cluster 151`, `Cluster 155`, `Cluster 156`, `Community 1185`, `Cluster 163`, `Cluster 174`, `Cluster 175`, `Cluster 179`, `Community 1205`, `Cluster 182`, `Cluster 183`, `Community 1214`, `Cluster 194`, `Cluster 199`, `Community 1735`, `Cluster 203`, `Cluster 208`, `Community 1239`, `Cluster 219`, `Community 1759`, `Cluster 231`, `Cluster 232`, `Community 1771`, `Cluster 238`, `Community 1776`, `Cluster 243`, `Cluster 247`, `Cluster 253`, `Community 1278`, `Community 1284`, `Community 1796`, `Community 1288`, `Community 1289`, `Community 1803`, `Cluster 273`, `Cluster 275`, `Community 1312`, `Community 1317`, `Cluster 298`, `Cluster 304`, `Cluster 307`, `Community 1334`, `Cluster 314`, `Community 1342`, `Community 1348`, `Cluster 334`, `Cluster 343`, `Cluster 351`, `Cluster 359`, `Community 1383`, `Community 1388`, `Cluster 371`, `Cluster 379`, `Cluster 392`, `Cluster 393`, `Cluster 400`, `Cluster 409`, `Community 1946`, `Cluster 427`, `Cluster 432`, `Community 1467`, `Cluster 450`, `Community 972`, `Community 982`, `Community 983`, `Community 987`, `Community 996`, `Community 1004`?**
  _High betweenness centrality (0.130) - this node is a cross-community bridge._
- **Why does `range()` connect `Cluster 41` to `API Views & Scenarios`, `Optimizer Validation & Reporting`, `Macro Regime API & Tests`, `Risk Analytics API Tests`, `Optimizer Config Surface`, `Cluster 529`, `Community 1043`, `Cluster 19`, `Cluster 21`, `Cluster 33`, `Community 1060`, `Cluster 44`, `Cluster 46`, `Cluster 51`, `Community 1086`, `Cluster 63`, `Cluster 579`, `Community 1097`, `Cluster 79`, `Cluster 80`, `Cluster 82`, `Cluster 84`, `Community 1110`, `Cluster 94`, `Community 1123`, `Community 1135`, `Cluster 112`, `Community 1138`, `Cluster 116`, `Cluster 124`, `Cluster 128`, `Cluster 151`, `Cluster 152`, `Cluster 154`, `Community 1183`, `Cluster 169`, `Cluster 175`, `Cluster 180`, `Community 1205`, `Cluster 181`, `Cluster 183`, `Cluster 186`, `Community 1215`, `Cluster 192`, `Cluster 199`, `Cluster 203`, `Cluster 204`, `Cluster 207`, `Cluster 215`, `Cluster 216`, `Community 1759`, `Cluster 227`, `Cluster 233`, `Cluster 235`, `Cluster 242`, `Cluster 245`, `Cluster 246`, `Community 1275`, `Cluster 253`, `Cluster 264`, `Community 1803`, `Community 1291`, `Cluster 275`, `Cluster 289`, `Cluster 308`, `Cluster 310`, `Cluster 314`, `Cluster 316`, `Cluster 333`, `Cluster 336`, `Cluster 343`, `Cluster 345`, `Cluster 354`, `Cluster 355`, `Cluster 362`, `Cluster 385`, `Cluster 392`, `Cluster 396`, `Cluster 403`, `Cluster 410`, `Cluster 412`, `Community 1464`, `Cluster 447`, `Cluster 449`, `Cluster 450`, `Cluster 455`, `Cluster 457`, `Community 971`, `Community 972`, `Cluster 464`, `Community 981`, `Community 983`, `Community 986`, `Community 991`, `Community 999`, `Community 1007`, `Community 1011`, `Community 1017`?**
  _High betweenness centrality (0.082) - this node is a cross-community bridge._
- **Why does `sum` connect `Optimizer Config Surface` to `Cluster 132`, `Community 1540`, `Community 1284`, `Community 1159`, `Community 1165`, `Community 1039`, `Cluster 143`, `Cluster 147`, `Cluster 276`, `Cluster 19`, `Cluster 23`, `Cluster 27`, `Cluster 32`, `Cluster 38`, `Cluster 166`, `Cluster 295`, `Cluster 41`, `Cluster 169`, `Cluster 45`, `Cluster 46`, `Cluster 48`, `Cluster 305`, `Cluster 180`, `Community 1464`, `Cluster 445`, `Cluster 61`, `Community 1470`, `Cluster 196`, `Cluster 457`, `Cluster 204`, `Community 978`, `Cluster 343`, `Community 983`, `Community 986`, `Cluster 218`, `Cluster 92`, `Cluster 94`, `Cluster 96`, `Cluster 354`, `Cluster 227`, `Cluster 231`, `Cluster 232`, `Cluster 108`, `Cluster 240`, `Cluster 379`, `Cluster 116`, `Cluster 244`, `Cluster 371`, `Cluster 245`, `Cluster 378`, `Community 1275`?**
  _High betweenness centrality (0.061) - this node is a cross-community bridge._
- **What connects `Assemble optimizer-ready DataFrames from database ORM rows.  This module is the`, `Research module — factor history, optimization, strategies, and reporting.`, `Pure metric computation functions extracted from stock_selection_pipeline.py.  Z` to the rest of the system?**
  _12107 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `API Views & Scenarios` be split into smaller, more focused modules?**
  _Cohesion score 0.02 - nodes in this community are weakly interconnected._
- **Should `Optimizer Validation & Reporting` be split into smaller, more focused modules?**
  _Cohesion score 0.01 - nodes in this community are weakly interconnected._